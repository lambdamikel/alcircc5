FABLE 5 REVIEW BUNDLE -- ROUND 12 (July 8, 2026)
=================================================

Seventh review in the ALCI_RCC5 series: a context-loaded ("hot", NOT cold)
adversarial audit of the canonical round-12 manuscript

    split_forest_automata_with_appendices.tex  (29pp, May 31, 2026)

by Claude Fable 5 (Anthropic), a different model lineage from the proof's
author (GPT-5.5, OpenAI). This bundle is self-contained for feeding back to
the author without repository access.

CONTENTS
--------
referee_report_round12_fable5.pdf / .tex
    The formal report (9pp). Findings, severity-graded:
      F1 (CRITICAL)  The Truth Lemma of Theorem B(b) assumes an unproved
                     SHADOW AMALGAMATION LEMMA: rho_T is amalgamated from
                     bag networks only (App E), yet the universal and
                     vertical-request cases assume the declared
                     relation-vector shadow entries agree with rho_T.
                     Machine-checked counterexample: a 3-bag configuration
                     passing every listed legality test whose declared
                     vectors are jointly unrealizable (23/64 assignments
                     on the minimal pattern fail). The 6th review's C1,
                     one layer up -- but strictly smaller (see report
                     Sec. 6 for the repair program).
      F2 (MAJOR)     Def 3.3 permits EQ-valued shadow entries; obligations
                     then never fire on that target. One-line fix.
      F3 (MAJOR)     The shadow's propagation scope is never defined
                     (App H "must continue"). One-line fix (mandatory
                     propagation).
      F4 (MAJOR)     K(C_0) finiteness (Lemma 3.5) is asserted for an
                     a-priori-infinite enumeration (6th review's M1).
      F5-F7          Minor (App A wording; parity narrative; input-tree
                     arity; plus an observation on request-closed laps).
    Steps found SOUND include: Theorem 2.5 exactly as stated (verified at
    small widths, WP14); the finite->countable compactness passage; strong
    equality; running intersection; the C_split rejection mechanism under
    the repaired discipline; the PO-loop strong-EQ concept handled
    correctly by exact occurrence identity. No accepted-but-unsatisfiable
    CONCEPT was found.

verification/
    wp14_patchwork_property_check.py + wp14_output.txt
        Theorem 2.5 / App A verified directly: 21,538 exhaustive +
        41,681 sampled two-bag amalgamations, 300 leaf-by-leaf tree
        patchings, EQ-forcing impossibility. All PASS (pure stdlib).
    wp15_shadow_row_realizability.py + wp15_output.txt
        The F1 counterexample + exhaustive pattern sweep + the repair
        disciplines (single-shadow 250/250; DR/PO-only 358/358;
        extended-bag 200/200). Pure stdlib.
    wp16_round12_bag_acceptance.py + wp16_output.txt
        Acceptance-level mechanism check vs the cover-tree tableau:
        repaired discipline correct on all ten diagnostics + 148-concept
        random sweep (0 disagreements); literal spec (F2/F3 loopholes)
        wrongly ACCEPTS C_force, C_split, C_2hop, C_3hop.
        Needs support/ on sys.path (it inserts ../support-equivalent
        automatically when run from the repo; here: run from
        verification/ with PYTHONPATH=../support).

support/
    alcircc5_reasoner.py, cover_tree_tableau.py -- the repo's concept
    classes and the cover-tree tableau oracle used by WP16.

HOW TO RUN
----------
    cd verification
    python3 wp14_patchwork_property_check.py     # ~4 min
    python3 wp15_shadow_row_realizability.py     # ~1 min
    PYTHONPATH=../support python3 -u wp16_round12_bag_acceptance.py  # ~2 min

REQUESTED OF THE AUTHOR (report Sec. 6, the round-13 program)
-------------------------------------------------------------
  1. State and prove the Shadow Amalgamation Lemma, preferably via the
     vertical-liveness discipline: PP/PPI/EQ pairs always co-bagged
     (saturation (S3)/(V7) extended to the shadow layer), shadow entries
     restricted to {DR, PO}; then prove bags + DR/PO-only rows jointly
     realizable (DR-default for shadow-shadow pairs; single-shadow case
     already follows from Theorem 2.5 applied to the extended family).
  2. Exclude EQ shadow entries (F2) and make shadow propagation mandatory
     (F3) in the legality tests / transition function.
  3. Give the witness-generated accounting for K(C_0) (F4), or switch to
     the 2^poly type/mosaic bound.
  4. Fix the App A wording (F5) and the parity/arity formalities (F6).

STATUS LANGUAGE (project convention)
------------------------------------
The decidability theorem remains STRONGLY SUPPORTED, NOT CERTIFIED.
7 reviews, 7 defects (six cold, this one hot). Round-12 is still not
cold-reviewed; this audit does not change that.
