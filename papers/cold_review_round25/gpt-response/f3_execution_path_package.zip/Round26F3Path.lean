import Round19Transport

/-!
# Round26F3Path

This supplement makes the blocked/cyclic F3 path explicit.

It does **not** assert the bounded-width/F3 completeness theorem.  Instead it
formalizes the exact theorem that has to be supplied by the mathematical F3
argument and proves the two mechanical consequences:

1. a cyclic/blocked code that realizes a directed omega-limit yields an ordinary
   ALCI_RCC5 model; and
2. a bounded Boolean checker for such codes yields decidability by finite search.

The intended completed F3 theorem is an inhabitant of `BoundedCyclicF3` below.
-/

namespace Round19
open Atom

/-! ## 1. Omega-limit soundness for certified prefixes -/

/--
A directed finite-prefix presentation of an omega RCC5 frame.

`D n` and `rhoN n` are the domain and atomic relation of finite prefix `n`.
`rho` is the intended omega relation on the union domain `fun x => ∃ n, D n x`.

The localization fields say that each tuple needed by R1/R2/R3 is already
present in one prefix and that the omega relation agrees with that prefix on the
entries being checked.  In an actual cyclic-certificate construction, these
facts come from prefix monotonicity and pair-value stability of the unfolding.
-/
structure DirectedRCC5Limit
    (D : Nat → Occ → Prop)
    (rhoN : Nat → Occ → Occ → Atom)
    (rho : Occ → Occ → Atom) : Prop where
  rcc5N : ∀ n, RCC5Interp
    { dom := D n, rho := rhoN n, val := fun _ _ => False }
  diag_local : ∀ x, (∃ n, D n x) →
    ∃ n, D n x ∧ rho x x = rhoN n x x
  pair_local : ∀ x y, (∃ n, D n x) → (∃ n, D n y) →
    ∃ n, D n x ∧ D n y ∧
      rho x y = rhoN n x y ∧ rho y x = rhoN n y x
  triple_local : ∀ x y z,
    (∃ n, D n x) → (∃ n, D n y) → (∃ n, D n z) →
    ∃ n, D n x ∧ D n y ∧ D n z ∧
      rho x y = rhoN n x y ∧
      rho y z = rhoN n y z ∧
      rho x z = rhoN n x z

/--
The directed omega-union of locally stable RCC5 prefixes is an RCC5
interpretation.
-/
theorem directed_limit_rcc5
    (D : Nat → Occ → Prop)
    (rhoN : Nat → Occ → Occ → Atom)
    (rho : Occ → Occ → Atom)
    (val : Nat → Occ → Prop)
    (L : DirectedRCC5Limit D rhoN rho) :
    RCC5Interp { dom := fun x => ∃ n, D n x, rho := rho, val := val } := by
  constructor
  · intro x hx
    obtain ⟨n, hxn, hr⟩ := L.diag_local x hx
    rw [hr]
    exact (L.rcc5N n).refl_eq x hxn
  · intro x y hx hy hxy
    obtain ⟨n, hxn, hyn, hxyN, _hyxN⟩ := L.pair_local x y hx hy
    exact (L.rcc5N n).eq_id x y hxn hyn (by rwa [hxyN] at hxy)
  · intro x y hx hy
    obtain ⟨n, hxn, hyn, hxyN, hyxN⟩ := L.pair_local x y hx hy
    rw [hxyN, hyxN]
    exact (L.rcc5N n).conv_ x y hxn hyn
  · intro x y z hx hy hz
    obtain ⟨n, hxn, hyn, hzn, hxyN, hyzN, hxzN⟩ :=
      L.triple_local x y z hx hy hz
    rw [hxyN, hyzN, hxzN]
    exact (L.rcc5N n).comp_ x y z hxn hyn hzn

/--
Omega-limit analogue of `sat_from_hintikka`.

Once a cyclic/blocking code supplies a directed omega-limit frame and a
Hintikka labelling on the union domain, the existing truth lemma gives ordinary
concept satisfiability.
-/
theorem directed_limit_satisfiable
    (D : Nat → Occ → Prop)
    (rhoN : Nat → Occ → Occ → Atom)
    (rho : Occ → Occ → Atom)
    (val : Nat → Occ → Prop)
    (L : DirectedRCC5Limit D rhoN rho)
    (τ : Occ → List Concept)
    (H : Hintikka (fun x => ∃ n, D n x) rho τ)
    (root : Occ) (hroot : ∃ n, D n root)
    (C0 : Concept) (hC0 : C0 ∈ τ root) :
    Satisfiable C0 := by
  refine ⟨{ dom := fun x => ∃ n, D n x, rho := rho, val := val }, ?_,
    root, hroot, ?_⟩
  · exact directed_limit_rcc5 D rhoN rho val L
  · exact truth_lemma (fun x => ∃ n, D n x) rho τ H C0 root hroot hC0

/-! ## 2. What an accepted cyclic code must semantically realize -/

/--
Semantic payload of an accepted finite cyclic/blocking code.

The code itself is represented externally by a natural number.  The finite
checker is a Boolean predicate on that code.  If the checker accepts, the F3
soundness decoder must be able to construct this payload: a directed omega
limit, a Hintikka labelling on the union domain, and a root carrying the target
concept.
-/
structure OmegaCodeRealizes (C0 : Concept) (code : Nat) where
  D : Nat → Occ → Prop
  rhoN : Nat → Occ → Occ → Atom
  rho : Occ → Occ → Atom
  val : Nat → Occ → Prop
  τ : Occ → List Concept
  root : Occ
  limit : DirectedRCC5Limit D rhoN rho
  hintikka : Hintikka (fun x => ∃ n, D n x) rho τ
  root_dom : ∃ n, D n root
  root_has : C0 ∈ τ root

/-- Accepted cyclic codes are sound because their omega-unfoldings are models. -/
theorem OmegaCodeRealizes.sound {C0 : Concept} {code : Nat}
    (R : OmegaCodeRealizes C0 code) : Satisfiable C0 := by
  exact directed_limit_satisfiable R.D R.rhoN R.rho R.val R.limit R.τ
    R.hintikka R.root R.root_dom C0 R.root_has

/-! ## 3. A bounded executable F3 theorem and finite search -/

/--
The decision-grade form of cyclic F3.

An inhabitant of this structure is the missing theorem/algorithmic package:
for every concept it gives a computable bound and a Boolean checker over codes
below that bound.  Soundness decodes every accepted code to an omega-unfolded
model.  Completeness says every satisfiable concept has some accepted bounded
code.
-/
structure BoundedCyclicF3 where
  bound : Concept → Nat
  check : Concept → Nat → Bool
  realizes : ∀ C0 code, code < bound C0 → check C0 code = true →
    OmegaCodeRealizes C0 code
  complete : ∀ C0, Satisfiable C0 →
    ∃ code, code < bound C0 ∧ check C0 code = true

/-- Soundness half extracted from `BoundedCyclicF3`. -/
theorem BoundedCyclicF3.sound (F : BoundedCyclicF3)
    (C0 : Concept) (code : Nat)
    (hlt : code < F.bound C0) (hcheck : F.check C0 code = true) :
    Satisfiable C0 := by
  exact (F.realizes C0 code hlt hcheck).sound

/-- Semantic satisfiability is equivalent to existence of an accepted bounded code. -/
theorem BoundedCyclicF3.iff_codes (F : BoundedCyclicF3) (C0 : Concept) :
    Satisfiable C0 ↔
      ∃ code, code < F.bound C0 ∧ F.check C0 code = true := by
  constructor
  · exact F.complete C0
  · rintro ⟨code, hlt, hcheck⟩
    exact F.sound C0 code hlt hcheck

/-- Boolean search over codes `0, ..., n-1`. -/
def boundedSearch (p : Nat → Bool) : Nat → Bool
  | 0 => false
  | n + 1 => boundedSearch p n || p n

/-- Correctness of `boundedSearch`. -/
theorem boundedSearch_true_iff (p : Nat → Bool) :
    ∀ n, boundedSearch p n = true ↔ ∃ k, k < n ∧ p k = true := by
  intro n
  induction n with
  | zero =>
      constructor
      · intro h
        cases h
      · rintro ⟨k, hk, _hp⟩
        cases hk
  | succ n ih =>
      constructor
      · intro h
        cases hs : boundedSearch p n with
        | false =>
            cases hp : p n with
            | false =>
                simp [boundedSearch, hs, hp] at h
            | true =>
                exact ⟨n, by omega, hp⟩
        | true =>
            have hex : ∃ k, k < n ∧ p k = true := ih.mp (by simpa using hs)
            obtain ⟨k, hk, hp⟩ := hex
            exact ⟨k, by omega, hp⟩
      · rintro ⟨k, hk, hp⟩
        have hcase : k < n ∨ k = n := by omega
        cases hcase with
        | inl hklt =>
            have hs : boundedSearch p n = true := ih.mpr ⟨k, hklt, hp⟩
            simp [boundedSearch, hs]
        | inr hkeq =>
            subst hkeq
            simp [boundedSearch, hp]

/--
Given a decision-grade bounded cyclic F3 package, concept satisfiability is
decidable by finite Boolean search.
-/
theorem decidable_satisfiable_from_bounded_cyclic_F3
    (F : BoundedCyclicF3) (C0 : Concept) :
    Decidable (Satisfiable C0) := by
  by_cases h : boundedSearch (F.check C0) (F.bound C0) = true
  · apply isTrue
    have hex : ∃ code, code < F.bound C0 ∧ F.check C0 code = true :=
      (boundedSearch_true_iff (F.check C0) (F.bound C0)).mp h
    exact (F.iff_codes C0).mpr hex
  · apply isFalse
    intro hsat
    have hex : ∃ code, code < F.bound C0 ∧ F.check C0 code = true :=
      F.complete C0 hsat
    have htrue : boundedSearch (F.check C0) (F.bound C0) = true :=
      (boundedSearch_true_iff (F.check C0) (F.bound C0)).mpr hex
    exact h htrue

/-- The final theorem shape: a proved `BoundedCyclicF3` instance gives decidability. -/
theorem decidability_from_bounded_cyclic_F3
    (F : BoundedCyclicF3) : ∀ C0, Decidable (Satisfiable C0) := by
  intro C0
  exact decidable_satisfiable_from_bounded_cyclic_F3 F C0

/-- Naming the remaining mathematical target as a proposition, without axiomatising it. -/
def BoundedCyclicF3Target : Prop := Nonempty BoundedCyclicF3

/-- If the target is proved, decidability follows. -/
theorem decidability_from_BoundedCyclicF3Target
    (H : BoundedCyclicF3Target) : ∀ C0, Decidable (Satisfiable C0) := by
  intro C0
  rcases H with ⟨F⟩
  exact decidability_from_bounded_cyclic_F3 F C0

end Round19
