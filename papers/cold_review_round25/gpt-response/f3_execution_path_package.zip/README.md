# F3 execution path supplement

This is an append-only supplement for `Round19Transport.lean`.

Files:

- `Round26F3Path.lean` — omega-limit soundness plus a decision-grade bounded
  cyclic F3 interface and finite-search theorem.
- `Round26CinfRegression.lean` — regression test for the infinite PP-chain
  concept using a repeated blocked type.
- `F3_COMPLETENESS_TARGET.md` — explanation of the exact remaining theorem.
- `check.sh` — copies/imports the files into a work directory and runs Lean if
  Lean is available.
- `audit_no_axioms.sh` — static check that the supplement contains no `sorry`,
  `axiom`, or `admit` tokens.

The environment used to create this package did not contain `lean` or `elan`, so
these files are Lean-shaped and proof-complete but not kernel-checked here.  Run
`./check.sh /path/to/Round19Transport.lean` in a Lean 4.31.0 environment.
