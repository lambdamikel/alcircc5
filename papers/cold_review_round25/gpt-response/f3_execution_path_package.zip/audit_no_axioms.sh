#!/usr/bin/env bash
set -euo pipefail
if grep -RInE '\b(sorry|axiom|admit)\b' Round26F3Path.lean Round26CinfRegression.lean; then
  echo "forbidden token found" >&2
  exit 1
fi
echo "no sorry/axiom/admit tokens found in supplement"
