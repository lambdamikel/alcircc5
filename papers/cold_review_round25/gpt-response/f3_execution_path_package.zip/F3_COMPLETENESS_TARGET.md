# F3 execution status and exact remaining theorem

This package executes the formal path up to the decision-grade F3 target.

## What is formalized

`Round26F3Path.lean` adds:

1. `DirectedRCC5Limit`: a stable omega-union interface for finite certified
   prefixes.
2. `directed_limit_rcc5`: the omega-union is an RCC5 interpretation.
3. `directed_limit_satisfiable`: a Hintikka labelling on that union yields
   `Satisfiable C0` by the existing truth lemma.
4. `OmegaCodeRealizes`: semantic payload of an accepted finite cyclic code.
5. `BoundedCyclicF3`: the exact decision-grade bounded F3 package.
6. `decidability_from_bounded_cyclic_F3`: finite Boolean search gives
   `Decidable (Satisfiable C0)` for every concept once such a package is proved.

`Round26CinfRegression.lean` adds the standard omega-chain regression for

```lean
def Cinf : Concept :=
  Concept.and
    (Concept.ex Atom.pp Concept.top)
    (Concept.all Atom.pp (Concept.ex Atom.pp Concept.top))
```

showing the intended cyclic/blocking reading: one repeated type unfolds into an
infinite PP-chain model.

## What remains genuinely mathematical

An inhabitant of:

```lean
BoundedCyclicF3
```

must provide:

```lean
bound    : Concept -> Nat
check    : Concept -> Nat -> Bool
realizes : every accepted bounded code decodes to an OmegaCodeRealizes payload
complete : every satisfiable concept has an accepted code below bound C0
```

This is the precise replacement for the older finite-plan
`CompletenessObligation`.  It is not a second assumption in addition to F3; it
is the finite/cyclic, decision-grade statement of F3.

## Consequence

Once `BoundedCyclicF3` is proved, the included theorem gives:

```lean
theorem decidability_from_bounded_cyclic_F3
    (F : BoundedCyclicF3) : forall C0, Decidable (Satisfiable C0)
```

The current package does not claim to prove the `complete` field.  That field is
where the bounded-width/uniformization argument has to be installed.
