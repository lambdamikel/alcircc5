#!/usr/bin/env bash
set -euo pipefail

if [ $# -ne 1 ]; then
  echo "usage: $0 /path/to/Round19Transport.lean" >&2
  exit 2
fi

SRC="$1"
if [ ! -f "$SRC" ]; then
  echo "not found: $SRC" >&2
  exit 2
fi

if ! command -v lean >/dev/null 2>&1; then
  echo "lean not found on PATH" >&2
  exit 127
fi

WORK="$(mktemp -d)"
cp "$SRC" "$WORK/Round19Transport.lean"
cp Round26F3Path.lean "$WORK/Round26F3Path.lean"
cp Round26CinfRegression.lean "$WORK/Round26CinfRegression.lean"

cd "$WORK"
lean --version
lean Round26F3Path.lean
lean Round26CinfRegression.lean
