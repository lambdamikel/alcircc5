import Round19Transport

/-!
# Round26CinfRegression

A small regression file showing the intended blocked/cyclic reading on the
standard infinite PP-chain example.  The finite object is one repeated type;
the model is the omega unfolding.
-/

namespace Round19
open Atom

/-- Domain of the omega unfolding: use only `Occ.core n` as live points. -/
def omegaDom : Occ → Prop
  | .core _ => True
  | .born _ _ => False

/-- Atomic RCC5 relation on the chain: equality on the diagonal, PP forward,
PPI backward. -/
def chainAtom (i j : Nat) : Atom :=
  if i = j then Atom.eq else if i < j then Atom.pp else Atom.ppi

/-- Lift the chain relation to `Occ`; off-domain values are irrelevant. -/
def omegaRho : Occ → Occ → Atom
  | .core i, .core j => chainAtom i j
  | _, _ => Atom.eq

def omegaInterpWith (val : Nat → Occ → Prop) : Interp where
  dom := omegaDom
  rho := omegaRho
  val := val

@[simp] theorem chainAtom_self (i : Nat) : chainAtom i i = Atom.eq := by
  unfold chainAtom
  simp

theorem chainAtom_eq {i j : Nat} (h : chainAtom i j = Atom.eq) : i = j := by
  unfold chainAtom at h
  by_cases hij : i = j
  · exact hij
  · by_cases hlt : i < j
    · simp [hij, hlt] at h
    · simp [hij, hlt] at h

theorem chainAtom_conv (i j : Nat) :
    chainAtom j i = conv (chainAtom i j) := by
  unfold chainAtom
  by_cases hij : i = j
  · subst j
    simp
  · by_cases hlt : i < j
    · have hji : ¬ j = i := by omega
      have hjlt : ¬ j < i := by omega
      simp [hij, hlt, hji, hjlt]
    · have hjlt : j < i := by omega
      have hji : ¬ j = i := by omega
      simp [hij, hlt, hji, hjlt]

theorem chainAtom_comp (i j k : Nat) :
    chainAtom i k ∈ comp (chainAtom i j) (chainAtom j k) := by
  unfold chainAtom
  by_cases hij : i = j
  · subst j
    simp
  · by_cases hjk : j = k
    · subst k
      simp
    · by_cases hik : i = k
      · subst k
        by_cases hlt : i < j
        · have hji : ¬ j = i := by omega
          have hjlt : ¬ j < i := by omega
          simp [hij, hlt, hji, hjlt]
        · have hjlt : j < i := by omega
          have hji : ¬ j = i := by omega
          simp [hij, hlt, hji, hjlt]
      · by_cases hijlt : i < j
        · by_cases hjklt : j < k
          · have hiklt : i < k := by omega
            simp [hij, hjk, hik, hijlt, hjklt, hiklt]
          · have hkltj : k < j := by omega
            by_cases hiklt : i < k
            · simp [hij, hjk, hik, hijlt, hjklt, hiklt]
            · have hklti : k < i := by omega
              simp [hij, hjk, hik, hijlt, hjklt, hiklt, hklti]
        · have hjlti : j < i := by omega
          by_cases hjklt : j < k
          · by_cases hiklt : i < k
            · simp [hij, hjk, hik, hijlt, hjklt, hjlti, hiklt]
            · have hklti : k < i := by omega
              simp [hij, hjk, hik, hijlt, hjklt, hjlti, hiklt, hklti]
          · have hkltj : k < j := by omega
            have hklti : k < i := by omega
            have hiklt : ¬ i < k := by omega
            simp [hij, hjk, hik, hijlt, hjklt, hjlti, hkltj, hklti, hiklt]

theorem omegaInterpWith_rcc5 (val : Nat → Occ → Prop) :
    RCC5Interp (omegaInterpWith val) := by
  refine ⟨?_, ?_, ?_, ?_⟩
  · intro x hx
    cases x with
    | core i => simp [omegaInterpWith, omegaDom, omegaRho]
    | born s j => cases hx
  · intro x y hx hy hxy
    cases x with
    | core i =>
        cases y with
        | core j =>
            have h : chainAtom i j = Atom.eq := by
              simpa [omegaInterpWith, omegaRho] using hxy
            exact congrArg Occ.core (chainAtom_eq h)
        | born s j => cases hy
    | born s j => cases hx
  · intro x y hx hy
    cases x with
    | core i =>
        cases y with
        | core j => simpa [omegaInterpWith, omegaRho] using chainAtom_conv i j
        | born s j => cases hy
    | born s j => cases hx
  · intro x y z hx hy hz
    cases x with
    | core i =>
        cases y with
        | core j =>
            cases z with
            | core k => simpa [omegaInterpWith, omegaRho] using chainAtom_comp i j k
            | born s k => cases hz
        | born s j => cases hy
    | born s j => cases hx

/-- The familiar forcing concept. -/
def Cinf : Concept :=
  Concept.and
    (Concept.ex Atom.pp Concept.top)
    (Concept.all Atom.pp (Concept.ex Atom.pp Concept.top))

def CinfType : List Concept :=
  [ Cinf,
    Concept.ex Atom.pp Concept.top,
    Concept.all Atom.pp (Concept.ex Atom.pp Concept.top),
    Concept.top ]

def CinfTau : Occ → List Concept
  | .core _ => CinfType
  | .born _ _ => []

theorem CinfTau_hintikka : Hintikka omegaDom omegaRho CinfTau := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro x a hx hatom hnatom
    cases x with
    | core n => simp [CinfTau, CinfType, Cinf] at hatom
    | born s j => cases hx
  · intro x hx hbot
    cases x with
    | core n => simp [CinfTau, CinfType, Cinf] at hbot
    | born s j => cases hx
  · intro x c d hx hand
    cases x with
    | core n =>
        simp [CinfTau, CinfType, Cinf] at hand
        rcases hand with ⟨hc, hd⟩
        subst c
        subst d
        simp [CinfTau, CinfType, Cinf]
    | born s j => cases hx
  · intro x c d hx hor
    cases x with
    | core n => simp [CinfTau, CinfType, Cinf] at hor
    | born s j => cases hx
  · intro x r c hx hall y hy hrho
    cases x with
    | core n =>
        simp [CinfTau, CinfType, Cinf] at hall
        rcases hall with ⟨hr, hc⟩
        subst r
        subst c
        cases y with
        | core m => simp [CinfTau, CinfType]
        | born s j => cases hy
    | born s j => cases hx
  · intro x r c hx hex
    cases x with
    | core n =>
        simp [CinfTau, CinfType, Cinf] at hex
        rcases hex with ⟨hr, hc⟩
        subst r
        subst c
        refine ⟨Occ.core (n + 1), ?_, ?_, ?_⟩
        · trivial
        · have hne : ¬ n = n + 1 := by omega
          have hlt : n < n + 1 := Nat.lt_succ_self n
          simp [omegaRho, chainAtom, hne, hlt]
        · simp [CinfTau, CinfType]
    | born s j => cases hx

theorem Cinf_satisfiable_from_omega_block : Satisfiable Cinf := by
  refine ⟨omegaInterpWith (fun a x => Concept.atom a ∈ CinfTau x), ?_,
    Occ.core 0, trivial, ?_⟩
  · exact omegaInterpWith_rcc5 (fun a x => Concept.atom a ∈ CinfTau x)
  · exact truth_lemma omegaDom omegaRho CinfTau CinfTau_hintikka
      Cinf (Occ.core 0) trivial (by simp [CinfTau, CinfType])

end Round19
