#!/usr/bin/env python3
"""Finite RCC5 path-automaton audit for the Round 29 F3 attempt.

This script checks the key one-dimensional lemma used in the proof attempt:
within the automaton of possible relations along a path, there is no cycle that
both avoids EQ and uses a horizontal label (DR or PO). Hence any infinite path
whose endpoint cannot be folded back by EQ is eventually purely vertical: PP-only
or PPI-only in one of the vertical cones.
"""
from __future__ import annotations
from collections import defaultdict

ATOMS = ("EQ", "DR", "PO", "PP", "PPI")
PROPER = ("DR", "PO", "PP", "PPI")
HORIZ = {"DR", "PO"}
VERT = {"PP", "PPI"}

COMP = {
    ("EQ","EQ"):("EQ",), ("EQ","DR"):("DR",), ("EQ","PO"):("PO",), ("EQ","PP"):("PP",), ("EQ","PPI"):("PPI",),
    ("DR","EQ"):("DR",), ("DR","DR"):ATOMS, ("DR","PO"):("DR","PO","PP"), ("DR","PP"):("DR","PO","PP"), ("DR","PPI"):("DR",),
    ("PO","EQ"):("PO",), ("PO","DR"):("DR","PO","PPI"), ("PO","PO"):ATOMS, ("PO","PP"):("PO","PP"), ("PO","PPI"):("DR","PO","PPI"),
    ("PP","EQ"):("PP",), ("PP","DR"):("DR",), ("PP","PO"):("DR","PO","PP"), ("PP","PP"):("PP",), ("PP","PPI"):ATOMS,
    ("PPI","EQ"):("PPI",), ("PPI","DR"):("DR","PO","PPI"), ("PPI","PO"):("PO","PPI"), ("PPI","PP"):("EQ","PO","PP","PPI"), ("PPI","PPI"):("PPI",),
}

def cset(S: frozenset[str], a: str) -> frozenset[str]:
    out: set[str] = set()
    for r in S:
        out.update(COMP[(r, a)])
    return frozenset(out)

def fmt(S: frozenset[str]) -> str:
    return "{" + ",".join(a for a in ATOMS if a in S) + "}"

NOEQ = [frozenset(a for i, a in enumerate(ATOMS) if (mask >> i) & 1)
        for mask in range(1, 1 << len(ATOMS))
        if not ((mask >> ATOMS.index("EQ")) & 1)]

EDGES: list[tuple[frozenset[str], str, frozenset[str]]] = []
for S in NOEQ:
    for a in PROPER:
        U = cset(S, a)
        if "EQ" not in U:
            EDGES.append((S, a, U))

ADJ: dict[frozenset[str], list[tuple[str, frozenset[str]]]] = defaultdict(list)
for S, a, U in EDGES:
    ADJ[S].append((a, U))

# Tarjan SCCs.
index = 0
stack: list[frozenset[str]] = []
onstack: set[frozenset[str]] = set()
indices: dict[frozenset[str], int] = {}
low: dict[frozenset[str], int] = {}
sccs: list[list[frozenset[str]]] = []

def strongconnect(v: frozenset[str]) -> None:
    global index
    indices[v] = index
    low[v] = index
    index += 1
    stack.append(v)
    onstack.add(v)
    for _, w in ADJ[v]:
        if w not in indices:
            strongconnect(w)
            low[v] = min(low[v], low[w])
        elif w in onstack:
            low[v] = min(low[v], indices[w])
    if low[v] == indices[v]:
        compo = []
        while True:
            w = stack.pop()
            onstack.remove(w)
            compo.append(w)
            if w == v:
                break
        sccs.append(compo)

for v in NOEQ:
    if v not in indices:
        strongconnect(v)

cyclic_sccs = []
for compo in sccs:
    if len(compo) > 1:
        cyclic_sccs.append(compo)
    elif compo:
        v = compo[0]
        if any(w == v for _, w in ADJ[v]):
            cyclic_sccs.append(compo)

horizontal_cycle_edges = []
for compo in cyclic_sccs:
    C = set(compo)
    for v in compo:
        for a, w in ADJ[v]:
            if w in C and a in HORIZ:
                horizontal_cycle_edges.append((v, a, w))

print("RCC5 no-EQ path automaton audit")
print("================================")
print(f"No-EQ states: {len(NOEQ)}")
print(f"No-EQ transitions: {len(EDGES)}")
print()
print("No-EQ transitions:")
for S, a, U in sorted(EDGES, key=lambda e: (len(e[0]), fmt(e[0]), e[1], fmt(e[2]))):
    print(f"  {fmt(S):18s} --{a:3s}--> {fmt(U)}")
print()
print("Cyclic no-EQ SCCs:")
for compo in cyclic_sccs:
    states = ", ".join(fmt(s) for s in sorted(compo, key=fmt))
    internal_labels = sorted({a for v in compo for a, w in ADJ[v] if w in set(compo)})
    print(f"  [{states}]  internal labels = {internal_labels}")
print()
if horizontal_cycle_edges:
    print("FAIL: found a no-EQ cycle using a horizontal label:")
    for v, a, w in horizontal_cycle_edges:
        print(f"  {fmt(v)} --{a}--> {fmt(w)}")
    raise SystemExit(1)
else:
    print("PASS: every no-EQ cycle is vertical-only.")
    print("Consequence: any infinite path that never admits EQ is eventually trapped")
    print("in a PP-cone or a PPI-cone. Horizontal recurrence is foldable.")
