/-
Round29PathAutomatonSketch.lean

Lean-shaped sketch for the finite path automaton used in the Round 29 proof attempt.
This file is intentionally a sketch/specification, not a kernel-checked supplement in this environment.
The main theorem is stated as a comment because Lean is
not available here to validate a `native_decide` proof.
-/

inductive A where
  | eq | dr | po | pp | ppi
  deriving DecidableEq, Repr

open A

def comp : A -> A -> List A
  | eq,  eq  => [eq]
  | eq,  dr  => [dr]
  | eq,  po  => [po]
  | eq,  pp  => [pp]
  | eq,  ppi => [ppi]
  | dr,  eq  => [dr]
  | dr,  dr  => [eq, dr, po, pp, ppi]
  | dr,  po  => [dr, po, pp]
  | dr,  pp  => [dr, po, pp]
  | dr,  ppi => [dr]
  | po,  eq  => [po]
  | po,  dr  => [dr, po, ppi]
  | po,  po  => [eq, dr, po, pp, ppi]
  | po,  pp  => [po, pp]
  | po,  ppi => [dr, po, ppi]
  | pp,  eq  => [pp]
  | pp,  dr  => [dr]
  | pp,  po  => [dr, po, pp]
  | pp,  pp  => [pp]
  | pp,  ppi => [eq, dr, po, pp, ppi]
  | ppi, eq  => [ppi]
  | ppi, dr  => [dr, po, ppi]
  | ppi, po  => [po, ppi]
  | ppi, pp  => [eq, po, pp, ppi]
  | ppi, ppi => [ppi]

/-
Intended finite theorem, established by the Python audit:

`no_horizontal_noeq_cycle`:
In the finite automaton on nonempty subsets of {dr,po,pp,ppi}, with transition
S --a--> S*a retained only when eq notin S*a, every directed cycle has labels
contained in {pp} or contained in {ppi}.  In particular no no-EQ cycle uses dr
or po.

This should be formalized in Lean by encoding subsets as 5-bit masks and proving the statement by
decidable exhaustive checking.
-/
