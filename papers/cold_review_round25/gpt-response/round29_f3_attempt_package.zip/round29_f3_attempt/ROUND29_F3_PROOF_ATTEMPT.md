# Round 29 F3 proof attempt: horizontal-clock route

This note is an attempted proof of the remaining bounded-width/F3 theorem after reading
`why_its_hard.pdf` and `width_barrier.pdf`.  It is intentionally adversarial: it records the
part that can be made finite-table rigorous, the proposed lifting argument, and the point that still
has to be turned into a Lean theorem before decidability can be claimed.

## 0. Target

Let `Cl(C0)` be the Fischer-Ladner / NNF closure of the input concept, let

```text
E(C0) = { existential subconcepts ∃R.D in Cl(C0) },
T(C0) = set of closure types ⊆ Cl(C0).
```

A decision-grade F3 theorem should produce a computable bound `B(C0)` such that every
satisfiable `C0` has a finite cyclic/stable certificate using at most `B(C0)` live interface ports,
and such that the certificate checker is finite and decidable.

The existing Lean soundness pipeline then gives:

```text
accepted finite cyclic certificate => omega unfolding => RCC5 model => C0 satisfiable.
```

The missing direction is:

```text
C0 satisfiable => accepted bounded cyclic certificate.
```

## 1. Start from a generated support model

Given any satisfying interpretation `I, x0 ⊨ C0`, choose, for every selected node `x` and every
existential formula `∃R.D ∈ type(x)`, one witness `w(x, ∃R.D)` with

```text
rho(x, w) = R and w ⊨ D.
```

Close from `x0` under these chosen witnesses.  This gives a countable support submodel `S` of
out-degree at most `|E(C0)|`.

This step is safe because:

1. Existentials are preserved by construction.
2. Universals are preserved when passing to a subdomain.
3. RCC5 R1/R2/R3 are inherited by restriction.

So the problem is not uncontrolled model degree.  The only remaining danger is that the complete
RCC5 relation on the finitely-branching support tree may require unbounded live interface rows.

## 2. The finite path automaton

For a path segment with edge labels `a1, ..., an`, define the possible endpoint-relation set by
iterated RCC5 composition:

```text
Rel([]) = {EQ}
Rel(w ++ [a]) = ⋃_{r ∈ Rel(w)} comp(r, a).
```

For blocking, the relevant question is whether `EQ ∈ Rel(w)`.  If `EQ` is possible, a repeated
state at the end of `w` may be folded.  If `EQ` is impossible, the path segment cannot be collapsed
by equality and must be represented by a genuine unfolding.

The finite audit in `scripts/rcc5_path_automaton.py` proves the following table fact.

### Lemma 1: no horizontal no-EQ cycle

In the automaton whose states are nonempty subsets of `{DR,PO,PP,PPI}` and whose transition is
`S --a--> S*a` when `EQ ∉ S*a`, every directed cycle is labelled only by `PP` or only by `PPI`.
There is no cycle avoiding `EQ` that uses a horizontal label `DR` or `PO`.

Equivalently: any infinite path that never admits an equality fold is eventually trapped in a
vertical cone.  The only cyclic no-EQ SCCs found by the audit are:

```text
{PP}          --PP-->  {PP}
{PO,PP}       --PP-->  {PO,PP}
{DR,PO,PP}    --PP-->  {DR,PO,PP}
{PPI}         --PPI--> {PPI}
{DR,PPI}      --PPI--> {DR,PPI}
{DR,PO,PPI}   --PPI--> {DR,PO,PPI}
{DR}          --PPI--> {DR}
```

The last state `{DR}` under `PPI` is the familiar downward-DR shadow case.

This is the first genuine horizontal clock: horizontal recurrence is impossible without eventually
making `EQ` available.  Non-foldable recurrence is vertical.

## 3. Path blocking consequence

Let a support path be decorated not only by the RCC5 path-automaton state, but also by the finite
closure type of the current node and by the finite vector of active ancestor requirements that still
constrain descendants.  Call this decorated object a `block state`.

There are finitely many block states, bounded computably from `Cl(C0)` and the finite RCC5
path-automaton.  Along any infinite support path:

1. If a block state repeats while `EQ` is available between the two occurrences, fold horizontally.
   This is an ordinary blocking step; the lower occurrence can be represented by a cyclic pointer.
2. If no such fold occurs, Lemma 1 implies the path is eventually in a vertical `PP`-cone or
   `PPI`-cone.  Then the remaining infinite behavior is a vertical ladder, represented by the
   already-understood cyclic/omega unfolding.  Any unbounded relation inherited along the ladder
   is represented by a finite row-state transition, not by adding live ports.

Thus a single branch cannot force unbounded horizontal width.  Infinite branches are either
foldable or vertical.

## 4. Attempted lift from paths to width

Because the generated support tree has branching at most `|E(C0)|`, an unbounded live horizontal
interface would have to arise from a large antichain of support nodes.  Let `u` be their least common
ancestor region in the support tree.  Each member of the antichain lies below one of finitely many
successor branches of `u`.

The intended lifting argument is:

1. Each branch below `u` has only a bounded nonvertical prefix by the path-blocking consequence.
2. After that prefix, the branch is a vertical cone with a finite row-state relative to `u` and to the
   finitely many other nonvertical prefixes at the same interface.
3. Two vertical tails with the same finite row-state and the same closure type are interchangeable
   for all ALCI_RCC5 formulas in `Cl(C0)`.
4. Therefore, in a minimal support/certificate, only one representative of each such state is needed.
5. The number of live interface representatives is bounded by

```text
B(C0) = geometric_bound(|E(C0)|, number_of_block_states(C0)).
```

This would close F6 and yield the finite cyclic F3 certificate.

## 5. The exact remaining lemma

The proof attempt is not complete until the following lemma is proved.

### Lemma 2: dominated vertical-tail pruning / horizontal interface pruning

Fix a generated support tree and a finite interface bag `P`.  Suppose two pending vertical tails
`A` and `B` below the same interface have:

1. the same closure type,
2. the same path-automaton cone (`PP`-cone or `PPI`-cone),
3. the same row-state to every protected port in `P`, and
4. the same outstanding existential obligations up to closure type.

Then one of the two tails can be replaced by a cyclic pointer to the other, or deleted with its
obligations redirected, without destroying:

```text
- all existential witnesses needed by retained nodes,
- all universal restrictions in Cl(C0),
- RCC5 converse and composition closure,
- strong-EQ irreflexivity for PP/PPI ladders.
```

If Lemma 2 holds, F3 follows from Lemma 1 plus bounded branching.  If Lemma 2 fails, the failure
is exactly a forced rigid horizontal coordinate system: the two tails have identical finite observable
state but cannot be redirected because their relations to the surrounding horizontal crowd are
semantically rigid.

## 6. Why this is progress but not a proof of decidability

The new finite-table fact rules out the simplest missing horizontal clock problem: there is no
infinite nonfoldable horizontal path.  This is stronger than merely saying singleton determination is
vertical; it also accounts for non-singleton relation-set propagation.

However, F6 is a width statement, not only a path statement.  The final path-to-antichain lift is
precisely Lemma 2.  I do not currently have a kernel-checkable proof of Lemma 2.  The attempt
therefore does not prove decidability yet.

What it does provide is a smaller, sharper target:

```text
F3 reduces to horizontal interface pruning for finitely many vertical-tail row states.
```

This is the lemma I would try to formalize next in Lean, after first representing block states and
row-state equality in the existing `Catalog`/`Cert` vocabulary.

## 7. Lean status

This environment does not have `lean` or `elan` on `PATH`, so none of this package is kernel-checked.
The finite RCC5 audit is executable Python and has been run in the container; its output is in
`outputs/path_automaton_report.txt`.

