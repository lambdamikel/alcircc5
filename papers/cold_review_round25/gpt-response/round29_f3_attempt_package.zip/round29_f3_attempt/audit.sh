#!/usr/bin/env bash
set -euo pipefail
python3 scripts/rcc5_path_automaton.py > outputs/path_automaton_report.txt
if grep -RInE '\b(sorry|axiom|admit)\b' --exclude='audit.sh' .; then
  echo 'Found a Lean proof placeholder token.' >&2
  exit 1
fi
if command -v lean >/dev/null 2>&1; then
  lean --version
else
  echo 'lean not found on PATH; Lean files not kernel-checked.'
fi
