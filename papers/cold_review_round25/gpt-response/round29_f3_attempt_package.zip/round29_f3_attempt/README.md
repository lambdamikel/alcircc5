# Round 29 F3 attempt package

Contents:

- `ROUND29_F3_PROOF_ATTEMPT.md` — proof attempt and current status.
- `scripts/rcc5_path_automaton.py` — finite audit of the no-EQ path automaton.
- `outputs/path_automaton_report.txt` — generated audit output.
- `lean/Round29PathAutomatonSketch.lean` — Lean-shaped definitions/specification sketch only; not kernel-checked here.

The package does **not** claim a full decidability proof.  It proves by finite computation the
one-dimensional horizontal-clock lemma and reduces the remaining F3 proof to a precise horizontal
interface-pruning lemma.
