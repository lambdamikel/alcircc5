
/-!
# Omega-unfolding repair for the F3 interface

Append this file after `Round19Transport.lean` and run the concatenation.
It adds a prefix-limit soundness theorem: if an infinite relation is the
stable limit of certified finite prefixes, then it is an RCC5 frame.  This
is the formal shape needed for blocked/cyclic certificates: the finite
object supplies all finite prefixes, while the model domain is their
omega-unfolding.
-/

namespace Round19
open Atom

/-- A stable omega-limit of finite certified prefixes.

`rho0` is the off-diagonal limit relation.  The interpretation relation
will be `EQ` on the diagonal and `rho0` off the diagonal.  `cover3` says
that every finite triple of limit-domain occurrences appears in some
certified finite prefix.  `rho_agrees` says that, on any such prefix,
the limit relation agrees with the finite certificate's `pairVal`.
-/
structure PrefixLimit where
  dom : Occ -> Prop
  rho0 : Occ -> Occ -> Atom
  C : Nat -> Cert
  wf : ∀ n, Wellformed (C n)
  scond : ∀ n, SCond (C n)
  cover3 : ∀ x y z, dom x -> dom y -> dom z ->
    ∃ n,
      x ∈ existingBefore (C n) (C n).steps.length ∧
      y ∈ existingBefore (C n) (C n).steps.length ∧
      z ∈ existingBefore (C n) (C n).steps.length
  rho_agrees : ∀ n x y,
    x ∈ existingBefore (C n) (C n).steps.length ->
    y ∈ existingBefore (C n) (C n).steps.length ->
    x ≠ y ->
    rho0 x y = pairVal (C n) x y

def PrefixLimit.rho (L : PrefixLimit) (x y : Occ) : Atom :=
  if x = y then Atom.eq else L.rho0 x y

def PrefixLimit.interp (L : PrefixLimit) (val : Nat -> Occ -> Prop) : Interp :=
  { dom := L.dom, rho := L.rho, val := val }

/-- The stable omega-limit of finite certified prefixes is an RCC5 frame. -/
theorem prefixLimit_rcc5 (L : PrefixLimit) (val : Nat -> Occ -> Prop) :
    RCC5Interp (L.interp val) := by
  constructor
  · intro x hx
    unfold PrefixLimit.interp PrefixLimit.rho
    simp
  · intro x y hx hy hxyeq
    by_cases hxy : x = y
    · exact hxy
    · exfalso
      obtain ⟨n, hxn, hyn, _hzn⟩ := L.cover3 x y y hx hy hy
      have hrho : L.rho0 x y = Atom.eq := by
        unfold PrefixLimit.interp PrefixLimit.rho at hxyeq
        simp [hxy] at hxyeq
        exact hxyeq
      have hpv : pairVal (L.C n) x y = Atom.eq := by
        rw [← L.rho_agrees n x y hxn hyn hxy]
        exact hrho
      exact pairVal_proper (L.C n) (L.wf n) (L.scond n) x y hxn hyn hxy hpv
  · intro x y hx hy
    by_cases hxy : x = y
    · subst hxy
      unfold PrefixLimit.interp PrefixLimit.rho
      simp
    · obtain ⟨n, hxn, hyn, _hzn⟩ := L.cover3 x y y hx hy hy
      unfold PrefixLimit.interp PrefixLimit.rho
      rw [if_neg (fun h : y = x => hxy h.symm), if_neg hxy]
      rw [L.rho_agrees n y x hyn hxn (fun h : y = x => hxy h.symm)]
      rw [L.rho_agrees n x y hxn hyn hxy]
      exact pairVal_conv (L.C n) (L.wf n) (L.scond n).core_conv hxy
        (birthBound hxn) (birthBound hyn)
  · intro x y z hx hy hz
    obtain ⟨n, hxn, hyn, hzn⟩ := L.cover3 x y z hx hy hz
    unfold PrefixLimit.interp PrefixLimit.rho
    by_cases hxy : x = y
    · subst hxy
      rw [if_pos rfl, comp_eq_left]
      exact List.mem_cons_self ..
    · by_cases hyz : y = z
      · subst hyz
        rw [if_pos rfl, comp_eq_right]
        exact List.mem_cons_self ..
      · by_cases hxz : x = z
        · rw [if_pos hxz, if_neg hxy, if_neg hyz]
          rw [L.rho_agrees n x y hxn hyn hxy]
          rw [L.rho_agrees n y z hyn hzn hyz]
          rw [← congrArg (pairVal (L.C n) y) hxz]
          rw [pairVal_conv (L.C n) (L.wf n) (L.scond n).core_conv hxy
                (birthBound hxn) (birthBound hyn)]
          exact eq_mem_comp_conv _
        · rw [if_neg hxz, if_neg hxy, if_neg hyz]
          rw [L.rho_agrees n x z hxn hzn hxz]
          rw [L.rho_agrees n x y hxn hyn hxy]
          rw [L.rho_agrees n y z hyn hzn hyz]
          exact pairVal_closed (L.C n) (L.wf n) (L.scond n)
            x z y hxn hzn hyn hxz hxy hyz

/-- Omega-limit soundness with predicate Hintikka labels.  This is the
replacement for the finite-plan-only capstone when the certificate is
blocked/cyclic and must be unfolded indefinitely. -/
theorem omega_limit_satisfiable (L : PrefixLimit) (val : Nat -> Occ -> Prop)
    (tau : Occ -> Concept -> Prop)
    (H : HintikkaP (L.interp val) tau)
    (root : Occ) (hroot : L.dom root)
    (C0 : Concept) (hC0 : tau root C0) :
    Satisfiable C0 := by
  exact ⟨L.interp val, prefixLimit_rcc5 L val, root, hroot,
    truth_lemmaP (L.interp val) tau H C0 root hroot hC0⟩

/-! ## A concrete infinite PP-chain model for the standard blocking test -/

def Cinf : Concept :=
  Concept.and
    (Concept.ex Atom.pp Concept.top)
    (Concept.all Atom.pp (Concept.ex Atom.pp Concept.top))

/-- Relation of the strict natural-number chain: `i PP j` iff `i < j`. -/
def natChainR (i j : Nat) : Atom :=
  if i = j then Atom.eq else if i < j then Atom.pp else Atom.ppi

theorem natChainR_eq_id {i j : Nat} :
    natChainR i j = Atom.eq -> i = j := by
  intro h
  unfold natChainR at h
  by_cases hij : i = j
  · exact hij
  · by_cases hlt : i < j
    · have hfalse : False := by simpa [hij, hlt] using h
      exact False.elim hfalse
    · have hfalse : False := by simpa [hij, hlt] using h
      exact False.elim hfalse

theorem natChainR_conv (i j : Nat) :
    natChainR j i = conv (natChainR i j) := by
  unfold natChainR
  by_cases hij : i = j <;>
  by_cases hji : j = i <;>
  by_cases hijlt : i < j <;>
  by_cases hjilt : j < i <;>
  simp [hij, hji, hijlt, hjilt] <;> omega

theorem natChainR_comp (i j k : Nat) :
    natChainR i k ∈ comp (natChainR i j) (natChainR j k) := by
  unfold natChainR
  by_cases hij : i = j <;>
  by_cases hijlt : i < j <;>
  by_cases hjk : j = k <;>
  by_cases hjklt : j < k <;>
  by_cases hik : i = k <;>
  by_cases hiklt : i < k <;>
  simp [hij, hijlt, hjk, hjklt, hik, hiklt] <;> omega


def chainDom : Occ -> Prop
  | Occ.core _ => True
  | Occ.born _ _ => False

def chainRho : Occ -> Occ -> Atom
  | Occ.core i, Occ.core j => natChainR i j
  | _, _ => Atom.dr

/-! ### Finite certified prefixes of the PP chain

For the simple blocking test, the omega-chain can be approximated by finite
core-only certificates.  Each prefix has no attachment steps; its core net is
the restriction of the strict natural-number PP chain.  The following
`PrefixLimit` instance is therefore a completely explicit limit of finite
certified prefixes.  A catalogue-level cyclic implementation would replace
these growing core prefixes by finite blocked templates plus a proof that their
finite unfoldings agree with this same limit relation.
-/

def chainCert (n : Nat) : Cert where
  nCore := n
  coreNet := natChainR
  templates := []
  steps := []
  f := fun _ _ _ _ => Atom.dr

theorem chainCert_no_step {n i : Nat} (hi : i < (chainCert n).steps.length) :
    False := by
  simpa [chainCert] using hi

theorem chainCert_wf (n : Nat) : Wellformed (chainCert n) := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro i hi t ht
    exact False.elim (chainCert_no_step hi)
  · intro i hi t ht
    exact False.elim (chainCert_no_step hi)
  · intro i hi
    exact False.elim (chainCert_no_step hi)
  · intro i hi
    exact False.elim (chainCert_no_step hi)
  · intro i hi
    exact False.elim (chainCert_no_step hi)
  · intro i hi p q
    exact False.elim (chainCert_no_step hi)
  · intro i hi r1 r1' r2 r2' j h1 h2
    exact False.elim (chainCert_no_step hi)

theorem chainCert_scond (n : Nat) : SCond (chainCert n) := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro c c'
    simpa [chainCert] using natChainR_conv c c'
  · intro c c' hc hc' hne heq
    exact hne (natChainR_eq_id (by simpa [chainCert] using heq))
  · intro c1 c2 c3 h1 h2 h3 h12 h13 h32
    simpa [chainCert] using natChainR_comp c1 c3 c2
  · intro i hi c c' hc hc' hne
    exact False.elim (chainCert_no_step hi)
  · intro i hi x hx y hy jz hjz hxy hxz hyz
    exact False.elim (chainCert_no_step hi)
  · intro i hi x hx jz hjz hxz
    exact False.elim (chainCert_no_step hi)

/-- The PP omega-chain as a stable limit of finite certified prefixes. -/
def chainPrefixLimit : PrefixLimit where
  dom := chainDom
  rho0 := chainRho
  C := chainCert
  wf := chainCert_wf
  scond := chainCert_scond
  cover3 := by
    intro x y z hx hy hz
    cases x with
    | core i =>
        cases y with
        | core j =>
            cases z with
            | core k =>
                refine ⟨i + j + k + 1, ?_, ?_, ?_⟩
                · exact mem_existingBefore_core.mpr (by simp [chainCert]; omega)
                · exact mem_existingBefore_core.mpr (by simp [chainCert]; omega)
                · exact mem_existingBefore_core.mpr (by simp [chainCert]; omega)
            | born s k =>
                simp [chainDom] at hz
                cases hz
        | born s j =>
            simp [chainDom] at hy
            cases hy
    | born s i =>
        simp [chainDom] at hx
        cases hx
  rho_agrees := by
    intro n x y hx hy hxy
    cases x with
    | core i =>
        cases y with
        | core j =>
            rfl
        | born s j =>
            have hfalse : False := by
              have hy' := mem_existingBefore_born.mp hy
              simpa [chainCert] using hy'.1
            exact False.elim hfalse
    | born s i =>
        have hfalse : False := by
          have hx' := mem_existingBefore_born.mp hx
          simpa [chainCert] using hx'.1
        exact False.elim hfalse

theorem chainPrefixLimit_rcc5 :
    RCC5Interp (chainPrefixLimit.interp (fun _ _ => False)) :=
  prefixLimit_rcc5 chainPrefixLimit (fun _ _ => False)


def chainInterp : Interp :=
  { dom := chainDom, rho := chainRho, val := fun _ _ => False }

theorem chain_rcc5 : RCC5Interp chainInterp := by
  constructor
  · intro x hx
    cases x with
    | core i =>
        simp [chainInterp, chainDom, chainRho, natChainR]
    | born s j =>
        simp [chainInterp, chainDom] at hx
        cases hx
  · intro x y hx hy hxyeq
    cases x with
    | core i =>
        cases y with
        | core j =>
            have hij : i = j := natChainR_eq_id (by simpa [chainInterp, chainRho] using hxyeq)
            exact congrArg Occ.core hij
        | born s j =>
            simp [chainInterp, chainDom] at hy
            cases hy
    | born s j =>
        simp [chainInterp, chainDom] at hx
        cases hx
  · intro x y hx hy
    cases x with
    | core i =>
        cases y with
        | core j =>
            simpa [chainInterp, chainRho] using natChainR_conv i j
        | born s j =>
            simp [chainInterp, chainDom] at hy
            cases hy
    | born s j =>
        simp [chainInterp, chainDom] at hx
        cases hx
  · intro x y z hx hy hz
    cases x with
    | core i =>
        cases y with
        | core j =>
            cases z with
            | core k =>
                simpa [chainInterp, chainRho] using natChainR_comp i j k
            | born s k =>
                simp [chainInterp, chainDom] at hz
                cases hz
        | born s j =>
            simp [chainInterp, chainDom] at hy
            cases hy
    | born s i =>
        simp [chainInterp, chainDom] at hx
        cases hx


/-- The same PP chain, obtained through the prefix-limit construction. -/
def prefixChainInterp : Interp :=
  chainPrefixLimit.interp (fun _ _ => False)

theorem prefixChain_sat_Cinf_root : sat prefixChainInterp (Occ.core 0) Cinf := by
  unfold Cinf
  constructor
  · refine ⟨Occ.core 1, ?_, ?_, ?_⟩
    · simp [prefixChainInterp, PrefixLimit.interp, chainPrefixLimit, chainDom]
    · have hne : (Occ.core 0) ≠ Occ.core 1 := by intro h; injection h with h0; omega
      have hneN : (0 : Nat) ≠ 1 := by omega
      have hlt : (0 : Nat) < 1 := by omega
      simp [prefixChainInterp, PrefixLimit.interp, PrefixLimit.rho,
        chainPrefixLimit, chainRho, natChainR, hne, hneN, hlt]
    · trivial
  · intro y hy hyr
    cases y with
    | core n =>
        refine ⟨Occ.core (n+1), ?_, ?_, ?_⟩
        · simp [prefixChainInterp, PrefixLimit.interp, chainPrefixLimit, chainDom]
        · have hne : (Occ.core n) ≠ Occ.core (n+1) := by
            intro h; injection h with hn; omega
          have hneN : n ≠ n+1 := by omega
          have hlt : n < n+1 := by omega
          simp [prefixChainInterp, PrefixLimit.interp, PrefixLimit.rho,
            chainPrefixLimit, chainRho, natChainR, hne, hneN, hlt]
        · trivial
    | born s j =>
        simp [prefixChainInterp, PrefixLimit.interp, chainPrefixLimit, chainDom] at hy
        cases hy

theorem Cinf_satisfiable_from_prefixLimit : Satisfiable Cinf := by
  exact omega_limit_satisfiable chainPrefixLimit (fun _ _ => False)
    (fun x C => sat prefixChainInterp x C)
    (model_hintikkaP prefixChainInterp)
    (Occ.core 0)
    (by simp [prefixChainInterp, PrefixLimit.interp, chainPrefixLimit, chainDom])
    Cinf
    prefixChain_sat_Cinf_root

theorem chain_sat_Cinf_root : sat chainInterp (Occ.core 0) Cinf := by
  unfold Cinf
  constructor
  · refine ⟨Occ.core 1, ?_, ?_, ?_⟩
    · simp [chainInterp, chainDom]
    · have hne : (0 : Nat) ≠ 1 := by omega
      have hlt : (0 : Nat) < 1 := by omega
      simp [chainInterp, chainRho, natChainR, hne, hlt]
    · trivial
  · intro y hy hyr
    cases y with
    | core n =>
        refine ⟨Occ.core (n+1), ?_, ?_, ?_⟩
        · simp [chainInterp, chainDom]
        · have hne : n ≠ n+1 := by omega
          have hlt : n < n+1 := by omega
          simp [chainInterp, chainRho, natChainR, hne, hlt]
        · trivial
    | born s j =>
        simp [chainInterp, chainDom] at hy
        cases hy

theorem Cinf_satisfiable : Satisfiable Cinf := by
  exact ⟨chainInterp, chain_rcc5, Occ.core 0,
    (by simp [chainInterp, chainDom]), chain_sat_Cinf_root⟩

end Round19
