#!/usr/bin/env bash
set -euo pipefail

# Usage:
#   ./check_omega_fix.sh /path/to/Round19Transport.lean
#
# The script concatenates the trusted Round19Transport.lean source with
# OmegaUnfoldingFix.append.lean and asks Lean to check the combined file.
# It does not modify the source file.

SRC=${1:-Round19Transport.lean}
APPEND=${APPEND:-OmegaUnfoldingFix.append.lean}
OUT=${OUT:-Round19TransportOmegaFix.lean}

if ! command -v lean >/dev/null 2>&1; then
  echo "lean executable not found. Install/select Lean 4.31.0 with elan, then rerun." >&2
  exit 127
fi

if [ ! -f "$SRC" ]; then
  echo "source file not found: $SRC" >&2
  exit 2
fi
if [ ! -f "$APPEND" ]; then
  echo "append file not found: $APPEND" >&2
  exit 2
fi

cat "$SRC" "$APPEND" > "$OUT"
lean "$OUT"
