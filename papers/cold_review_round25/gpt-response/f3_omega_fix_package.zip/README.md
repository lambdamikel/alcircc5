# F3 omega-unfolding repair add-on

This package contains an append-only Lean formalization for the F3/blocking
repair discussed in the review conversation.

The current `generated_satisfiable` theorem in `Round19Transport.lean` is a
finite-plan theorem: its model domain is `existingBefore (buildCert K plan)` for
a finite `plan`.  That finite theorem is still correct, but it is not the right
interface for blocked tableaux that represent infinite models.

`OmegaUnfoldingFix.append.lean` adds the missing semantic interface:

- `PrefixLimit`: a stable omega-limit of finite certified prefixes.
- `prefixLimit_rcc5`: every such stable limit is an RCC5 interpretation frame.
- `omega_limit_satisfiable`: if the omega-limit also has a HintikkaP labelling
  at a root, it satisfies the concept.
- `Cinf`: the standard test concept
  `∃PP.⊤ ⊓ ∀PP.∃PP.⊤`.
- `chainCert n`: finite certified prefixes of the strict PP chain.
- `chainPrefixLimit`: an explicit omega-limit of those prefixes.
- `Cinf_satisfiable_from_prefixLimit`: the test concept is satisfiable through
  the omega-limit construction.

The add-on contains no `sorry`, `axiom`, or `admit`.  It is meant to be appended
after `Round19Transport.lean`.

## Check command

From a directory containing both `Round19Transport.lean` and
`OmegaUnfoldingFix.append.lean`:

```bash
./check_omega_fix.sh Round19Transport.lean
```

The container used to prepare this package did not have `lean` or `elan`
installed, so the file is not kernel-checked here.  The script is included so it
can be checked in the Lean 4.31.0 environment used by the project.
