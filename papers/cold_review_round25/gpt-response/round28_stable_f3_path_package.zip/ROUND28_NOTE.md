# Round 28 continuation: stable certificate-prefix runs

This supplement tightens the cyclic/F3 repair.

Earlier versions used an abstract omega-limit interface: if finite prefixes
localize every pair and triple, then the omega union is an RCC5 interpretation.
That was sound, but still too far from the actual certificate machine.

`Round28StableF3Path.append.lean` moves one level closer.  It defines
`StableCertifiedRun`, an infinite run of actual finite certificates:

```lean
structure StableCertifiedRun where
  C : Nat -> Cert
  rho0 : Occ -> Occ -> Atom
  wf : forall n, Wellformed (C n)
  scond : forall n, SCond (C n)
  mono_le : forall {n m x}, n <= m ->
    certStageDom (C n) x -> certStageDom (C m) x
  rho_agrees : forall n x y,
    certStageDom (C n) x -> certStageDom (C n) y -> x <> y ->
      rho0 x y = pairVal (C n) x y
```

The core theorem is:

```lean
theorem StableCertifiedRun.rcc5
    (R : StableCertifiedRun) (val : Nat -> Occ -> Prop) :
    RCC5Interp (R.interp val)
```

Thus the blocked-tableau intuition is represented as precise obligations:

1. every finite expansion prefix remains a valid finite certificate;
2. expanding preserves all old occurrences;
3. expanding never changes any old off-diagonal `pairVal`;
4. the Hintikka labelling holds on the omega union.

The theorem then gives a genuine ALCI_RCC5 model on the omega union.

The file also defines the tightened decision-grade target:

```lean
structure BoundedStableF3 where
  Code : Type
  enumerate : Concept -> List Code
  accept : Concept -> Code -> Bool
  realize : forall C0 code, accept C0 code = true -> StableRunRealization C0
  complete : forall C0, Satisfiable C0 -> FoundIn (accept C0) (enumerate C0)
```

and proves:

```lean
theorem decidability_from_bounded_stable_F3
    (H : Nonempty BoundedStableF3) :
    forall C0 : Concept, Decidable (Satisfiable C0)
```

## What this closes

This closes the earlier formal-interface looseness where an accepted cyclic code
could realize an arbitrary `DirectedRCC5Limit`.  Accepted codes must now realize
an omega run of the existing certificate machinery.

## What remains

The hard F3 theorem is now: construct an inhabitant of `BoundedStableF3`.
That means supplying a finite code type, finite enumeration, Boolean checker,
realization into `StableCertifiedRun`, and the completeness theorem that every
satisfiable concept has an accepted bounded code.

## Regression example

`Round28CinfStableRun.append.lean` adds the standard infinite-PP-chain example
in the tightened framework.  It uses growing core-only finite certificates:

```lean
def chainCert28 (n : Nat) : Cert
```

whose core nets are finite restrictions of the relation

```text
i = j  => EQ
i < j  => PP
i > j  => PPI
```

and packages them as:

```lean
def chainRun28 : StableCertifiedRun
```

The regression theorem is:

```lean
theorem Cinf28_satisfiable_from_stable_run : Satisfiable Cinf28
```

This is not the full F3 construction; it is a sanity check that the repaired
soundness interface handles the simplest blocked infinite branch.
