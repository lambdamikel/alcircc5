#!/usr/bin/env bash
set -euo pipefail

if ! command -v lean >/dev/null 2>&1; then
  echo "lean not found on PATH" >&2
  exit 127
fi

cat Round19Transport.lean Round28StableF3Path.append.lean Round28CinfStableRun.append.lean > Round19TransportRound28Cinf.lean
lean Round19TransportRound28Cinf.lean
