#!/usr/bin/env bash
set -euo pipefail

grep -RInE '\b(sorry|axiom|admit)\b' Round28StableF3Path.append.lean Round28CinfStableRun.append.lean && exit 1 || true
echo "No sorry/axiom/admit tokens found in Round28 Lean supplements"
