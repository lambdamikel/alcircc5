/-!
# Round28CinfStableRun.append.lean

Append after `Round19Transport.lean` and `Round28StableF3Path.append.lean`.

This is a regression example for the corrected blocked/cyclic reading.  The
finite pattern is the one-state instruction "make one more PP successor"; its
omega unfolding is represented here by the growing core-only certificates whose
core nets are finite restrictions of the natural-number PP chain.
-/

namespace Round19
open Atom

/-- The standard concept forcing an infinite PP-chain. -/
def Cinf28 : Concept :=
  Concept.and
    (Concept.ex Atom.pp Concept.top)
    (Concept.all Atom.pp (Concept.ex Atom.pp Concept.top))

/-- Strict natural-number RCC5 chain: equality on the diagonal, PP forward, PPI backward. -/
def natChainR28 (i j : Nat) : Atom :=
  if i = j then Atom.eq else if i < j then Atom.pp else Atom.ppi

@[simp] theorem natChainR28_self (i : Nat) : natChainR28 i i = Atom.eq := by
  unfold natChainR28
  simp

theorem natChainR28_eq_id {i j : Nat} :
    natChainR28 i j = Atom.eq -> i = j := by
  intro h
  unfold natChainR28 at h
  by_cases hij : i = j
  · exact hij
  · by_cases hlt : i < j
    · simp [hij, hlt] at h
    · simp [hij, hlt] at h

theorem natChainR28_conv (i j : Nat) :
    natChainR28 j i = conv (natChainR28 i j) := by
  unfold natChainR28
  by_cases hij : i = j
  · subst j
    simp
  · by_cases hlt : i < j
    · have hji : ¬ j = i := by omega
      have hjlt : ¬ j < i := by omega
      simp [hij, hlt, hji, hjlt]
    · have hjlt : j < i := by omega
      have hji : ¬ j = i := by omega
      simp [hij, hlt, hji, hjlt]

theorem natChainR28_comp (i j k : Nat) :
    natChainR28 i k ∈ comp (natChainR28 i j) (natChainR28 j k) := by
  unfold natChainR28
  by_cases hij : i = j
  · subst j
    simp
  · by_cases hjk : j = k
    · subst k
      simp
    · by_cases hik : i = k
      · subst k
        by_cases hlt : i < j
        · have hji : ¬ j = i := by omega
          have hjlt : ¬ j < i := by omega
          simp [hij, hlt, hji, hjlt]
        · have hjlt : j < i := by omega
          have hji : ¬ j = i := by omega
          simp [hij, hlt, hji, hjlt]
      · by_cases hijlt : i < j
        · by_cases hjklt : j < k
          · have hiklt : i < k := by omega
            simp [hij, hjk, hik, hijlt, hjklt, hiklt]
          · have hkltj : k < j := by omega
            by_cases hiklt : i < k
            · simp [hij, hjk, hik, hijlt, hjklt, hiklt]
            · have hklti : k < i := by omega
              simp [hij, hjk, hik, hijlt, hjklt, hiklt, hklti]
        · have hjlti : j < i := by omega
          by_cases hjklt : j < k
          · by_cases hiklt : i < k
            · simp [hij, hjk, hik, hijlt, hjklt, hjlti, hiklt]
            · have hklti : k < i := by omega
              simp [hij, hjk, hik, hijlt, hjklt, hjlti, hiklt, hklti]
          · have hkltj : k < j := by omega
            have hklti : k < i := by omega
            have hiklt : ¬ i < k := by omega
            simp [hij, hjk, hik, hijlt, hjklt, hjlti, hkltj, hklti, hiklt]

/-- The n-th finite certified prefix: n core points and no attachment steps. -/
def chainCert28 (n : Nat) : Cert where
  nCore := n
  coreNet := natChainR28
  templates := []
  steps := []
  f := fun _ _ _ _ => Atom.dr

theorem chainCert28_no_step {n i : Nat} (hi : i < (chainCert28 n).steps.length) :
    False := by
  simpa [chainCert28] using hi

theorem chainCert28_wf (n : Nat) : Wellformed (chainCert28 n) := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro i hi t ht; exact False.elim (chainCert28_no_step hi)
  · intro i hi t ht; exact False.elim (chainCert28_no_step hi)
  · intro i hi; exact False.elim (chainCert28_no_step hi)
  · intro i hi; exact False.elim (chainCert28_no_step hi)
  · intro i hi; exact False.elim (chainCert28_no_step hi)
  · intro i hi p q; exact False.elim (chainCert28_no_step hi)
  · intro i hi r1 r1' r2 r2' j h1 h2; exact False.elim (chainCert28_no_step hi)

theorem chainCert28_scond (n : Nat) : SCond (chainCert28 n) := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
  · intro c c'
    simpa [chainCert28] using natChainR28_conv c c'
  · intro c c' hc hc' hne heq
    exact hne (natChainR28_eq_id (by simpa [chainCert28] using heq))
  · intro c1 c2 c3 h1 h2 h3 h12 h13 h32
    simpa [chainCert28] using natChainR28_comp c1 c3 c2
  · intro i hi c c' hc hc' hne
    exact False.elim (chainCert28_no_step hi)
  · intro i hi x hx y hy jz hjz hxy hxz hyz
    exact False.elim (chainCert28_no_step hi)
  · intro i hi x hx jz hjz hxz
    exact False.elim (chainCert28_no_step hi)

/-- Monotonicity of the growing core-only prefixes. -/
theorem chainCert28_mono {n m : Nat} {x : Occ} (hnm : n <= m) :
    certStageDom (chainCert28 n) x -> certStageDom (chainCert28 m) x := by
  intro hx
  cases x with
  | core i =>
      have hi : i < n := by
        simpa [certStageDom, chainCert28] using
          (mem_existingBefore_core.mp hx)
      exact mem_existingBefore_core.mpr (by
        simp [chainCert28]
        omega)
  | born s j =>
      have hb := mem_existingBefore_born.mp hx
      have hs : s < (chainCert28 n).steps.length := hb.1
      exact False.elim (chainCert28_no_step hs)

/-- Agreement of every finite prefix with the omega chain relation. -/
theorem chainCert28_rho_agrees (n : Nat) (x y : Occ)
    (hx : certStageDom (chainCert28 n) x)
    (hy : certStageDom (chainCert28 n) y) (hxy : x ≠ y) :
    (fun x y => match x, y with
      | Occ.core i, Occ.core j => natChainR28 i j
      | _, _ => Atom.dr) x y = pairVal (chainCert28 n) x y := by
  cases x with
  | core i =>
      cases y with
      | core j => rfl
      | born s j =>
          have hb := mem_existingBefore_born.mp hy
          exact False.elim (chainCert28_no_step hb.1)
  | born s i =>
      have hb := mem_existingBefore_born.mp hx
      exact False.elim (chainCert28_no_step hb.1)

/-- The stable certified run generated by repeatedly adding one PP successor. -/
def chainRun28 : StableCertifiedRun where
  C := chainCert28
  rho0 := fun x y => match x, y with
    | Occ.core i, Occ.core j => natChainR28 i j
    | _, _ => Atom.dr
  wf := chainCert28_wf
  scond := chainCert28_scond
  mono_le := by
    intro n m x hnm hx
    exact chainCert28_mono hnm hx
  rho_agrees := chainCert28_rho_agrees

/-- The root concept is true at core 0 in the stable omega run. -/
theorem chainRun28_sat_root :
    sat (chainRun28.interp (fun _ _ => False)) (Occ.core 0) Cinf28 := by
  unfold Cinf28
  constructor
  · refine ⟨Occ.core 1, ?_, ?_, ?_⟩
    · exact ⟨2, mem_existingBefore_core.mpr (by simp [chainCert28])⟩
    · have hocc : (Occ.core 0) ≠ Occ.core 1 := by
        intro h; injection h with h01; omega
      have hnat : (0 : Nat) ≠ 1 := by omega
      have hlt : (0 : Nat) < 1 := by omega
      simp [StableCertifiedRun.interp, StableCertifiedRun.rho, chainRun28,
        natChainR28, hocc, hnat, hlt]
    · trivial
  · intro y hy hyr
    cases y with
    | core n =>
        refine ⟨Occ.core (n + 1), ?_, ?_, ?_⟩
        · rcases hy with ⟨m, hm⟩
          refine ⟨Nat.max m (n + 2), ?_⟩
          exact mem_existingBefore_core.mpr (by simp [chainCert28]; omega)
        · have hocc : (Occ.core n) ≠ Occ.core (n + 1) := by
            intro h; injection h with hn; omega
          have hnat : n ≠ n + 1 := by omega
          have hlt : n < n + 1 := by omega
          simp [StableCertifiedRun.interp, StableCertifiedRun.rho, chainRun28,
            natChainR28, hocc, hnat, hlt]
        · trivial
    | born s j =>
        rcases hy with ⟨m, hm⟩
        have hb := mem_existingBefore_born.mp hm
        exact False.elim (chainCert28_no_step hb.1)

/-- Regression theorem: the blocked/cyclic reading yields the required infinite model. -/
theorem Cinf28_satisfiable_from_stable_run : Satisfiable Cinf28 := by
  exact ⟨chainRun28.interp (fun _ _ => False),
    chainRun28.rcc5 (fun _ _ => False),
    Occ.core 0,
    ⟨1, mem_existingBefore_core.mpr (by simp [chainCert28])⟩,
    chainRun28_sat_root⟩

end Round19
