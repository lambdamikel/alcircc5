# ALCI_RCC5 Round 19--25 cold referee package

This package contains a formalized referee report and small supporting scripts.

Files:

- `alci_rcc5_round25_cold_review.pdf` - compiled report.
- `alci_rcc5_round25_cold_review.tex` - LaTeX source.
- `scripts/audit_static.py` - static source-location extractor and issue highlighter.
- `scripts/scat_degenerate_check.py` - concrete RCC5 calculation for the `SCat.net_r3` over-check.
- `scripts/build_report.sh` - rebuilds the PDF with `pdflatex`.
- `scripts/optional_lean_check.sh` - optional Lean kernel check of the submitted file, if Lean is installed.
- `snippets/source_index.txt` - generated output from `audit_static.py` on the submitted source.
- `snippets/scat_degenerate_output.txt` - generated output from `scat_degenerate_check.py`.

Line numbers in the report refer to the `Round19Transport.lean` file in the uploaded `cold_review_round25.zip` archive.

The report explicitly distinguishes the bounded-width/F3 mathematical assumption from the formalization-level finite-certificate defect: the latter is presented as an underformalized decision-ready interface for the former, not as a second independent RCC5 conjecture.

## Rebuild

From this directory:

```sh
./scripts/build_report.sh
```

## Static audit helper

```sh
python3 scripts/audit_static.py /path/to/Round19Transport.lean
python3 scripts/scat_degenerate_check.py
```

## Optional Lean check

```sh
./scripts/optional_lean_check.sh /path/to/Round19Transport.lean
```

The scripts do not prove or disprove the Lean development. They reproduce the source-location and table-calculation evidence used in the report.
