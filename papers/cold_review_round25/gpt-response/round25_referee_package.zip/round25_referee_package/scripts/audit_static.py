#!/usr/bin/env python3
"""Static source-location helper for the ALCI_RCC5 cold review.

This script is intentionally lightweight. It does not re-prove Lean. It reads a
Round19Transport.lean file, reports source locations for the definitions and
theorems discussed in the review, and flags the high-order certificate fields
that motivate the finite-code repair.
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path

NAMES = [
    "def conv",
    "def comp",
    "structure Template",
    "structure Cert",
    "structure Wellformed",
    "def certC",
    "structure SCond",
    "theorem frame_closed",
    "def certD",
    "structure SCat",
    "theorem scat_scond",
    "structure Catalog",
    "structure CatOk",
    "def PlanOk",
    "theorem build_wellformed",
    "theorem build_faithful",
    "theorem catalogue_soundness",
    "def certK",
    "inductive Concept",
    "structure Interp",
    "def sat",
    "structure Hintikka",
    "theorem truth_lemma",
    "structure RCC5Interp",
    "theorem certInterp_rcc5",
    "def Satisfiable",
    "theorem sat_from_hintikka",
    "theorem sample_satisfiable",
    "structure HintikkaP",
    "theorem model_hintikkaP",
    "theorem satisfiable_iff_hintikkaP",
    "theorem generated_satisfiable",
    "def CompletenessObligation",
    "theorem sample_satisfiable_ex",
]

FIELD_PATTERNS = [
    ("Template.net", re.compile(r"\bnet\s*:\s*TPort\s*\u2192\s*TPort\s*\u2192\s*Atom")),
    ("Cert.coreNet", re.compile(r"\bcoreNet\s*:\s*Nat\s*\u2192\s*Nat\s*\u2192\s*Atom")),
    ("Cert.f", re.compile(r"\bf\s*:\s*Nat\s*\u2192\s*\(Nat\s*\u2192\s*Atom\)")),
    ("Catalog.F", re.compile(r"\bF\s*:\s*Nat\s*\u2192\s*\(Nat\s*\u2192\s*Atom\)")),
]


def line_no(lines: list[str], needle: str) -> int | None:
    for i, line in enumerate(lines, 1):
        if needle in line:
            return i
    return None


def print_snippet(lines: list[str], start: int, end: int) -> None:
    for n in range(start, min(end, len(lines)) + 1):
        print(f"{n:5d}: {lines[n-1].rstrip()}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path, help="path to Round19Transport.lean")
    parser.add_argument("--snippets", action="store_true", help="print selected snippets")
    args = parser.parse_args()

    text = args.source.read_text(encoding="utf-8")
    lines = text.splitlines()

    print("Source:", args.source)
    print("Total lines:", len(lines))
    print()
    print("Named locations")
    print("---------------")
    for name in NAMES:
        loc = line_no(lines, name)
        print(f"{name:38s} {loc if loc is not None else 'not found'}")

    print()
    print("Higher-order / total-function field flags")
    print("-----------------------------------------")
    for label, pat in FIELD_PATTERNS:
        found = False
        for i, line in enumerate(lines, 1):
            if pat.search(line):
                print(f"{label:18s} line {i}: {line.strip()}")
                found = True
        if not found:
            print(f"{label:18s} not found by exact pattern")

    print()
    print("Degenerate SCat side-condition check")
    print("------------------------------------")
    tri_loc = line_no(lines, "  tri :")
    net_loc = line_no(lines, "  net_r3 :")
    print(f"SCond.tri starts at line {tri_loc}")
    print(f"SCat.net_r3 starts at line {net_loc}")
    if tri_loc is not None:
        print("SCond.tri snippet:")
        print_snippet(lines, tri_loc, tri_loc + 5)
    if net_loc is not None:
        print("SCat.net_r3 snippet:")
        print_snippet(lines, net_loc, net_loc + 5)
    print("Manual inspection target: SCat.net_r3 should exclude p=fresh_j and q=fresh_j, or require diagonal EQ normalization.")

    if args.snippets:
        print()
        print("Selected snippets")
        print("-----------------")
        for needle in ["structure Template", "structure Cert", "structure Catalog", "structure CatOk", "structure SCond", "structure SCat", "structure Interp", "def Satisfiable", "def CompletenessObligation"]:
            loc = line_no(lines, needle)
            if loc is not None:
                print()
                print(f">>> {needle} at line {loc}")
                print_snippet(lines, loc, loc + 18)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
