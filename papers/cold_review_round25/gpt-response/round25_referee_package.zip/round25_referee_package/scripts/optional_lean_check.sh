#!/usr/bin/env sh
set -eu
if [ "$#" -ne 1 ]; then
  echo "usage: $0 /path/to/Round19Transport.lean" >&2
  exit 2
fi
SRC=$1
if ! command -v lean >/dev/null 2>&1; then
  echo "lean not found on PATH" >&2
  exit 127
fi
lean "$SRC"
echo "Lean accepted $SRC"
