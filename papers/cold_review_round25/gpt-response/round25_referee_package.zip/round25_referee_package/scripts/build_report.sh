#!/usr/bin/env sh
set -eu
DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$DIR"
pdflatex -interaction=nonstopmode -halt-on-error alci_rcc5_round25_cold_review.tex >/tmp/alci_rcc5_report_pdflatex_1.log
pdflatex -interaction=nonstopmode -halt-on-error alci_rcc5_round25_cold_review.tex >/tmp/alci_rcc5_report_pdflatex_2.log
echo "Built $DIR/alci_rcc5_round25_cold_review.pdf"
