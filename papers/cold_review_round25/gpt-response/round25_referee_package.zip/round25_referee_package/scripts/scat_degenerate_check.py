#!/usr/bin/env python3
"""Concrete RCC5 table calculation for the SCat.net_r3 degeneracy finding.

The witness calculation is:
  net fresh0 fresh1 = PP
  net fresh1 fresh0 = PPI
  net fresh1 fresh1 = DR
SCat.net_r3 with p=fresh0, q=fresh1, j=1 requires:
  PP in comp(PP, conv(DR))
Since conv(DR)=DR and comp(PP,DR)=[DR], the requirement is false.
"""

from __future__ import annotations

CONV = {
    "EQ": "EQ",
    "PP": "PPI",
    "PPI": "PP",
    "PO": "PO",
    "DR": "DR",
}

COMP = {
    ("EQ", "EQ"): ["EQ"],
    ("EQ", "PP"): ["PP"],
    ("EQ", "PPI"): ["PPI"],
    ("EQ", "PO"): ["PO"],
    ("EQ", "DR"): ["DR"],
    ("PP", "EQ"): ["PP"],
    ("PPI", "EQ"): ["PPI"],
    ("PO", "EQ"): ["PO"],
    ("DR", "EQ"): ["DR"],
    ("PP", "PP"): ["PP"],
    ("PP", "PPI"): ["EQ", "PP", "PPI", "PO", "DR"],
    ("PP", "PO"): ["PP", "PO", "DR"],
    ("PP", "DR"): ["DR"],
    ("PPI", "PP"): ["EQ", "PP", "PPI", "PO"],
    ("PPI", "PPI"): ["PPI"],
    ("PPI", "PO"): ["PPI", "PO"],
    ("PPI", "DR"): ["PPI", "PO", "DR"],
    ("PO", "PP"): ["PP", "PO"],
    ("PO", "PPI"): ["PPI", "PO", "DR"],
    ("PO", "PO"): ["EQ", "PP", "PPI", "PO", "DR"],
    ("PO", "DR"): ["PPI", "PO", "DR"],
    ("DR", "PP"): ["PP", "PO", "DR"],
    ("DR", "PPI"): ["DR"],
    ("DR", "PO"): ["PP", "PO", "DR"],
    ("DR", "DR"): ["EQ", "PP", "PPI", "PO", "DR"],
}


def main() -> int:
    lhs = "PP"
    right_1 = "PP"
    diagonal = "DR"
    right_2 = CONV[diagonal]
    allowed = COMP[(right_1, right_2)]
    print("SCat.net_r3 degenerate-port calculation")
    print("lhs                      =", lhs)
    print("net p fresh_j            =", right_1)
    print("net q fresh_j            =", diagonal)
    print("conv (net q fresh_j)     =", right_2)
    print("comp(PP, conv(DR))       =", allowed)
    print("required membership true =", lhs in allowed)
    if lhs in allowed:
        raise SystemExit("unexpected: witness did not fail")
    print("Conclusion: the catalogue check rejects this diagonal choice.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
