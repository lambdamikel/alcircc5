# Support probes for the regular-cover route

This directory contains the Python probes and captured outputs used in the report `regular_cover_route_report.pdf`.

- `scripts/`: runnable Python probes, all dependency-free.
- `outputs/`: captured stdout for each probe.
- `reference/`: user-supplied Lean reference file used as context for the certificate architecture.

The probes are finite sanity checks, exhaustive small searches, and model-construction witnesses. They are not a substitute for Lean formalization, but each is intended to make the corresponding claim cross-checkable against the RCC5 composition table.

v2 adds scripts and outputs for WP81-WP83: ghost guards, uniform cross policies, and non-uniform cross-policy characterization.
