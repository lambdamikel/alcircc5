#!/usr/bin/env python3
"""
WP52: Periodic PO-unsafe matrices have regular downward-closed DR guards.

Two vertical PP chains are indexed by N with i <= i' meaning node i is a
proper part of/same as node i' (upward index).  A DR guard between chains must
be downward closed:

    D(i,j) and i0 <= i and j0 <= j imply D(i0,j0).

If U(i,j) marks PO-unsafe type pairs that must be guarded by DR, the least
DR guard is

    D(i,j) iff exists i' >= i, j' >= j with U(i',j').

This probe checks that when U is ultimately periodic in both coordinates,
D is ultimately periodic/regular and can be computed by a finite residue test.
It supports the regular PO-guard route: periodic vertical components do not
create nonregular DR-boundary obligations.
"""
from itertools import product
import random

def u_val(i, j, pre_i, per_i, pre_j, per_j, table_prefix, table_tail):
    # table_prefix handles finite rectangle before one coordinate enters tail;
    # table_tail is indexed by tail residues once both are in tail.
    if i >= pre_i and j >= pre_j:
        return table_tail[((i - pre_i) % per_i, (j - pre_j) % per_j)]
    return table_prefix.get((i,j), False)

def brute_D(i, j, N, U):
    return any(U(ip,jp) for ip in range(i,N) for jp in range(j,N))

def finite_D(i, j, pre_i, per_i, pre_j, per_j, U, Ncheck=80):
    """Finite residue formula for the least down-closure on a large finite prefix.

    For an ultimately periodic U, if both coordinates are in the tail and any
    unsafe tail residue occurs at all, then from every sufficiently lower pair
    whose coordinates can see that residue in the future, D holds. Since each
    residue recurs unboundedly, every tail position can see every tail residue
    in both coordinates. Thus the tail-tail D value is constant: whether U has
    any unsafe tail-tail cell. Finite prefix/tail strips are computed by looking
    at one full future period plus the finite prefix; this is enough because
    beyond the period residues recur.
    """
    # If there is any unsafe future cell in a sufficiently large window, D holds.
    # The window bound covers finite prefix plus two periods beyond max(i,j).
    bound_i = max(i, pre_i) + 2*per_i + pre_i + 2
    bound_j = max(j, pre_j) + 2*per_j + pre_j + 2
    # Include finite prefix/tail interactions up to the explicit Ncheck sanity bound.
    bound_i = max(bound_i, min(Ncheck, pre_i + 2*per_i + 10))
    bound_j = max(bound_j, min(Ncheck, pre_j + 2*per_j + 10))
    return any(U(ip,jp) for ip in range(i,bound_i) for jp in range(j,bound_j))

def run_case(seed, pre_i=3, per_i=2, pre_j=2, per_j=3, N=40):
    random.seed(seed)
    # Random finite prefix values for cells where at least one coordinate is pre-tail.
    table_prefix = {}
    for i in range(pre_i + per_i):
        for j in range(pre_j + per_j):
            if i < pre_i or j < pre_j:
                table_prefix[(i,j)] = random.random() < 0.25
    # Random tail residue matrix.
    table_tail = {}
    for ri in range(per_i):
        for rj in range(per_j):
            table_tail[(ri,rj)] = random.random() < 0.25
    U = lambda i,j: u_val(i,j,pre_i,per_i,pre_j,per_j,table_prefix,table_tail)
    errors=[]
    for i,j in product(range(N), repeat=2):
        b = brute_D(i,j,N,U)
        f = finite_D(i,j,pre_i,per_i,pre_j,per_j,U,Ncheck=N)
        # brute_D on finite N can miss future periodic unsafe cells beyond N, so only
        # compare against a larger brute window for fairness.
        b2 = brute_D(i,j,4*N,U)
        if f != b2:
            errors.append((i,j,f,b2))
            break
    # Compute tail-tail collapse.
    tail_has_unsafe = any(table_tail.values())
    tail_values = set()
    for i in range(pre_i, pre_i+2*per_i):
        for j in range(pre_j, pre_j+2*per_j):
            tail_values.add(finite_D(i,j,pre_i,per_i,pre_j,per_j,U,Ncheck=N))
    return errors, tail_has_unsafe, tail_values, table_tail

def main():
    print("WP52: periodic PO-unsafe obligations -> regular downward DR guard")
    print("Least guard: D(i,j) iff some unsafe U(i',j') occurs northeast of (i,j).")
    print("For ultimately periodic U, D is regular; in the tail-tail quadrant it collapses to a constant.")
    for seed in range(10):
        errors, tail_has, tail_values, tail_table = run_case(seed)
        print(f"seed={seed}: errors={len(errors)} tail_has_unsafe={tail_has} tail_D_values={sorted(tail_values)}")
        if errors:
            print("  first error", errors[0])
            raise SystemExit(1)
    print("PASS: tested periodic unsafe matrices have finite/residue-computable downward guards.")
    print("Interpretation: nonregular PO avoidance cannot arise from two ultimately periodic vertical components alone.")

if __name__ == '__main__':
    main()
