#!/usr/bin/env python3
"""
WP75: one-old trace interfaces over-accept; pair-aware trace interfaces are sufficient
for RCC5 closure against a finite fresh block.

The probe derives the RCC5 composition table from finite set semantics, exhibits a
small one-old over-acceptance witness, and checks the pair-aware criterion for a
single-fresh block.
"""
from itertools import combinations, product

ATOMS = ["EQ", "PP", "PPI", "PO", "DR"]
PROPER = ["PP", "PPI", "PO", "DR"]
INV = {"EQ":"EQ", "PP":"PPI", "PPI":"PP", "PO":"PO", "DR":"DR"}

def rel(A,B):
    if A == B: return "EQ"
    if A < B: return "PP"
    if A > B: return "PPI"
    if A.isdisjoint(B): return "DR"
    return "PO"

def nonempty_subsets(n):
    U = list(range(n))
    out=[]
    for r in range(1,n+1):
        for c in combinations(U,r):
            out.append(frozenset(c))
    return out

def derive_comp(n=5):
    regs=nonempty_subsets(n)
    comp={(a,b):set() for a in ATOMS for b in ATOMS}
    for X,Y,Z in product(regs, repeat=3):
        comp[(rel(X,Y), rel(Y,Z))].add(rel(X,Z))
    return comp

COMP=derive_comp()

def comp(a,b):
    return COMP[(a,b)]

def closed_triple(rxy, ryz, rxz):
    """Check all three relevant ordered composition constraints for x,y,z."""
    labels={('x','y'):rxy, ('y','x'):INV[rxy], ('y','z'):ryz, ('z','y'):INV[ryz], ('x','z'):rxz, ('z','x'):INV[rxz]}
    objs=['x','y','z']
    for a,b,c in product(objs, repeat=3):
        if a==b or b==c or a==c:
            continue
        if labels[(a,c)] not in comp(labels[(a,b)], labels[(b,c)]):
            return False, (a,b,c, labels[(a,b)], labels[(b,c)], labels[(a,c)], comp(labels[(a,b)], labels[(b,c)]))
    return True, None

def pair_aware_ok(old_rel, trace_x, trace_y, fresh_atoms=None):
    """old_rel = rho(x,y); traces are tuples rho(x,f_i), rho(y,f_i)."""
    k=len(trace_x)
    assert len(trace_y)==k
    # For every fresh port f_i, check all triples x,y,f_i.
    for i in range(k):
        ok, why = closed_triple(old_rel, trace_y[i], trace_x[i])
        # closed_triple arguments are rxy, ryz, rxz, i.e. x-y, y-f, x-f.
        if not ok:
            return False, (i, why)
    return True, None

def block_one_old_ok(trace, fresh_internal=None):
    # For one fresh point and no internal fresh-fresh constraints, any proper atom is okay.
    return all(t in PROPER for t in trace)

def main():
    print("WP75 pair-aware trace interface")
    print("Selected composition cells:")
    for a,b in [("PP","DR"),("PO","PP"),("DR","PO"),("PPI","PO")]:
        print(f"  {a};{b} = {sorted(comp(a,b))}")

    print("\n=== One-old interface over-acceptance witness ===")
    # Old pair x PP y. y is DR from fresh b. x is claimed PO to b.
    old_rel="PP"
    trace_x=("PO",)
    trace_y=("DR",)
    print(f"old relation x-y = {old_rel}")
    print(f"individual trace x->b = {trace_x[0]} valid_one_old={block_one_old_ok(trace_x)}")
    print(f"individual trace y->b = {trace_y[0]} valid_one_old={block_one_old_ok(trace_y)}")
    ok, why=pair_aware_ok(old_rel, trace_x, trace_y)
    print(f"pair-aware joint check: {ok}")
    if not ok:
        i, detail=why
        a,b,c,rab,rbc,rac,allowed=detail
        print("  rejecting triple:", detail)
        print(f"  reason: {rab};{rbc} allows {sorted(allowed)}, but {rac} was assigned")

    print("\n=== Pair-aware table for one fresh port ===")
    for old_rel in PROPER:
        total=0; okc=0
        bad_samples=[]
        for tx,ty in product(PROPER, repeat=2):
            total+=1
            ok,_=pair_aware_ok(old_rel,(tx,),(ty,))
            if ok: okc+=1
            elif len(bad_samples)<3: bad_samples.append((tx,ty))
        print(f"old_rel {old_rel:3s}: allowed trace-pairs {okc:2d}/{total}; bad samples {bad_samples}")

    print("\n=== Sufficiency sanity check for one fresh port ===")
    bad=0
    for old_rel,tx,ty in product(PROPER,PROPER,PROPER):
        ok,_=pair_aware_ok(old_rel,(tx,),(ty,))
        closed,_=closed_triple(old_rel,ty,tx)
        if ok != closed:
            bad+=1
            print("mismatch", old_rel, tx, ty, ok, closed)
            break
    print(f"pair-aware criterion exactly matches RCC5 triple closure for two old + one fresh: mismatches={bad}")

    print("\nConclusion:")
    print("  A one-old trace automaton is not enough: individually valid old-to-fresh traces can be jointly inconsistent.")
    print("  Adding the old-old pair colour gives a finite pair-aware transition condition, and for RCC5's ternary composition this is the right local check for fixed blocks.")

if __name__ == '__main__':
    main()
