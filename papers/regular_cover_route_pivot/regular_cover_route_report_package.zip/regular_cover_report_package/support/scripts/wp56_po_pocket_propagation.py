#!/usr/bin/env python3
"""
WP56: PO-pocket propagation rules for the regular-cover route.

Derives the RCC5 composition table from finite set semantics and prints the
allowed relation domains for x-z when x PO y and y R z, then the remaining
options when x/z is PO-unsafe (PO is forbidden by endpoint types).
"""
from itertools import combinations, product

ATOMS = ["EQ", "PP", "PPI", "PO", "DR"]
PROPER = ["PP", "PPI", "PO", "DR"]

def rel(a, b):
    a, b = set(a), set(b)
    if a == b:
        return "EQ"
    if a < b:
        return "PP"
    if a > b:
        return "PPI"
    if a.isdisjoint(b):
        return "DR"
    return "PO"

def powerset_nonempty(base):
    base = list(base)
    for r in range(1, len(base)+1):
        for comb in combinations(base, r):
            yield frozenset(comb)

# small universe large enough for RCC5 composition cells
U = range(5)
regions = list(powerset_nonempty(U))
comp = {(r,s): set() for r in ATOMS for s in ATOMS}
for x,y,z in product(regions, repeat=3):
    comp[(rel(x,y), rel(y,z))].add(rel(x,z))

# sanity: show full table in compact form for proper atoms only
print("RCC5 proper-atom composition cells involving PO as first or second leg:")
for r in ATOMS:
    if r == "EQ":
        continue
    print(f"  PO ; {r:3s} = {sorted(comp[('PO', r)])}")
for r in ATOMS:
    if r == "EQ":
        continue
    print(f"  {r:3s} ; PO = {sorted(comp[(r, 'PO')])}")

print("\nProtected PO pocket rule: x PO y and y R z. If x/z is PO-unsafe, remove PO.")
for R in PROPER:
    dom = set(comp[("PO", R)]) - {"EQ"}
    no_po = dom - {"PO"}
    print(f"  x PO y, y {R:3s} z: x-z in {sorted(dom)}; if PO forbidden -> {sorted(no_po)}")

print("\nSymmetric/converse pocket rule: x R y and y PO z. If x/z is PO-unsafe, remove PO.")
for R in PROPER:
    dom = set(comp[(R, "PO")]) - {"EQ"}
    no_po = dom - {"PO"}
    print(f"  x {R:3s} y, y PO z: x-z in {sorted(dom)}; if PO forbidden -> {sorted(no_po)}")

# Flag deterministic after forbidding PO.
print("\nCells where forbidding PO makes the result singleton:")
for left in PROPER:
    for right in PROPER:
        if left == "PO" or right == "PO":
            dom = set(comp[(left, right)]) - {"EQ"}
            no_po = dom - {"PO"}
            if len(no_po) == 1 and "PO" in dom:
                print(f"  {left:3s};{right:3s}: {sorted(dom)} -> {sorted(no_po)}")

print("\nInterpretation examples:")
print("  x PO y and y PP z gives {PO,PP}; if x/z may not be PO, then x PP z is forced.")
print("  x PP y and y PO z gives {DR,PO,PP}; if x/z may not be PO, a choice remains: DR or PP.")
print("  x PO y and y DR z gives {DR,PO,PPI}; if x/z may not be PO, a choice remains: DR or PPI.")
