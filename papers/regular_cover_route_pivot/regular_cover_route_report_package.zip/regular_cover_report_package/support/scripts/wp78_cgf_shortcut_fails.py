#!/usr/bin/env python3
"""
WP78: sanity check for the coloured-triangle/CGF shortcut.

The point is not to rediscover that ALCI_RCC5 can force infinite PP-depth;
that is known. The point is to prevent a false proof: if the coloured-triangle
translation could be fed directly to an ordinary guarded/clique-guarded finite
model property theorem, it would incorrectly yield finite models for strict
PP-tower concepts.

We check finite strict partial orders for the minimal PP-tower condition:
there is a root r such that (i) r has a PP successor and (ii) every PP-successor
of r has a PP successor. Because PP is transitive, this means the upset above r
has no maximal element, impossible in a finite strict poset.
"""
from itertools import product


def transitive_closure(n, edges):
    reach = [[False]*n for _ in range(n)]
    for i,j in edges:
        reach[i][j] = True
    changed = True
    while changed:
        changed = False
        for i in range(n):
            for j in range(n):
                if reach[i][j]:
                    rowj = reach[j]
                    rowi = reach[i]
                    for k in range(n):
                        if rowj[k] and not rowi[k]:
                            rowi[k] = True
                            changed = True
    return reach


def is_strict_poset(rel):
    n = len(rel)
    for i in range(n):
        if rel[i][i]:
            return False
    for i in range(n):
        for j in range(n):
            if rel[i][j]:
                for k in range(n):
                    if rel[j][k] and not rel[i][k]:
                        return False
    return True


def tower_condition(rel, r):
    n = len(rel)
    # root has a successor
    if not any(rel[r][y] for y in range(n)):
        return False
    # every strict successor of root has a strict successor
    for y in range(n):
        if rel[r][y]:
            if not any(rel[y][z] for z in range(n)):
                return False
    return True


def enumerate_posets(n):
    pairs = [(i,j) for i in range(n) for j in range(n) if i != j]
    # exhaustive only up to n=4; larger combinatorics explode
    for bits in product([0,1], repeat=len(pairs)):
        edges = [p for bit,p in zip(bits,pairs) if bit]
        rel = transitive_closure(n, edges)
        if is_strict_poset(rel):
            yield rel


def direct_no_finite_proof(rel, r):
    # In any finite strict poset, every nonempty finite subset has a maximal element.
    upset = [y for y in range(len(rel)) if rel[r][y]]
    maxes = []
    for y in upset:
        if not any(rel[y][z] for z in upset):
            maxes.append(y)
    return upset, maxes


def main():
    print("WP78: CGF/finite-model shortcut sanity check")
    print("Searching finite strict PP-posets for the tower condition.")
    for n in range(1,5):
        posets = 0
        witnesses = 0
        for rel in enumerate_posets(n):
            posets += 1
            for r in range(n):
                if tower_condition(rel, r):
                    witnesses += 1
                    print("Unexpected finite tower model", n, r)
                    return
        print(f"n={n}: posets={posets} tower_models=0")
    print("PASS: no finite strict PP-poset satisfies the PP-tower condition (as expected).")
    # Show the elementary reason on a sample chain.
    rel = [[False]*4 for _ in range(4)]
    for i in range(4):
        for j in range(i+1,4):
            rel[i][j] = True
    upset, maxes = direct_no_finite_proof(rel, 0)
    print("sample finite chain upset above 0:", upset, "maximal elements:", maxes)
    print("Conclusion: any argument importing a finite-model-property theorem directly")
    print("for the coloured-triangle presentation is suspect; the correct object is a")
    print("regular cover/unfolding, not a finite model quotient.")

if __name__ == '__main__':
    main()
