#!/usr/bin/env python3
"""
WP77: RCC5 composition as forbidden coloured triangles.

This probe is intentionally syntactic.  It derives the RCC5 composition table
from finite-set semantics over a small universe, then emits the universal
forbidden-triangle clauses

    not (R(x,y) and S(y,z) and T(x,z))

for every T not in comp(R,S).  Each such clause is clique-guarded by the three
binary atoms on the three variable-pairs.  This supports the meta-reduction of
ALCI_RCC5 into a finite edge-coloured forbidden-triangle / clique-guarded-style
constraint problem.
"""
from itertools import combinations, product

ATOMS = ["EQ", "PP", "PPI", "PO", "DR"]
PROPER = ["PP", "PPI", "PO", "DR"]
CONV = {"EQ":"EQ", "PP":"PPI", "PPI":"PP", "PO":"PO", "DR":"DR"}

def rel(a,b):
    A, B = set(a), set(b)
    if A == B:
        return "EQ"
    if A < B:
        return "PP"
    if A > B:
        return "PPI"
    if A.isdisjoint(B):
        return "DR"
    return "PO"

def derive_comp():
    U = range(4)
    regs = []
    for r in range(1, 1 << len(U)):
        regs.append(frozenset(i for i in U if (r >> i) & 1))
    comp = {(r,s): set() for r in ATOMS for s in ATOMS}
    for a,b,c in product(regs, repeat=3):
        comp[(rel(a,b), rel(b,c))].add(rel(a,c))
    return {k: tuple(sorted(v, key=ATOMS.index)) for k,v in comp.items()}

def is_clique_guarded_clause(R,S,T):
    # variables x,y,z; atoms Rxy, Syz, Txz cover all three pairs.
    pairs = {tuple(sorted(p)) for p in [("x","y"),("y","z"),("x","z")]}
    return pairs == {("x","y"),("x","z"),("y","z")}

def main():
    comp = derive_comp()
    forbidden = []
    for R,S in product(ATOMS, repeat=2):
        allowed = set(comp[(R,S)])
        for T in ATOMS:
            if T not in allowed:
                forbidden.append((R,S,T))
    print("RCC5 composition as forbidden coloured triangles")
    print(f"atoms={ATOMS}")
    print(f"number of composition cells={len(ATOMS)**2}")
    print(f"number of forbidden triangle colour triples={len(forbidden)}")
    print()
    print("Determining singleton cells among proper atoms:")
    for R,S in product(PROPER, repeat=2):
        out = comp[(R,S)]
        if len(out) == 1:
            print(f"  {R};{S} -> {out[0]}")
    print()
    print("First 30 forbidden triangle clauses:")
    for R,S,T in forbidden[:30]:
        ok = is_clique_guarded_clause(R,S,T)
        print(f"  not ({R}(x,y) and {S}(y,z) and {T}(x,z))  clique_guarded={ok}")
    print()
    bad = [(R,S,T) for R,S,T in forbidden if not is_clique_guarded_clause(R,S,T)]
    print(f"forbidden clauses failing pair-clique coverage: {len(bad)}")
    print()
    print("Important caveat:")
    print("  The composition clauses are clique-guarded once the edge-colouring is total.")
    print("  The exact-one-colour/totality condition for every ordered pair is a separate")
    print("  complete-edge-colouring requirement; it should be built into certificates or")
    print("  handled by a suitable coloured-graph/guarded-fragment theorem, not ignored.")

if __name__ == "__main__":
    main()
