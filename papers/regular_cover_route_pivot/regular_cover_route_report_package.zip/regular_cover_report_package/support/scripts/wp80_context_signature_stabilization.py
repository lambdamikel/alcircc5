#!/usr/bin/env python3
"""
WP80: context-signature stabilization for fixed recursive extension bases.

For a fixed recursive block, take finite prefixes and compute the old context
signature relative to the current two-port boundary.  The signature consists of:
  * trace classes: RCC5 rows from old occurrences to the boundary ports;
  * pair-domain data between trace classes.

This illustrates the theorem-shaped fact that, for a fixed finite basis and
fixed finite boundary, recursive old-context propagation is finite-state.
"""
from itertools import combinations, product

ATOMS = ["EQ", "PP", "PPI", "PO", "DR"]
PROPER = ["PP", "PPI", "PO", "DR"]
CONV = {"EQ":"EQ", "PP":"PPI", "PPI":"PP", "PO":"PO", "DR":"DR"}

# Derive RCC5 composition table from finite set semantics.
def rel(a,b):
    if a == b: return "EQ"
    if a < b: return "PP"
    if b < a: return "PPI"
    if a.isdisjoint(b): return "DR"
    return "PO"

def derive_comp(n=4):
    U = tuple(range(n))
    subs = []
    for mask in range(1, 1<<n):
        subs.append(frozenset(i for i in U if mask>>i & 1))
    comp = {(r,s): set() for r in ATOMS for s in ATOMS}
    for a,b,c in product(subs, repeat=3):
        comp[(rel(a,b), rel(b,c))].add(rel(a,c))
    return comp
COMP = derive_comp(4)

def transitive_closure(objs, edges):
    less = {(x,y): False for x in objs for y in objs}
    for x,y in edges:
        if x != y:
            less[(x,y)] = True
    changed = True
    while changed:
        changed = False
        for x in objs:
            for y in objs:
                if less[(x,y)]:
                    for z in objs:
                        if less[(y,z)] and not less[(x,z)]:
                            less[(x,z)] = True
                            changed = True
    return less

def downward_disj_closure(objs, less, seeds):
    disj = {(x,y): False for x in objs for y in objs}
    for x,y in seeds:
        if x != y:
            disj[(x,y)] = disj[(y,x)] = True
    leq = lambda a,b: a == b or less[(a,b)]
    changed = True
    while changed:
        changed = False
        for x,y in list(product(objs, repeat=2)):
            if disj[(x,y)]:
                for xp,yp in product(objs, repeat=2):
                    if leq(xp,x) and leq(yp,y) and xp != yp and not disj[(xp,yp)]:
                        disj[(xp,yp)] = disj[(yp,xp)] = True
                        changed = True
    return disj

def atom(x,y,less,disj):
    if x == y: return "EQ"
    if less[(x,y)]: return "PP"
    if less[(y,x)]: return "PPI"
    if disj[(x,y)]: return "DR"
    return "PO"

def check_closed(objs, less, disj):
    errs = []
    for x,y,z in product(objs, repeat=3):
        r = atom(x,y,less,disj)
        s = atom(y,z,less,disj)
        t = atom(x,z,less,disj)
        if t not in COMP[(r,s)]:
            errs.append((x,y,z,r,s,t,sorted(COMP[(r,s)])))
            if len(errs) > 10:
                return errs
    return errs

def signature(objs, less, disj, boundary):
    old = [o for o in objs if o not in boundary]
    def tr(o):
        return tuple(atom(o,b,less,disj) for b in boundary)
    classes = {}
    for o in old:
        classes.setdefault(tr(o), []).append(o)
    domains = {}
    trs = sorted(classes.keys())
    for a in trs:
        for b in trs:
            vals = set()
            for x in classes[a]:
                for y in classes[b]:
                    vals.add(atom(x,y,less,disj))
            domains[(a,b)] = tuple(sorted(vals))
    fp = (tuple(trs), tuple(sorted((k,v) for k,v in domains.items())))
    return classes, domains, fp

def build_interval(n):
    # Connectors C[-1], C[0],...,C[n-1]; pockets A_i,B_i between C[i-1] and C[i].
    objs = ["C-1"]
    order = []
    disj = []
    for i in range(n):
        A,B,Cprev,C = f"A{i}", f"B{i}", f"C{i-1}", f"C{i}"
        objs.extend([A,B,C])
        order += [(Cprev,A),(Cprev,B),(A,C),(B,C)]
    objs = list(dict.fromkeys(objs))
    less = transitive_closure(objs, order)
    dis = downward_disj_closure(objs, less, disj)
    return objs, less, dis

def build_separated_star(n):
    # Connectors C[-1], C[0],...,C[n-1]; pockets A_i,B_i,D_i under C_i.
    # C[i-1] < A_i < C_i; B_i < C_i; D_i < C_i;
    # C[i-1] # B_i, C[i-1] # D_i, B_i # D_i.
    objs = ["C-1"]
    order = []
    disj = []
    for i in range(n):
        A,B,D,Cprev,C = f"A{i}", f"B{i}", f"D{i}", f"C{i-1}", f"C{i}"
        objs.extend([A,B,D,C])
        order += [(Cprev,A),(A,C),(B,C),(D,C)]
        disj += [(Cprev,B),(Cprev,D),(B,D)]
    objs = list(dict.fromkeys(objs))
    less = transitive_closure(objs, order)
    dis = downward_disj_closure(objs, less, disj)
    return objs, less, dis

def summarize(name, builder, maxn=10):
    print(f"=== {name} ===")
    last_fp = None
    first_stable = None
    for n in range(1, maxn+1):
        objs, less, dis = builder(n)
        errs = check_closed(objs, less, dis)
        if n == 1:
            boundary = ("C-1", "C0")
        else:
            boundary = (f"C{n-2}", f"C{n-1}")
        classes, domains, fp = signature(objs, less, dis, boundary)
        changed = (fp != last_fp)
        if not changed and first_stable is None:
            first_stable = n-1
        last_fp = fp
        print(f"n={n:2d}: objs={len(objs):2d} closed_errors={len(errs):2d} boundary={boundary} trace_classes={len(classes):2d} domain_entries={len(domains):3d} changed={changed}")
        for tr, members in sorted(classes.items()):
            sample = ','.join(members[:3]) + ("..." if len(members) > 3 else "")
            print(f"      trace {tr}: count={len(members):2d} sample={sample}")
    print()

if __name__ == "__main__":
    summarize("interval protected-PO pocket chain (WP67 style)", build_interval, 8)
    summarize("separated-star multi-witness chain (WP68 style)", build_separated_star, 8)
    print("Conclusion:")
    print("  With a fixed two-port boundary, old contexts in these recursive bases collapse")
    print("  to finitely many trace classes plus pair-domain data; the signature stabilizes")
    print("  after a short prefix.  This is evidence for the fixed-basis finite-state theorem,")
    print("  not a proof of bounded basis existence for all concepts.")
