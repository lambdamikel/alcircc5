#!/usr/bin/env python3
"""
WP79: Pair-colour transition algebra for a fixed extension block.

This probe illustrates the finite transition object suggested by the coherent
regular-cover route.  For a fixed finite block with inherited boundary ports I
and fresh ports F, a single old occurrence is summarized by its boundary trace
and fresh trace.  Two old occurrences also require their old-old atom.  The
admissible pair transitions form a finite table.

The example block is the prefix interval protected-PO pocket:
    L < A, L < B, A < C, B < C, A PO B
where < means PP.  This is the WP67/WP74 interval block.
"""
from itertools import product, combinations

ATOMS = ["EQ", "PP", "PPI", "PO", "DR"]
PROPER = ["PP", "PPI", "PO", "DR"]
CONV = {"EQ":"EQ", "PP":"PPI", "PPI":"PP", "PO":"PO", "DR":"DR"}


def rel(a, b):
    if a == b:
        return "EQ"
    if a < b:
        return "PP"
    if b < a:
        return "PPI"
    if a.isdisjoint(b):
        return "DR"
    return "PO"


def derive_comp():
    sets = [frozenset(s) for mask in range(1, 1 << 4)
            for s in [{i for i in range(4) if (mask >> i) & 1}]]
    comp = {(r,s): set() for r in ATOMS for s in ATOMS}
    for x in sets:
        for y in sets:
            r = rel(x,y)
            for z in sets:
                s = rel(y,z)
                t = rel(x,z)
                comp[(r,s)].add(t)
    return comp

COMP = derive_comp()


def comp_ok(rxy, ryz, rxz):
    return rxz in COMP[(rxy, ryz)]

class Net:
    def __init__(self, nodes):
        self.nodes = list(nodes)
        self.r = {}
        for x in self.nodes:
            self.r[(x,x)] = "EQ"
    def set(self, x, y, a):
        self.r[(x,y)] = a
        self.r[(y,x)] = CONV[a]
    def get(self, x, y):
        return self.r[(x,y)]
    def closed_errors(self):
        errs = []
        for x in self.nodes:
            for y in self.nodes:
                for z in self.nodes:
                    if not comp_ok(self.get(x,y), self.get(y,z), self.get(x,z)):
                        errs.append((x,y,z,self.get(x,y),self.get(y,z),self.get(x,z),COMP[(self.get(x,y),self.get(y,z))]))
        return errs


def interval_block():
    # L<A, L<B, A<C, B<C, A PO B.  Transitive closure gives L<C.
    nodes = ["L", "A", "B", "C"]
    n = Net(nodes)
    n.set("L", "A", "PP")
    n.set("L", "B", "PP")
    n.set("A", "C", "PP")
    n.set("B", "C", "PP")
    n.set("L", "C", "PP")
    n.set("A", "B", "PO")
    return n


def add_one_old(block, r_xL, t_xF):
    # t_xF is dict fresh -> atom x->fresh for F=[A,B,C]
    nodes = ["x"] + block.nodes
    n = Net(nodes)
    # copy block
    for i,u in enumerate(block.nodes):
        for v in block.nodes[i+1:]:
            n.set(u,v,block.get(u,v))
    n.set("x", "L", r_xL)
    for f,a in t_xF.items():
        n.set("x", f, a)
    return n


def one_old_states(block):
    F = ["A", "B", "C"]
    states = []
    for rL in PROPER:
        for vals in product(PROPER, repeat=len(F)):
            tr = dict(zip(F, vals))
            n = add_one_old(block, rL, tr)
            if not n.closed_errors():
                states.append((rL, tuple(vals)))
    return states


def add_two_old(block, state_x, state_y, r_xy):
    F = ["A", "B", "C"]
    nodes = ["x", "y"] + block.nodes
    n = Net(nodes)
    for i,u in enumerate(block.nodes):
        for v in block.nodes[i+1:]:
            n.set(u,v,block.get(u,v))
    r_xL, vals_x = state_x
    r_yL, vals_y = state_y
    n.set("x", "L", r_xL)
    n.set("y", "L", r_yL)
    n.set("x", "y", r_xy)
    for f,a in zip(F, vals_x):
        n.set("x", f, a)
    for f,a in zip(F, vals_y):
        n.set("y", f, a)
    return n


def pair_aware_table(block, states):
    valid = []
    rejected_samples = []
    total = 0
    by_oldrel = {r: 0 for r in PROPER}
    for sx in states:
        for sy in states:
            for rxy in PROPER:
                total += 1
                n = add_two_old(block, sx, sy, rxy)
                errs = n.closed_errors()
                if not errs:
                    valid.append((sx, sy, rxy))
                    by_oldrel[rxy] += 1
                elif len(rejected_samples) < 8:
                    # show first error involving x,y and a block node if possible
                    chosen = None
                    for e in errs:
                        if "x" in e[:3] and "y" in e[:3]:
                            chosen = e; break
                    rejected_samples.append((sx, sy, rxy, chosen or errs[0]))
    return valid, total, by_oldrel, rejected_samples


def signature_state(s):
    rL, vals = s
    return f"L:{rL} F(A,B,C):{vals}"


def main():
    print("WP79 pair-colour transition algebra for an interval PO-pocket block")
    block = interval_block()
    errs = block.closed_errors()
    print(f"block closed={not errs} errors={len(errs)}")
    print("block relations:")
    for u,v in combinations(block.nodes,2):
        print(f"  {u}->{v} = {block.get(u,v)}")
    states = one_old_states(block)
    print(f"\none-old transition states: {len(states)} / raw {4**4}")
    by_boundary = {r: [] for r in PROPER}
    for s in states:
        by_boundary[s[0]].append(s)
    for r, ss in by_boundary.items():
        print(f"  boundary {r}: {len(ss)} fresh traces")
        for s in ss[:5]:
            print(f"    {signature_state(s)}")
        if len(ss) > 5:
            print("    ...")
    valid, total, by_oldrel, samples = pair_aware_table(block, states)
    print(f"\npair-aware transition table: {len(valid)} / raw {total}")
    for r in PROPER:
        print(f"  old-old {r}: {by_oldrel[r]} valid state-pairs")
    print("\nrejection samples showing why pair awareness is needed:")
    for sx, sy, rxy, e in samples[:5]:
        x,y,z,r1,r2,r3,allowed = e
        print(f"  oldrel {rxy}; sx=({signature_state(sx)}); sy=({signature_state(sy)})")
        print(f"    bad triple {x},{y},{z}: {r1};{r2} allows {sorted(allowed)} but got {r3}")
    # A finite transition algebra is just this finite table.  Print a small bound.
    print("\nConclusion:")
    print("  For this fixed block, old-context propagation is captured by a finite")
    print("  pair-aware transition table.  Unary traces alone are over-accepting;")
    print("  old-old pair colours are exactly the extra local data needed.")

if __name__ == "__main__":
    main()
