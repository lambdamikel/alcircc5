#!/usr/bin/env python3
"""
WP68: Multi-PO star pockets with internal DR witnesses.

Shows two things:
  (1) the naive interval guard L < {A,B,D} < U is invalid when B DR D,
      because downward closure would force L DR L;
  (2) a separated-star guard works: put only the root A above the previous
      connector, keep PO witnesses B,D below the upper connector, and make
      the previous connector DR from B,D. This preserves A PO B and A PO D,
      keeps B DR D, and guards all cross-level pairs in a recursive chain.
"""
from itertools import product

ATOMS = ["EQ", "PP", "PPI", "PO", "DR"]
conv = {"EQ":"EQ", "PP":"PPI", "PPI":"PP", "PO":"PO", "DR":"DR"}

# RCC5 table by finite set semantics over universe of size 4 (enough for bases)
def rel(a,b):
    if a == b: return "EQ"
    if a and a < b: return "PP"
    if b and b < a: return "PPI"
    if a.isdisjoint(b): return "DR"
    return "PO"

def powerset(u):
    xs = list(u)
    for mask in range(1, 1<<len(xs)):  # nonempty regions only
        yield frozenset(xs[i] for i in range(len(xs)) if mask & (1<<i))

def derive_comp():
    regs = list(powerset(range(4)))
    comp = {(r,s): set() for r in ATOMS for s in ATOMS}
    for x,y,z in product(regs, repeat=3):
        comp[(rel(x,y), rel(y,z))].add(rel(x,z))
    return comp
COMP = derive_comp()

def closure_from_order_disj(objs, lt_edges, disj_edges):
    """Return transitive strict order lt and downward-closed disjointness #."""
    idx = {o:i for i,o in enumerate(objs)}
    n = len(objs)
    lt = [[False]*n for _ in range(n)]
    for a,b in lt_edges:
        lt[idx[a]][idx[b]] = True
    # transitive closure
    for k in range(n):
        for i in range(n):
            if lt[i][k]:
                rowi = lt[i]
                rowk = lt[k]
                for j in range(n):
                    if rowk[j]: rowi[j] = True
    # reflexive leq helper
    def leq(i,j): return i == j or lt[i][j]
    disj = [[False]*n for _ in range(n)]
    for a,b in disj_edges:
        ia, ib = idx[a], idx[b]
        disj[ia][ib] = disj[ib][ia] = True
    changed = True
    while changed:
        changed = False
        for a in range(n):
            for b in range(n):
                if not disj[a][b]: continue
                for x in range(n):
                    if not leq(x,a): continue
                    for y in range(n):
                        if leq(y,b) and not disj[x][y]:
                            disj[x][y] = disj[y][x] = True
                            changed = True
    return idx, lt, disj

def atom(i,j,lt,disj):
    if i == j: return "EQ"
    if lt[i][j]: return "PP"
    if lt[j][i]: return "PPI"
    if disj[i][j]: return "DR"
    return "PO"

def check_structure(objs, lt, disj):
    n = len(objs)
    errors = []
    # order irreflexive
    for i,o in enumerate(objs):
        if lt[i][i]: errors.append(("order_cycle", o))
    # disj irreflexive and not comparable
    for i,o in enumerate(objs):
        if disj[i][i]: errors.append(("disj_diagonal", o))
    for i,j in product(range(n), repeat=2):
        if disj[i][j] and (lt[i][j] or lt[j][i] or i==j):
            errors.append(("disj_comparable", objs[i], objs[j]))
    # RCC5 composition closure
    for i,j,k in product(range(n), repeat=3):
        r, s, t = atom(i,j,lt,disj), atom(j,k,lt,disj), atom(i,k,lt,disj)
        if t not in COMP[(r,s)]:
            errors.append(("comp", objs[i], objs[j], objs[k], r, s, t, sorted(COMP[(r,s)])))
            if len(errors) > 10: return errors
    return errors

def bad_interval():
    objs = ["L","A","B","D","U"]
    lt_edges = [("L","A"),("L","B"),("L","D"),("A","U"),("B","U"),("D","U")]
    disj_edges = [("B","D")]
    idx, lt, disj = closure_from_order_disj(objs, lt_edges, disj_edges)
    errors = check_structure(objs, lt, disj)
    return objs, idx, lt, disj, errors

def separated_star(n):
    # connectors C_-1, C_0, ..., C_{n-1}; pockets A_i,B_i,D_i for i=0..n-1
    objs = ["C_-1"]
    for i in range(n):
        objs += [f"A{i}", f"B{i}", f"D{i}", f"C{i}"]
    lt_edges = []
    disj_edges = []
    for i in range(n):
        prev = "C_-1" if i == 0 else f"C{i-1}"
        A,B,D,C = f"A{i}", f"B{i}", f"D{i}", f"C{i}"
        # separated star: prev < A < C; B < C; D < C; but prev is DR from B,D
        lt_edges += [(prev,A),(A,C),(B,C),(D,C)]
        disj_edges += [(prev,B),(prev,D),(B,D)]
    idx, lt, disj = closure_from_order_disj(objs, lt_edges, disj_edges)
    errors = check_structure(objs, lt, disj)
    return objs, idx, lt, disj, errors

def summarize_star(n):
    objs, idx, lt, disj, errors = separated_star(n)
    same_po = cross_po = 0
    witness_errors = []
    for i in range(n):
        A,B,D = f"A{i}", f"B{i}", f"D{i}"
        if atom(idx[A],idx[B],lt,disj) != "PO": witness_errors.append((A,B,atom(idx[A],idx[B],lt,disj)))
        if atom(idx[A],idx[D],lt,disj) != "PO": witness_errors.append((A,D,atom(idx[A],idx[D],lt,disj)))
        if atom(idx[B],idx[D],lt,disj) != "DR": witness_errors.append((B,D,atom(idx[B],idx[D],lt,disj)))
        same_po += (atom(idx[A],idx[B],lt,disj)=="PO") + (atom(idx[A],idx[D],lt,disj)=="PO")
    pocket_nodes = []
    for i in range(n): pocket_nodes += [f"A{i}",f"B{i}",f"D{i}"]
    for x in pocket_nodes:
        for y in pocket_nodes:
            if x == y: continue
            ix = int(x[1:]); iy = int(y[1:])
            if ix != iy and atom(idx[x],idx[y],lt,disj) == "PO": cross_po += 1
    # formula-visible pair colour: (kind src, kind tgt, atom, same-level witness label)
    colours = set()
    triples = set()
    def kind(o): return o[0] if o[0] in "ABDC" else "C"
    def wlabel(x,y):
        if x[0]=="A" and y[0] in ("B","D") and x[1:]==y[1:] and atom(idx[x],idx[y],lt,disj)=="PO":
            return f"W_A_PO_{y[0]}"
        return ""
    for x,y in product(objs, repeat=2):
        colours.add((kind(x), kind(y), atom(idx[x],idx[y],lt,disj), wlabel(x,y)))
    for x,y,z in product(objs, repeat=3):
        cxy=(kind(x),kind(y),atom(idx[x],idx[y],lt,disj),wlabel(x,y))
        cyz=(kind(y),kind(z),atom(idx[y],idx[z],lt,disj),wlabel(y,z))
        cxz=(kind(x),kind(z),atom(idx[x],idx[z],lt,disj),wlabel(x,z))
        triples.add((cxy,cyz,cxz))
    return dict(n=n, objects=len(objs), errors=len(errors), witness_errors=witness_errors[:5], same_po=same_po, cross_po=cross_po, colours=len(colours), triples=len(triples))

def main():
    print("=== Bad interval guard with internal DR ===")
    objs, idx, lt, disj, errors = bad_interval()
    print("relations of interest:")
    for a,b in [("L","A"),("L","B"),("L","D"),("B","D"),("L","L")]:
        print(f"  {a}->{b}: {atom(idx[a],idx[b],lt,disj)}")
    print("errors:", errors[:5])
    print("Conclusion: a common lower bound L below two DR witnesses B,D forces L DR L by downward closure.")
    print()
    print("=== Separated star guard recursive prefixes ===")
    for n in [1,2,3,4,6,9,12]:
        s = summarize_star(n)
        print(f"n={n}: objects={s['objects']} closure_errors={s['errors']} witness_errors={len(s['witness_errors'])} same_level_PO={s['same_po']} cross_level_PO={s['cross_po']} pair_colours={s['colours']} triple_patterns={s['triples']}")
        if s['witness_errors']:
            print("  sample witness errors", s['witness_errors'])
    print()
    print("PASS: separated-star guard preserves multiple PO witnesses with internal DR and eliminates cross-level PO in tested prefixes.")

if __name__ == "__main__":
    main()
