#!/usr/bin/env python3
"""
WP79: typed connector synthesis.

Purpose: demonstrate that once a finite RCC5 pocket and endpoint type-compatibility
masks are fixed, connector/envelope typing is a finite trace-synthesis problem.

This builds on WP71's one-point extension characterization.  We add abstract
profile compatibility predicates OK_R(e_profile, node_profile).  A typed connector
trace is valid iff it is algebraically admissible and passes endpoint compatibility
on every chosen relation (including converse side).
"""
from itertools import product

REL = ["PP","PPI","DR","PO"]
CONV = {"PP":"PPI", "PPI":"PP", "DR":"DR", "PO":"PO", "EQ":"EQ"}

# RCC5 table over proper relations, derived previously; enough for closure checks.
COMP = {
    ("PP","PP"): {"PP"},
    ("PP","PPI"): {"EQ","PP","PPI","PO","DR"},
    ("PP","DR"): {"DR"},
    ("PP","PO"): {"PP","PO","DR"},
    ("PPI","PP"): {"EQ","PP","PPI","PO"},
    ("PPI","PPI"): {"PPI"},
    ("PPI","DR"): {"PPI","PO","DR"},
    ("PPI","PO"): {"PPI","PO"},
    ("DR","PP"): {"DR","PP","PO"},
    ("DR","PPI"): {"DR"},
    ("DR","DR"): {"EQ","PP","PPI","PO","DR"},
    ("DR","PO"): {"DR","PP","PO"},
    ("PO","PP"): {"PP","PO"},
    ("PO","PPI"): {"PPI","PO","DR"},
    ("PO","DR"): {"PPI","PO","DR"},
    ("PO","PO"): {"EQ","PP","PPI","PO","DR"},
}
# Add EQ behavior for brute-force closure.
for r in ["EQ"]+REL:
    COMP[("EQ", r)] = {r}
    COMP[(r, "EQ")] = {r}


def converse(r): return CONV[r]


def rel_between(net, a, b):
    if a == b:
        return "EQ"
    return net[(a,b)]


def set_rel(net, a, b, r):
    if a == b:
        raise ValueError("proper self relation")
    net[(a,b)] = r
    net[(b,a)] = converse(r)


def check_closed(nodes, net):
    errors = []
    for x,y,z in product(nodes, repeat=3):
        r = rel_between(net,x,y)
        s = rel_between(net,y,z)
        t = rel_between(net,x,z)
        if t not in COMP[(r,s)]:
            errors.append((x,y,z,r,s,t,sorted(COMP[(r,s)])))
    return errors


def strict_order_and_disj(nodes, net):
    lt = {(x,y) for x in nodes for y in nodes if x!=y and rel_between(net,x,y)=="PP"}
    disj = {(x,y) for x in nodes for y in nodes if x!=y and rel_between(net,x,y)=="DR"}
    return lt, disj


def leq(x,y,lt):
    return x==y or (x,y) in lt


def wp71_criterion(pocket_nodes, pocket_net, trace):
    """trace maps pocket node x to relation e -> x."""
    lt, disj = strict_order_and_disj(pocket_nodes, pocket_net)
    U = {x for x,r in trace.items() if r=="PP"}   # e < x
    L = {x for x,r in trace.items() if r=="PPI"}  # x < e
    D = {x for x,r in trace.items() if r=="DR"}   # e # x

    # U upward closed
    for x in U:
        for y in pocket_nodes:
            if (x,y) in lt and y not in U:
                return False, ("U_not_upclosed", x, y)
    # U disjoint closure into D
    for x in U:
        for y in pocket_nodes:
            if (x,y) in disj and y not in D:
                return False, ("U_disj_not_D", x, y)
    # L downward closed
    for x in L:
        for y in pocket_nodes:
            if (y,x) in lt and y not in L:
                return False, ("L_not_downclosed", x, y)
    # L below U already
    for l in L:
        for u in U:
            if (l,u) not in lt:
                return False, ("L_not_below_U", l, u)
    # D downward closed
    for x in D:
        for y in pocket_nodes:
            if leq(y,x,lt) and y not in D:
                return False, ("D_not_downclosed", x, y)
    # L disjoint D already
    for l in L:
        for d in D:
            if (l,d) not in disj:
                return False, ("L_not_disj_D", l, d)
    return True, ("ok",)


def brute_add_connector(pocket_nodes, pocket_net, trace):
    nodes = list(pocket_nodes) + ["e"]
    net = dict(pocket_net)
    for x,r in trace.items():
        set_rel(net, "e", x, r)
    return check_closed(nodes, net)


def typed_valid(pocket_nodes, pocket_net, profiles, e_profile, trace, OK):
    ok, reason = wp71_criterion(pocket_nodes, pocket_net, trace)
    if not ok:
        return False, ("algebra", reason)
    for x,r in trace.items():
        xp = profiles[x]
        if r not in OK.get((e_profile, xp), set()):
            return False, ("type_forward", e_profile, r, xp, x)
        cr = converse(r)
        if cr not in OK.get((xp, e_profile), set()):
            return False, ("type_converse", xp, cr, e_profile, x)
    return True, ("ok",)


def enumerate_typed_traces(pocket_nodes, pocket_net, profiles, e_profile, OK):
    traces = []
    for vals in product(REL, repeat=len(pocket_nodes)):
        trace = dict(zip(pocket_nodes, vals))
        valid, reason = typed_valid(pocket_nodes, pocket_net, profiles, e_profile, trace, OK)
        if valid:
            traces.append(trace)
    return traces


def fmt_trace(nodes, tr):
    return tuple(tr[x] for x in nodes)


def pocket_PO_pair():
    nodes = ["A","B"]
    net = {}
    set_rel(net,"A","B","PO")
    return nodes, net


def pocket_DR_pair():
    nodes = ["B","D"]
    net = {}
    set_rel(net,"B","D","DR")
    return nodes, net


def main():
    print("WP79 typed connector synthesis")
    print("Typed connector traces = WP71 algebraic traces pruned by finite endpoint compatibility masks.\n")

    # Example 1: all-compatible connector on A PO B pocket.
    nodes, net = pocket_PO_pair()
    profiles = {"A":"Aprof", "B":"Bprof"}
    eprof = "Eprof"
    all_ok = {}
    for p in ["Aprof","Bprof","Dprof","Eprof"]:
        for q in ["Aprof","Bprof","Dprof","Eprof"]:
            all_ok[(p,q)] = set(REL)
    traces = enumerate_typed_traces(nodes, net, profiles, eprof, all_ok)
    print("Example 1: A PO B pocket, connector type compatible with all atoms")
    print(f"  typed traces={len(traces)} raw=16")
    print("  traces:", [fmt_trace(nodes,t) for t in traces])

    # Example 2: envelope all-DR wanted, but E cannot be DR to B.
    OK = dict(all_ok)
    OK[("Eprof","Bprof")] = {"PP","PPI","PO"}  # DR forbidden forward
    OK[("Bprof","Eprof")] = {converse(r) for r in OK[("Eprof","Bprof")]}
    traces2 = enumerate_typed_traces(nodes, net, profiles, eprof, OK)
    env = {"A":"DR","B":"DR"}
    valid_env, reason_env = typed_valid(nodes, net, profiles, eprof, env, OK)
    print("\nExample 2: same pocket, but E--DR--B is type-forbidden")
    print(f"  envelope trace (DR,DR) valid? {valid_env}, reason={reason_env}")
    print(f"  remaining typed traces={len(traces2)}")
    print("  sample:", [fmt_trace(nodes,t) for t in traces2[:8]])

    # Example 3: DR pocket B#D. Common lower below both algebraically invalid;
    # typed synthesis can still find split-style traces if allowed.
    nodes3, net3 = pocket_DR_pair()
    profiles3 = {"B":"Bprof", "D":"Dprof"}
    traces3 = enumerate_typed_traces(nodes3, net3, profiles3, eprof, all_ok)
    common_lower = {"B":"PP","D":"PP"}
    valid_cl, reason_cl = typed_valid(nodes3, net3, profiles3, eprof, common_lower, all_ok)
    print("\nExample 3: B DR D pocket")
    print(f"  common-lower trace (PP,PP) valid? {valid_cl}, reason={reason_cl}")
    print(f"  typed traces with all compatibility={len(traces3)}")
    print("  split-style traces containing PP to one side and DR to the other:")
    split = [fmt_trace(nodes3,t) for t in traces3 if set(fmt_trace(nodes3,t))=={"PP","DR"}]
    print(" ", split)

    # Example 4: type constraints force E below both DR-separated nodes: no trace.
    OK4 = dict(all_ok)
    # Force E->B and E->D only PP.
    OK4[("Eprof","Bprof")] = {"PP"}; OK4[("Bprof","Eprof")] = {"PPI"}
    OK4[("Eprof","Dprof")] = {"PP"}; OK4[("Dprof","Eprof")] = {"PPI"}
    traces4 = enumerate_typed_traces(nodes3, net3, profiles3, eprof, OK4)
    print("\nExample 4: type constraints force connector below both DR-separated pocket nodes")
    print(f"  typed traces={len(traces4)} (expected 0)")
    print("  interpretation: this connector profile cannot guard this pocket; use a different topology/profile or reject this basis.")

    # Sanity: algebraic criterion matches brute closure on all traces for two sample pockets.
    for label, (ns, nt) in [("PO", (nodes, net)), ("DR", (nodes3, net3))]:
        mism = 0
        for vals in product(REL, repeat=len(ns)):
            tr = dict(zip(ns, vals))
            crit, _ = wp71_criterion(ns, nt, tr)
            brute = not brute_add_connector(ns, nt, tr)
            if crit != brute:
                mism += 1
        print(f"\nSanity {label} pocket: WP71 criterion vs brute closure mismatches={mism}")

if __name__ == "__main__":
    main()
