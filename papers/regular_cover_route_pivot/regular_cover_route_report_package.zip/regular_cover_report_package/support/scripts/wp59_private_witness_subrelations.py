#!/usr/bin/env python3
"""
WP59: private witness subrelations repair the WP58 binary-domain obstruction.

The WP58 obstruction came from globalizing an existential witness relation at the
profile-pair level: D(T,N)={PO}, so one fresh N had to be PO to two T-occurrences
with incompatible rows to an A-selector.  This script builds finite set-model
prefixes where each T-occurrence has its own private PO-witness N.  The profile
pair T/N is multi-valued ({PO,DR}); the existential is represented by a selected
subrelation W_T_PO_N rather than by a singleton profile domain.

The constructed model uses profiles A,T,N.  There is one A-region.  For each i:
  Outside T: B_i is DR from A, with private N witness D_i also DR from A,
             and B_i PO D_i.
  Inside  T: C_i is PP to A (so A PPI C_i), with private N witness E_i also
             PP to A (so A PPI E_i), and C_i PO E_i.
All non-matching T/N pairs are DR.  Thus every T has a PO N witness, but not every
T/N pair is PO.  This is exactly the missing witness-subrelation layer.
"""
from itertools import combinations, product

ATOMS = ["EQ","PP","PPI","PO","DR"]
PROP = ["PP","PPI","PO","DR"]
CONV = {"EQ":"EQ","PP":"PPI","PPI":"PP","PO":"PO","DR":"DR"}

def rcc5(X,Y):
    if X == Y:
        return "EQ"
    if X < Y:
        return "PP"
    if Y < X:
        return "PPI"
    if X.isdisjoint(Y):
        return "DR"
    return "PO"

def derive_comp(universe_atoms):
    # derive from all nonempty subsets of a small finite universe
    subsets=[]
    U=list(universe_atoms)
    for mask in range(1,1<<len(U)):
        subsets.append(frozenset(U[i] for i in range(len(U)) if mask>>i & 1))
    comp={(a,b):set() for a in ATOMS for b in ATOMS}
    for X,Y,Z in product(subsets, repeat=3):
        comp[(rcc5(X,Y), rcc5(Y,Z))].add(rcc5(X,Z))
    return comp

COMP = derive_comp(range(4))

def check_closed(objs):
    names=list(objs)
    rel={(x,y):rcc5(objs[x],objs[y]) for x in names for y in names}
    errs=[]
    for x,y,z in product(names, repeat=3):
        if rel[(x,z)] not in COMP[(rel[(x,y)],rel[(y,z)])]:
            errs.append((x,y,z,rel[(x,y)],rel[(y,z)],rel[(x,z)],COMP[(rel[(x,y)],rel[(y,z)])]))
    return rel, errs

def build_prefix(n):
    objs={}
    # Universe atoms are just strings.  A contains all inside atoms and none of the outside atoms.
    A=set(["a_core"])
    for i in range(n):
        A.update([f"c{i}", f"t{i}", f"e{i}"])
    objs["A"] = frozenset(A)
    for i in range(n):
        # outside T and N, disjoint from A, PO each other via s_i
        objs[f"B{i}"] = frozenset([f"b{i}", f"s{i}"])
        objs[f"D{i}"] = frozenset([f"s{i}", f"d{i}"])
        # inside T and N, both proper parts of A, PO each other via t_i
        objs[f"C{i}"] = frozenset([f"c{i}", f"t{i}"])
        objs[f"E{i}"] = frozenset([f"t{i}", f"e{i}"])
    return objs

def profile(name):
    if name == "A": return "A"
    if name[0] in "BC": return "T"
    if name[0] in "DE": return "N"
    raise ValueError(name)

def collect_domains(rel):
    dom={}
    for (x,y),r in rel.items():
        if x==y: continue
        px,py=profile(x),profile(y)
        dom.setdefault((px,py),set()).add(r)
    return dom

def witness_edges(n, rel):
    # selected existential witness subrelation W subset T x N using matching index
    W=[]
    for i in range(n):
        W.append((f"B{i}", f"D{i}", rel[(f"B{i}",f"D{i}")]))
        W.append((f"C{i}", f"E{i}", rel[(f"C{i}",f"E{i}")]))
    return W

def report(n):
    objs=build_prefix(n)
    rel,errs=check_closed(objs)
    dom=collect_domains(rel)
    W=witness_edges(n, rel)
    badW=[e for e in W if e[2] != "PO"]
    # Every T occurrence has some selected PO N witness.
    Tnodes=[x for x in objs if profile(x)=="T"]
    has_w={t:any(a==t and r=="PO" and profile(b)=="N" for a,b,r in W) for t in Tnodes}
    return rel, errs, dom, W, badW, has_w

if __name__ == "__main__":
    print("WP59: private witness subrelations repair WP58-style shared-witness conflict")
    print("Relevant RCC5 cells:")
    for cell in [("DR","PO"),("PPI","PO"),("PO","PP")]:
        print(f"  {cell[0]};{cell[1]} = {sorted(COMP[cell])}")
    for n in [1,2,3,5,8]:
        rel,errs,dom,W,badW,has_w=report(n)
        print(f"\nprefix n={n}: objects={1+4*n}, closure_errors={len(errs)}, bad_witness_edges={badW}")
        print(f"  every T has selected PO N witness: {all(has_w.values())}")
        if n==2:
            print("  sample profile domains:")
            for k in sorted(dom):
                print(f"    D{k} = {sorted(dom[k])}")
            print("  selected witness subrelation W_T_PO_N:")
            for a,b,r in W:
                print(f"    {a} --{r}--> {b}")
            # Show non-selected T/N pairs are not forced PO.
            print("  non-selected T/N sample relations:")
            samples=[("B0","E0"),("B0","D1"),("C0","D0"),("C0","E1")]
            for x,y in samples:
                print(f"    {x}->{y} = {rel[(x,y)]}")
    print("\nConclusion: existential PO witnesses must be represented by a regular selected subrelation, not by making the whole T/N profile pair singleton-PO.")
