#!/usr/bin/env python3
"""
WP67: Recursive protected-PO pocket with prefix vertical guards.

At each level i create A_i, B_i, C_i. Protected witness A_i PO B_i.
Both A_i and B_i are below C_i. For i>0, previous connector C_{i-1}
 is below both A_i and B_i. Thus past levels are below both current A_i and B_i,
 while A_i and B_i remain incomparable and non-disjoint, hence PO.

This is a finite local rule:
  C_{i-1} < A_i, C_{i-1} < B_i, A_i < C_i, B_i < C_i.
The induced order is a chain of diamonds. No DR seeds are used.

The purpose is to show that cross-level residual PO hazards in recursive PO pockets
can be killed by a regular prefix order guard: old points become PP to the new
protected PO side witness B_i, while the current A_i remains PO to B_i.
"""
from itertools import product

ATOMS = ["EQ", "PP", "PPI", "PO", "DR"]
PROPER = ["PP", "PPI", "PO", "DR"]
CONV = {"EQ":"EQ", "PP":"PPI", "PPI":"PP", "PO":"PO", "DR":"DR"}

def rel_set(a,b):
    if a == b:
        return "EQ"
    if a < b:
        return "PP"
    if b < a:
        return "PPI"
    if not (a & b):
        return "DR"
    return "PO"

def derive_comp():
    universe = list(range(5))
    subs = []
    for mask in range(1, 1<<len(universe)):
        subs.append(frozenset(i for i in universe if mask & (1<<i)))
    comp = {(r,s):set() for r in ATOMS for s in ATOMS}
    for x,y,z in product(subs, repeat=3):
        comp[(rel_set(x,y), rel_set(y,z))].add(rel_set(x,z))
    return comp
COMP = derive_comp()

def build(n):
    objs=[]
    idx={}
    for i in range(n):
        for t in ["A","B","C"]:
            idx[(t,i)] = len(objs); objs.append((t,i))
    N=len(objs)
    less=[[False]*N for _ in range(N)]
    # local diamonds
    for i in range(n):
        A=idx[("A",i)]; B=idx[("B",i)]; C=idx[("C",i)]
        less[A][C]=True
        less[B][C]=True
        if i>0:
            P=idx[("C",i-1)]
            less[P][A]=True
            less[P][B]=True
    # transitive closure
    changed=True
    while changed:
        changed=False
        for i in range(N):
            for j in range(N):
                if less[i][j]:
                    rowj=less[j]
                    for k in range(N):
                        if rowj[k] and not less[i][k]:
                            less[i][k]=True; changed=True
    return objs, less

def atom(i,j,less):
    if i==j: return "EQ"
    if less[i][j]: return "PP"
    if less[j][i]: return "PPI"
    return "PO"  # no DR seeds in this construction

def closed(objs, less):
    errs=[]; N=len(objs)
    for i,j,k in product(range(N), repeat=3):
        r=atom(i,j,less); s=atom(j,k,less); t=atom(i,k,less)
        if t not in COMP[(r,s)]:
            errs.append((objs[i],objs[j],objs[k],r,s,t,COMP[(r,s)]))
            if len(errs)>=10: return errs
    return errs

def pair_colour(i,j,objs,less):
    si,ii=objs[i]; sj,jj=objs[j]
    r=atom(i,j,less)
    w=()
    # selected witness: A_i -> B_i by PO
    if si=="A" and sj=="B" and ii==jj and r=="PO":
        w=("e_A_PO_B",)
    return (si,sj,r,w)

def analyse(n):
    objs, less = build(n)
    N=len(objs)
    errs=closed(objs,less)
    # Verify protected PO and recursive witnesses plus prefix guard property.
    witness_errors=[]
    for i in range(n):
        A=objs.index(("A",i)); B=objs.index(("B",i)); C=objs.index(("C",i))
        if atom(A,B,less)!="PO": witness_errors.append(("A_PO_B",i,atom(A,B,less)))
        if atom(A,C,less)!="PP": witness_errors.append(("A_PP_C",i,atom(A,C,less)))
        if atom(B,C,less)!="PP": witness_errors.append(("B_PP_C",i,atom(B,C,less)))
        if i>0:
            P=objs.index(("C",i-1))
            if atom(P,A,less)!="PP": witness_errors.append(("prevC_PP_A",i,atom(P,A,less)))
            if atom(P,B,less)!="PP": witness_errors.append(("prevC_PP_B",i,atom(P,B,less)))
    cross_po=[]
    same_po=[]
    for i in range(N):
        for j in range(N):
            if i!=j and atom(i,j,less)=="PO":
                if objs[i][1]==objs[j][1]: same_po.append((objs[i],objs[j]))
                else: cross_po.append((objs[i],objs[j]))
    colours=set(pair_colour(i,j,objs,less) for i in range(N) for j in range(N))
    triples=set((pair_colour(i,j,objs,less), pair_colour(j,k,objs,less), pair_colour(i,k,objs,less))
                for i,j,k in product(range(N), repeat=3))
    bad=[]
    for c1,c2,c3 in triples:
        if c3[2] not in COMP[(c1[2], c2[2])]: bad.append((c1,c2,c3))
    return {
        "n":n, "objects":N, "closure_errors":len(errs), "witness_errors":witness_errors,
        "pair_colours":len(colours), "triple_patterns":len(triples), "bad_triples":len(bad),
        "same_level_PO":len(same_po), "cross_level_PO":len(cross_po),
        "sample_cross_po":cross_po[:5], "sample_colours":sorted(colours)[:12]
    }

if __name__ == "__main__":
    print("WP67 recursive protected-PO pocket with prefix vertical guards")
    print("Rule: C_{i-1}<A_i, C_{i-1}<B_i, A_i<C_i, B_i<C_i; A_i PO B_i protected.")
    for n in [1,2,3,4,6,9,12,16]:
        a=analyse(n)
        print(f"n={a['n']}: objects={a['objects']} pair_colours={a['pair_colours']} "
              f"triple_patterns={a['triple_patterns']} closure_errors={a['closure_errors']} "
              f"witness_errors={len(a['witness_errors'])} same_level_PO={a['same_level_PO']} "
              f"cross_level_PO={a['cross_level_PO']} bad_triples={a['bad_triples']}")
        if a['witness_errors']:
            print("  witness_errors", a['witness_errors'][:5])
        if a['sample_cross_po']:
            print("  sample_cross_po", a['sample_cross_po'])
    print("\nSample colours at n=4:")
    for c in analyse(4)["sample_colours"]:
        print(" ", c)
    print("\nConclusion: prefix order guards eliminate all cross-level PO; only protected same-level A/B pockets remain PO.")
