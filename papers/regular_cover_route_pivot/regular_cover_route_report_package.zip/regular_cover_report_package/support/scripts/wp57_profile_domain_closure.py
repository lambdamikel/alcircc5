#!/usr/bin/env python3
"""
WP57: finite RCC5 profile-domain closure probe.

This script derives the RCC5 composition table from ordinary nonempty set
semantics over a 3-point universe and implements a path-consistency/domain
closure operator for finite profile systems.

Purpose: test the full-logic regular-cover synthesis layer after the PO-pocket
observation.  A profile pair carries a domain D_ij of admissible RCC5 atoms.
Endpoint type compatibility and protected witnesses initialize/shrink domains;
then composition closure narrows D_ik by D_ij o D_jk.

This is a finite necessary filter for profile systems.  It is also sufficient
whenever all relevant domains become singleton and the resulting atomic network
satisfies RCC5 closure.
"""
from itertools import product, combinations

ATOMS = ["PP", "PPI", "PO", "DR"]  # proper atoms only for distinct profiles in examples
ALL_ATOMS = ["EQ"] + ATOMS
CONV = {"EQ":"EQ", "PP":"PPI", "PPI":"PP", "PO":"PO", "DR":"DR"}


def rel(A, B):
    if A == B:
        return "EQ"
    if A < B:
        return "PP"
    if B < A:
        return "PPI"
    if A.isdisjoint(B):
        return "DR"
    return "PO"


def derive_comp():
    universe = {0,1,2,3}
    subsets = []
    for mask in range(1, 1 << len(universe)):
        s = frozenset(i for i in universe if mask & (1 << i))
        subsets.append(s)
    comp = {(r,s): set() for r in ALL_ATOMS for s in ALL_ATOMS}
    for A, B, C in product(subsets, repeat=3):
        comp[(rel(A,B), rel(B,C))].add(rel(A,C))
    return comp

COMP = derive_comp()


def compose_domain(D1, D2):
    out = set()
    for r in D1:
        for s in D2:
            out |= COMP[(r,s)]
    return out

class DomainSystem:
    def __init__(self, names):
        self.names = list(names)
        self.n = len(self.names)
        self.D = [[set(ALL_ATOMS) for _ in range(self.n)] for __ in range(self.n)]
        for i in range(self.n):
            for j in range(self.n):
                if i == j:
                    self.D[i][j] = {"EQ"}
                else:
                    self.D[i][j] = set(ATOMS)
        self.explain = []

    def idx(self, name):
        return self.names.index(name)

    def restrict(self, a, b, allowed, reason=""):
        i, j = self.idx(a), self.idx(b)
        allowed = set(allowed)
        new = self.D[i][j] & allowed
        if new != self.D[i][j]:
            self.explain.append(f"restrict {a}->{b}: {sorted(self.D[i][j])} -> {sorted(new)} {reason}")
            self.D[i][j] = new
            self.D[j][i] = {CONV[x] for x in new}

    def close(self, verbose=False):
        changed = True
        rounds = 0
        while changed:
            changed = False
            rounds += 1
            for i,j,k in product(range(self.n), repeat=3):
                comp = compose_domain(self.D[i][j], self.D[j][k])
                new = self.D[i][k] & comp
                if new != self.D[i][k]:
                    if verbose:
                        self.explain.append(
                            f"pc via {self.names[j]}: {self.names[i]}->{self.names[k]} "
                            f"{sorted(self.D[i][k])} -> {sorted(new)} "
                            f"from {sorted(self.D[i][j])} o {sorted(self.D[j][k])}"
                        )
                    self.D[i][k] = new
                    self.D[k][i] = {CONV[x] for x in new}
                    changed = True
                if not self.D[i][k]:
                    return False, rounds
        return True, rounds

    def print_matrix(self):
        print("domains:")
        header = "      " + " ".join(f"{x:>18}" for x in self.names)
        print(header)
        for i,a in enumerate(self.names):
            row = [f"{a:>5}"]
            for j,b in enumerate(self.names):
                row.append(f"{','.join(sorted(self.D[i][j])):>18}")
            print(" ".join(row))

    def is_singleton_atomic(self):
        return all(len(self.D[i][j]) == 1 for i in range(self.n) for j in range(self.n))

    def atomic_errors(self):
        if not self.is_singleton_atomic():
            return ["not singleton"]
        rho = [[next(iter(self.D[i][j])) for j in range(self.n)] for i in range(self.n)]
        errs = []
        for i,j,k in product(range(self.n), repeat=3):
            if rho[i][k] not in COMP[(rho[i][j], rho[j][k])]:
                errs.append((self.names[i],self.names[j],self.names[k],rho[i][j],rho[j][k],rho[i][k]))
        return errs


def example_po_pocket():
    print("\n=== Example 1: protected PO pocket forces PP ===")
    ds = DomainSystem(["x","y","z"])
    ds.restrict("x","y", {"PO"}, "protected PO witness")
    ds.restrict("y","z", {"PP"}, "vertical edge")
    # x,z not PO-compatible, and also DR/PPI incompatible in this toy compatibility
    ds.restrict("x","z", {"PP","DR","PPI"}, "forbid PO by forallPO compatibility")
    ok, r = ds.close(verbose=True)
    print("ok", ok, "rounds", r)
    ds.print_matrix()
    print("expected x->z singleton PP")
    print("trace:")
    for e in ds.explain:
        print("  ", e)


def example_po_pocket_inconsistent():
    print("\n=== Example 2: protected PO pocket detects inconsistency ===")
    ds = DomainSystem(["x","y","z"])
    ds.restrict("x","y", {"PO"}, "protected PO witness")
    ds.restrict("y","z", {"PP"}, "vertical edge")
    ds.restrict("x","z", {"DR"}, "try to repair far pair by DR only")
    ok, r = ds.close(verbose=True)
    print("ok", ok, "rounds", r)
    ds.print_matrix()
    print("expected inconsistency because PO;PP allows only PO/PP")
    for e in ds.explain:
        print("  ", e)


def example_identity_profile_domains():
    print("\n=== Example 3: identity-selector profile domains survive domain closure ===")
    # Profiles L,A,U,B.  Abstracting WP44 over addresses:
    # L_i PP A_i, L_i PO A_j for j!=i -> D(L,A)={PP,PO}
    # U_i PPI A_i, U_i PO A_j for j!=i -> D(U,A)={PPI,PO}
    # A_i PO B all i, L_i DR B, U_i PPI B.
    ds = DomainSystem(["L","A","U","B"])
    ds.restrict("L","A", {"PP","PO"}, "identity selector: same index PP, other PO")
    ds.restrict("U","A", {"PPI","PO"}, "identity selector: same index PPI, other PO")
    ds.restrict("A","B", {"PO"}, "selector overlaps B")
    ds.restrict("L","B", {"DR"}, "forced split")
    ds.restrict("U","B", {"PPI"}, "forced split")
    # Leave L/U and same profile pairs broad/proper for this finite profile abstraction.
    ok, r = ds.close(verbose=True)
    print("ok", ok, "rounds", r)
    ds.print_matrix()
    print("Interpretation: finite domain closure does not reject the address-regular identity pattern.")
    if not ok:
        print("trace:")
        for e in ds.explain:
            print("  ", e)


def example_forced_more_than_repair():
    print("\n=== Example 4: two protected PO pockets force an order chain ===")
    ds = DomainSystem(["x","y","z","w"])
    ds.restrict("x","y", {"PO"}, "protected PO")
    ds.restrict("y","z", {"PP"}, "vertical")
    ds.restrict("x","z", {"PP","DR","PPI"}, "forbid PO -> should force PP")
    ds.restrict("z","w", {"PP"}, "vertical extension")
    ds.restrict("x","w", {"PP","DR","PPI"}, "forbid PO -> should force PP via transitive closure")
    ok, r = ds.close(verbose=True)
    print("ok", ok, "rounds", r)
    ds.print_matrix()
    print("expected x<z<w and x<w forced by composition/path closure")

if __name__ == "__main__":
    print("RCC5 comp cells used:")
    for pair in [("PO","PP"),("PPI","PO"),("PO","PPI"),("PO","DR")]:
        print(f"  {pair[0]};{pair[1]} = {sorted(COMP[pair])}")
    example_po_pocket()
    example_po_pocket_inconsistent()
    example_identity_profile_domains()
    example_forced_more_than_repair()
