#!/usr/bin/env python3
"""
WP62: Pair-colour palette alone is insufficient.

A valid RCC5 model can have a finite formula-visible pair-colour palette whose
raw colour cross-product contains composition-inconsistent combinations that are
never realized by any triple. Therefore a finite regular-cover certificate must
include either address automata or an explicit realized triple-colour relation;
pair colours alone over-reject.
"""
from itertools import product

ATOMS = ['EQ','PP','PPI','PO','DR']
proper = ['PP','PPI','PO','DR']
conv = {'EQ':'EQ','PP':'PPI','PPI':'PP','PO':'PO','DR':'DR'}

def rel(A,B):
    if A == B: return 'EQ'
    if A < B: return 'DR'  # not used for chain model below
    return 'DR'

# RCC5 table via finite set semantics over universe {0,1,2}
def rcc5(A,B):
    if A == B: return 'EQ'
    if A < B: return 'PP'
    if B < A: return 'PPI'
    if A.isdisjoint(B): return 'DR'
    return 'PO'

def powerset_nonempty(U):
    xs=list(U)
    for m in range(1,1<<len(xs)):
        yield frozenset(xs[i] for i in range(len(xs)) if (m>>i)&1)

def comp_table():
    U=set(range(4))
    sets=list(powerset_nonempty(U))
    table={(a,b):set() for a in ATOMS for b in ATOMS}
    for X,Y,Z in product(sets, repeat=3):
        table[(rcc5(X,Y), rcc5(Y,Z))].add(rcc5(X,Z))
    return {k: frozenset(v) for k,v in table.items()}

COMP=comp_table()

# Model: a finite prefix of one infinite PP chain, all nodes profile T.
# x_i PP x_j iff i<j.
def chain_atom(i,j):
    if i == j: return 'EQ'
    return 'PP' if i < j else 'PPI'

def realized_pair_colours(n):
    # formula-visible colour = (src_profile, tgt_profile, atom, witness_set)
    # no witnesses here.
    return {('T','T',chain_atom(i,j),()) for i in range(n) for j in range(n)}

def realized_triple_patterns(n):
    pats=set()
    for i,j,k in product(range(n), repeat=3):
        pats.add((('T','T',chain_atom(i,j),()),
                  ('T','T',chain_atom(j,k),()),
                  ('T','T',chain_atom(i,k),())))
    return pats

def bad_palette_cross_product(cols):
    bad=[]
    for cxy,cyz,cxz in product(cols, repeat=3):
        # all profiles match because single profile T
        a,b,c = cxy[2], cyz[2], cxz[2]
        if c not in COMP[(a,b)]:
            bad.append((cxy,cyz,cxz,COMP[(a,b)]))
    return bad

def bad_realized_triples(pats):
    bad=[]
    for cxy,cyz,cxz in pats:
        a,b,c = cxy[2], cyz[2], cxz[2]
        if c not in COMP[(a,b)]:
            bad.append((cxy,cyz,cxz,COMP[(a,b)]))
    return bad

if __name__ == '__main__':
    print('RCC5 comp(PP,PP)=', sorted(COMP[('PP','PP')]))
    print('RCC5 comp(PP,PPI)=', sorted(COMP[('PP','PPI')]))
    for n in [2,3,4,6]:
        cols=realized_pair_colours(n)
        pats=realized_triple_patterns(n)
        bad_all=bad_palette_cross_product(cols)
        bad_real=bad_realized_triples(pats)
        print(f'n={n}: pair_colours={len(cols)} realized_triple_patterns={len(pats)}')
        print(f'  bad palette cross-product triples={len(bad_all)}')
        print(f'  bad realized triples={len(bad_real)}')
        if bad_all:
            ex=bad_all[0]
            print('  sample impossible palette combination:')
            print('   cxy=', ex[0])
            print('   cyz=', ex[1])
            print('   cxz=', ex[2])
            print('   comp(cxy,cyz)=', sorted(ex[3]))
    assert all(len(bad_realized_triples(realized_triple_patterns(n))) == 0 for n in [2,3,4,6])
    assert len(bad_palette_cross_product(realized_pair_colours(3))) > 0
    print('PASS: actual chain is composition-closed, but palette-only all-combinations checking over-rejects.')
