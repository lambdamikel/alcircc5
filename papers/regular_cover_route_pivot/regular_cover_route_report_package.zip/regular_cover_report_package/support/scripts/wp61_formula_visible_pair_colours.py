#!/usr/bin/env python3
"""
WP61: Formula-visible pair-colour abstraction.

Builds a finite-prefix version of the WP59 private witness-subrelation
pattern and quotients ordered pairs only by information visible to an
ALCI concept/certificate:

    (source profile, target profile, RCC5 atom, selected witness labels)

The point is that address distinctions such as same-index vs different-index
need not be separate pair colours unless they change the RCC5 atom or witness
membership. This gives a concept-bounded colour palette: atom times finitely
many existential witness IDs, rather than arbitrary incidence colours.
"""
from itertools import combinations, product

# RCC5 relation over finite sets
REL = ['EQ','PP','PPI','PO','DR']
PROPER = ['PP','PPI','PO','DR']
CONV = {'EQ':'EQ','PP':'PPI','PPI':'PP','PO':'PO','DR':'DR'}

def rel(A,B):
    if A == B: return 'EQ'
    if A < B: return 'PP'
    if B < A: return 'PPI'
    if A.isdisjoint(B): return 'DR'
    return 'PO'

def comp_table():
    # brute force over small universe subsets
    U = list(range(4))
    subs = [frozenset(s) for r in range(1,5) for s in combinations(U,r)]
    table = {(a,b): set() for a in REL for b in REL}
    for X,Y,Z in product(subs, repeat=3):
        table[(rel(X,Y), rel(Y,Z))].add(rel(X,Z))
    return table
COMP = comp_table()

def build_prefix(n):
    # Implements the set pattern from WP59 in a simpler form.
    # Profiles: A global, and per index B,C:T and D,E:N.
    objs = {}
    prof = {}
    # Atoms use strings. Need A DR B_i and A DR D_i, A PPI C_i and A PPI E_i.
    # Let A be large-ish containing a_i/e_i for C/E; B/D disjoint from A.
    A_atoms = {'a'} | {f'c{i}' for i in range(n)} | {f'e{i}' for i in range(n)}
    objs['A0'] = frozenset(A_atoms); prof['A0'] = 'A'
    witnesses = set()
    for i in range(n):
        # B_i and D_i share bd_i outside A, so B_i PO D_i; both DR A.
        objs[f'B{i}'] = frozenset({f'b{i}', f'bd{i}'})
        objs[f'D{i}'] = frozenset({f'd{i}', f'bd{i}'})
        prof[f'B{i}'] = 'T'; prof[f'D{i}'] = 'N'
        witnesses.add((f'B{i}', f'D{i}', 'e_T_PO_N'))
        # C_i and E_i both strictly contain A? To make A PPI C/E and C_i PO E_i.
        # If both contain A they overlap A and each other; add private atoms so not nested.
        objs[f'C{i}'] = frozenset(A_atoms | {f'cpriv{i}', f'ce{i}'})
        objs[f'E{i}'] = frozenset(A_atoms | {f'epriv{i}', f'ce{i}'})
        prof[f'C{i}'] = 'T'; prof[f'E{i}'] = 'N'
        witnesses.add((f'C{i}', f'E{i}', 'e_T_PO_N'))
    return objs, prof, witnesses

def closure_errors(objs):
    names = list(objs)
    R = {(x,y): rel(objs[x], objs[y]) for x in names for y in names}
    errs=[]
    for x,y,z in product(names, repeat=3):
        if R[(x,z)] not in COMP[(R[(x,y)], R[(y,z)])]:
            errs.append((x,y,z,R[(x,y)],R[(y,z)],R[(x,z)],COMP[(R[(x,y)],R[(y,z)])]))
            if len(errs)>5: break
    return errs, R

def formula_visible_colours(objs, prof, witnesses):
    names = list(objs)
    witness_map = {}
    for x,y,e in witnesses:
        witness_map.setdefault((x,y), set()).add(e)
    errs, R = closure_errors(objs)
    colours = {}
    for x,y in product(names, repeat=2):
        labs = tuple(sorted(witness_map.get((x,y), set())))
        key = (prof[x], prof[y], R[(x,y)], labs)
        colours.setdefault(key, 0)
        colours[key]+=1
    return colours, R, errs

def check_colour_soundness(objs, prof, witnesses):
    colours, R, errs = formula_visible_colours(objs, prof, witnesses)
    # Since each colour carries an atom, any realized triple of concrete elements is sound
    # iff the original RCC5 network is sound. Check quotient-realized triples as well:
    # for every concrete triple, atom composition must pass.
    return len(errs)==0, len(colours), colours

if __name__ == '__main__':
    for n in [1,2,3,5,8]:
        objs, prof, wit = build_prefix(n)
        ok, cnum, colours = check_colour_soundness(objs, prof, wit)
        print(f'n={n}: objects={len(objs)} formula_visible_colours={cnum} rcc5_closed={ok}')
    objs, prof, wit = build_prefix(3)
    ok, cnum, colours = check_colour_soundness(objs, prof, wit)
    print('\nColours for n=3:')
    for k,v in sorted(colours.items()):
        print(f'  {k}: count={v}')
    print('\nObservation: colour count stabilizes because pair colours only record profiles, atom, and witness labels.')
