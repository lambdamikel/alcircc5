#!/usr/bin/env python3
"""
WP80: principal lower connector basis for arbitrary finite RCC5 pockets.

Given a finite strong-EQ closed RCC5 pocket P, build a canonical finite connector
basis with one principal lower connector L_i for each pocket point i, plus a
common top connector TOP.

Intuition: L_i is below the entire upset of i, and is made disjoint from exactly
what downward closure forces from that upset. Distinct L_i,L_j are disjoint iff
some element above i is disjoint from some element above j. This supplies split
lower connectors without creating L # L conflicts.

The probe exhaustively checks all closed atomic RCC5 pockets up to n=4.
"""
from itertools import product

ATOMS = ["PP", "PPI", "PO", "DR"]
ALL = ["EQ"] + ATOMS
CONV = {"EQ":"EQ", "PP":"PPI", "PPI":"PP", "PO":"PO", "DR":"DR"}

def rel_set(a,b):
    A=set(a); B=set(b)
    if A==B: return "EQ"
    if A < B: return "PP"
    if A > B: return "PPI"
    if A.isdisjoint(B): return "DR"
    return "PO"

def rcc5_table():
    U=range(5)
    regions=[frozenset(s) for mask in range(1,1<<5) for s in [tuple(i for i in U if mask>>i & 1)]]
    comp={(r,s):set() for r in ALL for s in ALL}
    for X in regions:
        for Y in regions:
            r=rel_set(X,Y)
            for Z in regions:
                s=rel_set(Y,Z); t=rel_set(X,Z)
                comp[(r,s)].add(t)
    return comp
COMP=rcc5_table()

def build_net_from_upper(n, vals):
    # vals over unordered pairs (i,j), i<j, atom from i to j
    mat=[["EQ" if i==j else None for j in range(n)] for i in range(n)]
    k=0
    for i in range(n):
        for j in range(i+1,n):
            r=vals[k]; k+=1
            mat[i][j]=r; mat[j][i]=CONV[r]
    return mat

def closure_errors(mat):
    n=len(mat); errs=[]
    for i in range(n):
        for j in range(n):
            for k in range(n):
                r,s,t=mat[i][j],mat[j][k],mat[i][k]
                if t not in COMP[(r,s)]:
                    errs.append((i,j,k,r,s,t,sorted(COMP[(r,s)])))
    return errs

def closed_networks(n):
    pairs=n*(n-1)//2
    for vals in product(ATOMS, repeat=pairs):
        mat=build_net_from_upper(n, vals)
        if not closure_errors(mat):
            yield mat

def to_order_disj(mat):
    n=len(mat)
    less=set(); disj=set()
    for i in range(n):
        for j in range(n):
            if mat[i][j]=="PP": less.add((i,j))
            if mat[i][j]=="DR": disj.add((i,j))
    return less,disj

def transitive_closure(less, N):
    less=set(less)
    changed=True
    while changed:
        changed=False
        add=set()
        for a,b in less:
            for c,d in less:
                if b==c and a!=d and (a,d) not in less:
                    add.add((a,d))
        if add:
            less |= add; changed=True
    return less

def downclose_disj(disj, less, N):
    # leq includes equality and less
    leq={(i,i) for i in range(N)} | set(less)
    disj=set(disj)
    changed=True
    while changed:
        changed=False
        add=set()
        for x,y in disj:
            for xp,x0 in leq:
                if x0!=x: continue
                for yp,y0 in leq:
                    if y0==y and xp!=yp and (xp,yp) not in disj:
                        add.add((xp,yp)); add.add((yp,xp))
        if add:
            disj |= add; changed=True
    return disj

def od_to_mat(less, disj, N):
    mat=[["EQ" if i==j else None for j in range(N)] for i in range(N)]
    for i in range(N):
        for j in range(N):
            if i==j: continue
            if (i,j) in less: mat[i][j]="PP"
            elif (j,i) in less: mat[i][j]="PPI"
            elif (i,j) in disj: mat[i][j]="DR"
            else: mat[i][j]="PO"
    return mat

def od_valid(less, disj, N):
    less=transitive_closure(less,N)
    # irreflexive order
    for i in range(N):
        if (i,i) in less: return False, "order_cycle"
    # sym disj and downclose
    for i,j in list(disj):
        disj.add((j,i))
    disj=downclose_disj(disj, less, N)
    for i in range(N):
        if (i,i) in disj: return False, "disj_diag"
    for i,j in less:
        if (i,j) in disj or (j,i) in disj: return False, "comparable_disj"
    mat=od_to_mat(less, disj, N)
    errs=closure_errors(mat)
    if errs: return False, ("closure", errs[:1])
    return True, "ok"

def principal_basis(mat):
    n=len(mat)
    less,disj=to_order_disj(mat)
    less=transitive_closure(less,n)
    # ids: originals 0..n-1, lower connectors n..2n-1, top 2n
    TOP=2*n; N=2*n+1
    new_less=set(less)
    new_disj=set(disj)
    # top above all originals and lower connectors
    for a in range(n):
        new_less.add((a,TOP))
    # original disj already symmetric in mat; ensure sym later
    for i in range(n):
        Li=n+i
        # upset of i in old pocket including i
        upset={a for a in range(n) if a==i or (i,a) in less}
        for u in upset:
            new_less.add((Li,u))
        new_less.add((Li,TOP))
        # L_i disjoint from any old a disjoint from some u in upset
        for a in range(n):
            if any((u,a) in disj for u in upset):
                if Li!=a:
                    new_disj.add((Li,a)); new_disj.add((a,Li))
    # disjointness between lower connectors forced by disjoint upsets
    for i in range(n):
        Li=n+i; upi={a for a in range(n) if a==i or (i,a) in less}
        for j in range(i+1,n):
            Lj=n+j; upj={b for b in range(n) if b==j or (j,b) in less}
            if any((a,b) in disj for a in upi for b in upj):
                new_disj.add((Li,Lj)); new_disj.add((Lj,Li))
    new_less=transitive_closure(new_less,N)
    for a,b in list(new_disj): new_disj.add((b,a))
    new_disj=downclose_disj(new_disj,new_less,N)
    return new_less,new_disj,N

def main():
    print("WP80 principal lower connector basis")
    print("For each old point i add L_i below upset(i), plus TOP above the pocket; disjointness is generated by downward closure.")
    for n in range(1,5):
        total=0; fail=0; max_new_pairs=0
        for mat in closed_networks(n):
            total+=1
            less,disj,N=principal_basis(mat)
            ok,why=od_valid(less,disj,N)
            if not ok:
                fail+=1
                if fail<=3: print("failure",n,why,mat)
            max_new_pairs=max(max_new_pairs,len(less)+len(disj))
        print(f"n={n}: closed_pockets={total} principal_basis_failures={fail} enlarged_size={2*n+1}")
    # sample pocket B DR D: show L_B/L_D split
    mat=build_net_from_upper(2, ("DR",))
    less,disj,N=principal_basis(mat)
    emat=od_to_mat(less,disj,N)
    print("\nSample pocket 0 DR 1 with L0,L1,TOP:")
    names=["B","D","L_B","L_D","TOP"]
    for i,a in enumerate(names):
        print("  ", a, "->", {names[j]: emat[i][j] for j in range(N) if j!=i})
    print("\nPASS if all failure counts are zero.")

if __name__=="__main__":
    main()
