#!/usr/bin/env python3
"""
WP77: canonical regular self-components for same-profile existential demands.

This probe is not a decision procedure.  It checks a small catalogue of regular
(<,#)-components showing that a single profile can satisfy any combination of
self-witness demands among {PP,PPI,DR,PO} using a bounded finite branch pattern.
Finite prefixes are checked for RCC5 closure and interior witness coverage.
"""
from itertools import combinations, chain

RELS = ["PP", "PPI", "DR", "PO"]

# RCC5 composition table derived from the (<,#) normal form by brute finite examples
# For checking closure, we use the normal form directly: < strict order, # downward closed.

def relation(x, y, less, disj):
    if x == y: return "EQ"
    if (x, y) in less: return "PP"
    if (y, x) in less: return "PPI"
    if frozenset((x, y)) in disj: return "DR"
    return "PO"

# RCC5 composition table from finite set semantics for verification
SETS = {
    'x': {1,2},
    'y': {2,3},
    'z': {3,4},
}

def rcc_rel(A, B):
    if A == B: return 'EQ'
    if A < B: return 'PP'
    if A > B: return 'PPI'
    if A.isdisjoint(B): return 'DR'
    return 'PO'

def derive_comp():
    # enumerate many small finite sets over universe {0,1,2,3}
    U = range(4)
    subs = []
    for mask in range(1, 1<<4):
        subs.append(frozenset(i for i in U if mask & (1<<i)))
    comp = {(a,b): set() for a in ['EQ','PP','PPI','DR','PO'] for b in ['EQ','PP','PPI','DR','PO']}
    for A in subs:
        for B in subs:
            for C in subs:
                comp[(rcc_rel(A,B), rcc_rel(B,C))].add(rcc_rel(A,C))
    return comp
COMP = derive_comp()


def transitive_closure(edges, nodes):
    less = set(edges)
    changed = True
    while changed:
        changed = False
        add = set()
        for a,b in less:
            for c,d in less:
                if b == c and a != d and (a,d) not in less:
                    add.add((a,d))
        if add:
            less |= add
            changed = True
    return less

def downward_close(disj_pairs, less, nodes):
    leq = set((x,x) for x in nodes) | set(less)
    disj = set(frozenset(p) for p in disj_pairs if p[0] != p[1])
    changed = True
    while changed:
        changed = False
        add = set()
        for pair in list(disj):
            a,b = tuple(pair)
            for x,y in leq:
                pass
        # easier: for every a#b, all x<=a,y<=b and x<=b,y<=a
        for pair in list(disj):
            a,b = tuple(pair)
            lows_a = [x for x in nodes if x == a or (x,a) in less]
            lows_b = [y for y in nodes if y == b or (y,b) in less]
            for x in lows_a:
                for y in lows_b:
                    if x != y:
                        fp = frozenset((x,y))
                        if fp not in disj:
                            add.add(fp)
            lows_b2 = [x for x in nodes if x == b or (x,b) in less]
            lows_a2 = [y for y in nodes if y == a or (y,a) in less]
            for x in lows_b2:
                for y in lows_a2:
                    if x != y:
                        fp = frozenset((x,y))
                        if fp not in disj:
                            add.add(fp)
        if add:
            disj |= add
            changed = True
    return disj

def check_closure(nodes, less, disj):
    errors = []
    for x in nodes:
        if (x,x) in less or frozenset((x,x)) in disj:
            errors.append(("diag", x))
    for x,y in less:
        if frozenset((x,y)) in disj:
            errors.append(("comparable_disj", x,y))
    for x in nodes:
        for y in nodes:
            for z in nodes:
                r = relation(x,y,less,disj)
                s = relation(y,z,less,disj)
                t = relation(x,z,less,disj)
                if t not in COMP[(r,s)]:
                    errors.append((x,y,z,r,s,t,COMP[(r,s)]))
    return errors

def branch_pattern(req):
    need_vert = 'PP' in req or 'PPI' in req
    need_dr = 'DR' in req
    need_po = 'PO' in req
    if need_dr and need_po and need_vert:
        branches = 4
        # DR cycle 0-1-2-3-0; non-DR opposite gives PO
        disj_edges = {(0,1),(1,2),(2,3),(3,0)}
    elif need_dr:
        branches = 2
        disj_edges = {(0,1)}
    elif need_po:
        branches = 2
        disj_edges = set()
    else:
        branches = 1
        disj_edges = set()
    return branches, disj_edges, need_vert

def build_component(req, radius=3):
    branches, disj_branch_edges, need_vert = branch_pattern(req)
    idxs = list(range(-radius, radius+1))
    nodes = [(b,i) for b in range(branches) for i in idxs]
    edges = []
    if need_vert:
        for b in range(branches):
            for i in idxs:
                for j in idxs:
                    if i < j:
                        edges.append(((b,i),(b,j)))
    less = transitive_closure(edges, nodes)
    disj_seed = []
    for b,c in disj_branch_edges:
        for i in idxs:
            for j in idxs:
                disj_seed.append(((b,i),(c,j)))
    disj = downward_close(disj_seed, less, nodes)
    return nodes, less, disj, branches, need_vert

def interior(nodes, radius=3):
    return [x for x in nodes if -radius < x[1] < radius]

def witness_coverage(req, nodes, less, disj, radius=3):
    bad = []
    ints = interior(nodes, radius)
    for x in ints:
        for R in req:
            found = False
            for y in nodes:
                if x != y and relation(x,y,less,disj) == R:
                    # for vertical witnesses avoid using finite-prefix endpoint only? any y in prefix ok for interiors
                    found = True
                    break
            if not found:
                bad.append((x,R))
    return bad

def powerset(iterable):
    s=list(iterable)
    return chain.from_iterable(combinations(s,r) for r in range(len(s)+1))

def main():
    print("WP77 canonical same-profile regular components")
    print("For each self-demand subset S, build a bounded branch pattern; check RCC5 closure and interior witnesses.")
    for subset in powerset(RELS):
        req=set(subset)
        nodes, less, disj, branches, need_vert = build_component(req)
        errs = check_closure(nodes, less, disj)
        bad = witness_coverage(req, nodes, less, disj)
        print(f"S={{{','.join(sorted(req))}}}: branches={branches} vertical={need_vert} closure_errors={len(errs)} witness_errors={len(bad)}")
        if errs[:1] or bad[:3]:
            print("  sample closure", errs[:1], "sample witness", bad[:3])
    print("Conclusion: same-profile self-witness obligations are regular-cover tame with <=4 branches in this catalogue.")

if __name__ == '__main__':
    main()
