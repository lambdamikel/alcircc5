#!/usr/bin/env python3
"""
WP76: Pair-aware block amalgamation theorem sanity check.

Given a closed old RCC5 network O and a closed fresh block F, an atomic
cross-assignment O x F yields a closed union iff every mixed triple
(two old + one fresh, or one old + two fresh, in all ordered permutations)
satisfies the RCC5 composition condition. This is the finite algebraic
content of the pair-aware trace interface.

The script derives the RCC5 composition table from finite set semantics,
enumerates small closed old/fresh networks, enumerates cross assignments,
and checks equivalence between full closure and the mixed-triple criterion.
"""
from itertools import combinations, product

RELS = ["PP", "PPI", "PO", "DR"]
ALL = ["EQ"] + RELS
CONV = {"EQ":"EQ", "PP":"PPI", "PPI":"PP", "PO":"PO", "DR":"DR"}

def rel(a,b):
    if a == b:
        return "EQ"
    if a < b:
        return "PP"
    if a > b:
        return "PPI"
    if a.isdisjoint(b):
        return "DR"
    return "PO"

def derive_comp():
    universe = list(range(4))
    regions = []
    for mask in range(1, 1 << len(universe)):
        regions.append(frozenset(i for i in universe if mask & (1 << i)))
    comp = {(r,s): set() for r in ALL for s in ALL}
    for a,b,c in product(regions, repeat=3):
        comp[(rel(a,b), rel(b,c))].add(rel(a,c))
    return comp

COMP = derive_comp()

def get(net, x, y):
    if x == y:
        return "EQ"
    if (x,y) in net:
        return net[(x,y)]
    return CONV[net[(y,x)]]

def set_edge(net, x, y, r):
    if x == y:
        assert r == "EQ"
    else:
        net[(x,y)] = r
        net[(y,x)] = CONV[r]

def closed(nodes, net):
    for x,y,z in product(nodes, repeat=3):
        r = get(net,x,y); s = get(net,y,z); t = get(net,x,z)
        if t not in COMP[(r,s)]:
            return False, (x,y,z,r,s,t,COMP[(r,s)])
    return True, None

def all_closed_networks(prefix, n):
    nodes = [f"{prefix}{i}" for i in range(n)]
    pairs = list(combinations(nodes, 2))
    out = []
    for labels in product(RELS, repeat=len(pairs)):
        net = {}
        for (x,y), r in zip(pairs, labels):
            set_edge(net,x,y,r)
        ok,_ = closed(nodes, net)
        if ok:
            out.append((nodes, net))
    return out

def union_with_cross(old_nodes, old_net, fresh_nodes, fresh_net, cross_labels):
    net = dict(old_net)
    net.update(fresh_net)
    k = 0
    for o in old_nodes:
        for f in fresh_nodes:
            set_edge(net,o,f,cross_labels[k]); k += 1
    return net

def mixed_triples_ok(old_nodes, fresh_nodes, net):
    nodes = old_nodes + fresh_nodes
    old = set(old_nodes); fresh = set(fresh_nodes)
    for x,y,z in product(nodes, repeat=3):
        cnt = (x in old) + (y in old) + (z in old)
        if cnt == 0 or cnt == 3:
            continue
        r = get(net,x,y); s = get(net,y,z); t = get(net,x,z)
        if t not in COMP[(r,s)]:
            return False, (x,y,z,r,s,t,COMP[(r,s)])
    return True, None

def run_case(no, nf):
    old_structs = all_closed_networks("o", no)
    fresh_structs = all_closed_networks("f", nf)
    total = 0; full_ok = 0; mixed_ok = 0; mismatch = 0
    sample_closed = None
    sample_reject = None
    for old_nodes, old_net in old_structs:
        for fresh_nodes, fresh_net in fresh_structs:
            for cross in product(RELS, repeat=no*nf):
                total += 1
                net = union_with_cross(old_nodes, old_net, fresh_nodes, fresh_net, cross)
                fo, ferr = closed(old_nodes+fresh_nodes, net)
                mo, merr = mixed_triples_ok(old_nodes, fresh_nodes, net)
                if fo: full_ok += 1
                if mo: mixed_ok += 1
                if fo != mo:
                    mismatch += 1
                    if mismatch <= 3:
                        print("MISMATCH", no, nf, cross, "full", fo, ferr, "mixed", mo, merr)
                if fo and sample_closed is None:
                    sample_closed = (old_nodes, fresh_nodes, cross)
                if (not fo) and sample_reject is None and merr is not None:
                    sample_reject = (old_nodes, fresh_nodes, cross, merr)
    return {
        "old_n": no,
        "fresh_n": nf,
        "old_closed_structs": len(old_structs),
        "fresh_closed_structs": len(fresh_structs),
        "total_cross_tests": total,
        "full_ok": full_ok,
        "mixed_ok": mixed_ok,
        "mismatch": mismatch,
        "sample_closed": sample_closed,
        "sample_reject": sample_reject,
    }

def format_sample_reject(s):
    if s is None:
        return "none"
    old_nodes, fresh_nodes, cross, err = s
    x,y,z,r,ss,t,allowed = err
    return f"cross={cross}; bad mixed triple {x},{y},{z}: {r};{ss} allows {sorted(allowed)} but got {t}"

if __name__ == "__main__":
    print("WP76 pair-aware block amalgamation")
    print("Criterion: old closed + fresh closed + all mixed triples valid <=> full union closed.")
    for no,nf in [(1,1),(2,1),(1,2),(2,2),(3,1),(3,2)]:
        res = run_case(no,nf)
        print(f"old={no}, fresh={nf}: old_structs={res['old_closed_structs']} fresh_structs={res['fresh_closed_structs']} total={res['total_cross_tests']} full_ok={res['full_ok']} mixed_ok={res['mixed_ok']} mismatches={res['mismatch']}")
        if no == 2 and nf == 1:
            print("  sample mixed rejection:", format_sample_reject(res['sample_reject']))
    print("PASS: in all tested cases, pair-aware mixed-triple criterion exactly matches full RCC5 closure.")
