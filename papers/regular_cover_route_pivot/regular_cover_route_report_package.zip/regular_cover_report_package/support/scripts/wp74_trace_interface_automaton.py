#!/usr/bin/env python3
"""
WP74: Trace-interface automata for finite extension blocks.

Given a finite RCC5 block with inherited boundary ports and fresh ports, enumerate
how an arbitrary old outside occurrence can be summarized by its trace to the
boundary, and how that trace admits only finitely many traces to the fresh ports.

This is a finite-state sanity check for the regular-cover extension-basis route.
"""
from itertools import combinations, product
from collections import defaultdict

ATOMS = ["DR", "PO", "PP", "PPI"]
ALL = ATOMS + ["EQ"]
CONV = {"EQ":"EQ", "DR":"DR", "PO":"PO", "PP":"PPI", "PPI":"PP"}


def rel(a, b):
    if a == b:
        return "EQ"
    if a < b:
        return "PP"
    if a > b:
        return "PPI"
    if a.isdisjoint(b):
        return "DR"
    return "PO"


def powerset_nonempty(n):
    U = range(n)
    out = []
    for r in range(1, n+1):
        for c in combinations(U, r):
            out.append(frozenset(c))
    return out


def derive_comp(n=4):
    regs = powerset_nonempty(n)
    comp = {(a,b): set() for a in ALL for b in ALL}
    for x in regs:
        for y in regs:
            rxy = rel(x,y)
            for z in regs:
                ryz = rel(y,z)
                rxz = rel(x,z)
                comp[(rxy, ryz)].add(rxz)
    return comp

COMP = derive_comp(4)


def set_atom(net, a, b, r):
    net[(a,b)] = r
    net[(b,a)] = CONV[r]


def close_check(nodes, net, verbose=False):
    # net must have all ordered pairs, diagonal EQ.
    errs = []
    for x in nodes:
        if net.get((x,x)) != "EQ":
            errs.append(("diag", x, net.get((x,x))))
    for x in nodes:
        for y in nodes:
            r = net.get((x,y))
            if r is None:
                errs.append(("missing", x, y))
                continue
            if net.get((y,x)) != CONV[r]:
                errs.append(("conv", x,y,r,net.get((y,x))))
    for x in nodes:
        for y in nodes:
            for z in nodes:
                r = net[(x,y)]
                s = net[(y,z)]
                t = net[(x,z)]
                if t not in COMP[(r,s)]:
                    errs.append(("comp", x,y,z,r,s,t,sorted(COMP[(r,s)])))
                    if verbose and len(errs) < 20:
                        print(errs[-1])
    return errs


def build_prefix_interval_block():
    # Boundary L; fresh A,B,C.
    # L < A,B < C and A PO B. (x<y means x PP y.)
    nodes = ["L", "A", "B", "C"]
    net = {(x,x): "EQ" for x in nodes}
    set_atom(net, "L", "A", "PP")
    set_atom(net, "L", "B", "PP")
    set_atom(net, "A", "C", "PP")
    set_atom(net, "B", "C", "PP")
    set_atom(net, "L", "C", "PP")
    set_atom(net, "A", "B", "PO")
    return nodes, net, ["L"], ["A", "B", "C"]


def build_separated_star_block():
    # Boundary L; fresh A,B,D,C.
    # L<A<C; B<C; D<C; L DR B,D; A PO B,D; B DR D.
    nodes = ["L", "A", "B", "D", "C"]
    net = {(x,x): "EQ" for x in nodes}
    set_atom(net, "L", "A", "PP")
    set_atom(net, "A", "C", "PP")
    set_atom(net, "L", "C", "PP")
    set_atom(net, "B", "C", "PP")
    set_atom(net, "D", "C", "PP")
    set_atom(net, "L", "B", "DR")
    set_atom(net, "L", "D", "DR")
    set_atom(net, "A", "B", "PO")
    set_atom(net, "A", "D", "PO")
    set_atom(net, "B", "D", "DR")
    return nodes, net, ["L"], ["A", "B", "D", "C"]


def build_envelope_block():
    # Boundary L; arbitrary-ish pocket A,B,D below U and disjoint from L.
    # A PO B, A PO D, B DR D; all pocket nodes PP U; L DR pocket; L PP U.
    nodes = ["L", "A", "B", "D", "U"]
    net = {(x,x): "EQ" for x in nodes}
    set_atom(net, "A", "B", "PO")
    set_atom(net, "A", "D", "PO")
    set_atom(net, "B", "D", "DR")
    for x in ["A","B","D"]:
        set_atom(net, x, "U", "PP")
        set_atom(net, "L", x, "DR")
    set_atom(net, "L", "U", "PP")
    return nodes, net, ["L"], ["A", "B", "D", "U"]


def enumerate_external_traces(name, builder):
    nodes, base, boundary, fresh = builder()
    errs = close_check(nodes, base)
    print(f"\n=== {name} ===")
    print(f"base nodes={nodes}, boundary={boundary}, fresh={fresh}, base_closed={len(errs)==0}")
    if errs:
        print("base errors", errs[:5])
        return
    # Enumerate relation from external old point X to boundary and fresh.
    # We require complete atomic extension closed. X is distinct, so proper atoms only.
    results = defaultdict(list)
    all_targets = boundary + fresh
    for rels in product(ATOMS, repeat=len(all_targets)):
        net = dict(base)
        ext_nodes = ["X"] + nodes
        net[("X","X")] = "EQ"
        ok = True
        for t, r in zip(all_targets, rels):
            set_atom(net, "X", t, r)
        e = close_check(ext_nodes, net)
        if not e:
            btrace = tuple(rels[:len(boundary)])
            ftrace = tuple(rels[len(boundary):])
            results[btrace].append(ftrace)
    print(f"boundary trace states with at least one extension: {len(results)} / {4**len(boundary)}")
    total = sum(len(v) for v in results.values())
    print(f"total admissible full traces: {total} / raw {4**len(all_targets)}")
    for btrace in sorted(results):
        outs = sorted(set(results[btrace]))
        print(f"  boundary {btrace}: {len(outs)} fresh traces")
        for o in outs[:8]:
            print(f"    -> {dict(zip(fresh,o))}")
        if len(outs) > 8:
            print(f"    ... {len(outs)-8} more")


def main():
    print("WP74 trace-interface automata")
    print("Composition table derived from nonempty finite sets.")
    for key in [("PO","PP"),("PP","DR"),("DR","PPI")]:
        print(f"comp{key}={sorted(COMP[key])}")
    enumerate_external_traces("prefix interval PO-pocket block", build_prefix_interval_block)
    enumerate_external_traces("separated-star multi-witness block", build_separated_star_block)
    enumerate_external_traces("envelope-isolated multi-witness block", build_envelope_block)
    print("\nConclusion:")
    print("  For each fixed finite block, old context is summarized by finitely many boundary traces.")
    print("  The relation from a boundary trace to fresh-pocket traces is a finite transition relation.")
    print("  Thus any fixed extension basis induces a finite trace automaton; the remaining issue is")
    print("  existence of a bounded finite basis, not coherence of old-context propagation for a fixed basis.")

if __name__ == "__main__":
    main()
