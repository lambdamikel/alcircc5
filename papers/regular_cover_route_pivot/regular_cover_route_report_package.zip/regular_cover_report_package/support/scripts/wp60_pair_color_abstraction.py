#!/usr/bin/env python3
"""WP60: pair-color abstraction for a regular RCC5 cover.

This takes the private-witness pattern from WP59 and shows that the
unbounded family is captured by finitely many pair colors: object kind plus
whether indices are equal/different/global.  It then checks RCC5 closure by
color triples rather than by raw occurrence triples.
"""
from itertools import product

ATOMS = ['EQ','PP','PPI','PO','DR']
INV = {'EQ':'EQ','PP':'PPI','PPI':'PP','PO':'PO','DR':'DR'}
# Composition table over RCC5 atoms with EQ as identity.
BASE_COMP = {
('PP','PP'):{'PP'},
('PP','PPI'):{'EQ','PP','PPI','PO','DR'},
('PP','PO'):{'PP','PO','DR'},
('PP','DR'):{'DR'},
('PPI','PP'):{'EQ','PP','PPI','PO'},
('PPI','PPI'):{'PPI'},
('PPI','PO'):{'PPI','PO'},
('PPI','DR'):{'PPI','PO','DR'},
('PO','PP'):{'PP','PO'},
('PO','PPI'):{'PPI','PO','DR'},
('PO','PO'):{'EQ','PP','PPI','PO','DR'},
('PO','DR'):{'PPI','PO','DR'},
('DR','PP'):{'PP','PO','DR'},
('DR','PPI'):{'DR'},
('DR','PO'):{'PP','PO','DR'},
('DR','DR'):{'EQ','PP','PPI','PO','DR'},
}
def comp(a,b):
    if a=='EQ': return {b}
    if b=='EQ': return {a}
    return BASE_COMP[(a,b)]

def rcc5(X,Y):
    if X == Y: return 'EQ'
    if X < Y: return 'PP'
    if Y < X: return 'PPI'
    if X.isdisjoint(Y): return 'DR'
    return 'PO'

def build(n):
    # One global A. For each i, T-kinds B_i,C_i and N-kinds D_i,E_i.
    # Sets chosen as in WP59-style repair: B_i PO D_i and C_i PO E_i,
    # but cross/nonmatching T/N pairs are DR.
    U=set(['a0'])
    objs=[]; regions={}
    regions[('A',None)]={'a0'}
    objs.append(('A',None))
    for i in range(n):
        # Private atoms
        b=f'b{i}'; c=f'c{i}'; d=f'd{i}'; e=f'e{i}'
        # B_i disjoint from A; D_i disjoint from A; B_i overlaps D_i on bd_i.
        bd=f'bd{i}'
        regions[('B',i)]={b,bd}
        regions[('D',i)]={d,bd}
        # C_i and E_i both contain A, overlap on ce_i, and properly contain A.
        ce=f'ce{i}'
        regions[('C',i)]={'a0',c,ce}
        regions[('E',i)]={'a0',e,ce}
        # Add all objects
        objs += [('B',i),('C',i),('D',i),('E',i)]
    return objs,regions

def pair_color(x,y):
    kx,ix=x; ky,iy=y
    if x==y:
        idxrel='same_obj'
    elif ix is None or iy is None:
        idxrel='global'
    elif ix==iy:
        idxrel='same_index'
    else:
        idxrel='diff_index'
    return (kx,ky,idxrel)

def check(n=6):
    objs,reg=build(n)
    atom_by_color={}
    errors=[]
    for x,y in product(objs, repeat=2):
        col=pair_color(x,y)
        a=rcc5(reg[x],reg[y])
        if col in atom_by_color and atom_by_color[col]!=a:
            errors.append(('not_well_defined', col, atom_by_color[col], a, x, y))
        atom_by_color[col]=a
    if errors:
        return errors, atom_by_color, None
    # Build realized color triples and check closure by colors.
    triple_colors=set()
    for x,y,z in product(objs, repeat=3):
        triple_colors.add((pair_color(x,y), pair_color(y,z), pair_color(x,z)))
    bad=[]
    for cxy,cyz,cxz in triple_colors:
        a=atom_by_color[cxy]; b=atom_by_color[cyz]; c=atom_by_color[cxz]
        if c not in comp(a,b):
            bad.append((cxy,cyz,cxz,a,b,c,comp(a,b)))
    return bad, atom_by_color, triple_colors

if __name__ == '__main__':
    for n in [1,2,3,5,8]:
        bad, table, triples = check(n)
        print(f'n={n}: pair_colors={len(table)} triple_color_patterns={len(triples) if triples else None} closure_errors={len(bad)}')
        if bad:
            print('first bad:', bad[0]); break
    print('\nSample pair-color atom table for n=5:')
    bad, table, triples=check(5)
    for col in sorted(table):
        kx,ky,rel=col
        if (kx,ky) in [('B','D'),('B','E'),('C','D'),('C','E'),('A','B'),('A','C'),('A','D'),('A','E')]:
            print(f'{col}: {table[col]}')
    print('\nConclusion: the private witness family is represented by a finite pair-color scheme; existential witnesses use the same_index PO subcolors, not the whole T/N profile pair.')
