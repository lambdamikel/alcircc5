#!/usr/bin/env python3
"""
WP70: lower-connector guard colouring for finite RCC5 pockets.

Given a finite pocket (as PP-order < and DR relation #) and, for each pocket
node x, a set of allowed relations from a lower connector L to x: {PP,DR},
search for a valid guard assignment.

An assignment L--x is valid iff U={x : L PP x} is
  (1) upward closed under pocket order: x in U and x<y => y in U;
  (2) DR-independent: not (x#y and x,y in U);
  (3) respects allowed labels.
All nodes outside U are set L DR x.

This captures the finite algebraic condition behind interval and separated-star
guards. Endpoint type compatibility determines allowed labels; this script only
checks the algebraic side.
"""
from itertools import combinations, product

def upward_closed(U, less):
    return all((y in U) for x,y in less if x in U)

def dr_independent(U, disj):
    return all(not (x in U and y in U) for x,y in disj)

def solve(nodes, less, disj, allowed):
    sols=[]
    for bits in product([0,1], repeat=len(nodes)):
        U={x for x,b in zip(nodes,bits) if b}
        ok=True
        for x in nodes:
            lab='PP' if x in U else 'DR'
            if lab not in allowed.get(x, {'PP','DR'}):
                ok=False; break
        if not ok: continue
        if not upward_closed(U,less): continue
        if not dr_independent(U,disj): continue
        sols.append(U)
    return sols

def show(name,nodes,less,disj,allowed):
    sols=solve(nodes,less,disj,allowed)
    print(f"\n{name}")
    print(f"  nodes={nodes}")
    print(f"  less={sorted(less)}")
    print(f"  disj={sorted(tuple(sorted(d)) for d in disj)}")
    print(f"  allowed={allowed}")
    print(f"  solutions={len(sols)}")
    for U in sols[:5]:
        print(f"    U={sorted(U)} labels=" + ", ".join(f"L-{'PP' if x in U else 'DR'}-{x}" for x in nodes))

if __name__ == '__main__':
    # Interval pocket A PO B, both below C; no internal DR. Common lower below all is allowed.
    nodes=['A','B','C']
    less={('A','C'),('B','C')}
    disj=set()
    allowed={x:{'PP','DR'} for x in nodes}
    show('Example 1: PO interval pocket, common lower allowed',nodes,less,disj,allowed)

    # Separated star A PO B, A PO D, B DR D, all below C, A<C,B<C,D<C.
    nodes=['A','B','D','C']
    less={('A','C'),('B','C'),('D','C')}
    disj={tuple(sorted(('B','D')))}
    allowed={x:{'PP','DR'} for x in nodes}
    show('Example 2: multi-witness pocket with B DR D',nodes,less,disj,allowed)

    # Same pocket, force A to be above lower and B,D to be DR from lower (WP68 shape).
    allowed={'A':{'PP'}, 'B':{'DR'}, 'D':{'DR'}, 'C':{'PP','DR'}}
    show('Example 3: separated-star compatibility requirements',nodes,less,disj,allowed)

    # Bad compatibility: force both DR-separated witnesses above lower.
    allowed={'A':{'PP','DR'}, 'B':{'PP'}, 'D':{'PP'}, 'C':{'PP','DR'}}
    show('Example 4: impossible if DR-separated witnesses both require PP from lower',nodes,less,disj,allowed)

    print('\nConclusion:')
    print('  For a single lower connector, guardability is exactly a finite upward-closed DR-independent set selection with endpoint-allowed labels.')
    print('  If no colouring exists, one needs a different basis topology, multiple connectors, or the requested profile combination is impossible.')
