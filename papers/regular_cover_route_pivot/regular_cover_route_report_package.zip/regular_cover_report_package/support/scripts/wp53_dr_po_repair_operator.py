#!/usr/bin/env python3
"""
WP53: DR-repair operator for residual PO violations in typed (<,#) templates.

Given a finite ordered-disjoint template (D,<,#,type), residual PO pairs are
incomparable and non-disjoint.  If a residual PO pair's endpoint types are not
PO-compatible, the full logic requires it to be guarded by PP/PPI/DR.

This probe implements the simplest repair: add DR for all residual PO-unsafe
pairs and close downward along <.  The repair is sound provided the closure
(1) does not hit the diagonal, (2) does not hit comparable pairs, (3) only adds
DR-compatible type pairs, and (4) does not destroy protected PO witness pairs.

The script checks the repair on a minimal fork and on random finite templates.
"""
from itertools import product, combinations
import random

ATOMS = ["EQ","PP","PPI","PO","DR"]
CONV = {"EQ":"EQ","PP":"PPI","PPI":"PP","PO":"PO","DR":"DR"}

def derive_rcc(order, disj, objs):
    def atom(a,b):
        if a == b: return "EQ"
        if (a,b) in order: return "PP"
        if (b,a) in order: return "PPI"
        if (a,b) in disj: return "DR"
        return "PO"
    return atom

def transitive_closure(order):
    order=set(order)
    changed=True
    while changed:
        changed=False
        for a,b in list(order):
            for c,d in list(order):
                if b==c and a!=d and (a,d) not in order:
                    order.add((a,d)); changed=True
    return order

def downclose(disj_base, order, objs):
    le={(x,x) for x in objs} | set(order)
    disj=set()
    for a,b in disj_base:
        if a!=b:
            disj.add((a,b)); disj.add((b,a))
    changed=True
    while changed:
        changed=False
        for a,b in list(disj):
            for x,a2 in le:
                if a2 != a: continue
                for y,b2 in le:
                    if b2 != b: continue
                    if x != y and (x,y) not in disj:
                        disj.add((x,y)); disj.add((y,x)); changed=True
    return disj

def is_valid_order_disj(order, disj, objs):
    # order already transitive
    if any((x,x) in order for x in objs): return False, "order_cycle"
    if any((x,x) in disj for x in objs): return False, "disj_reflexive"
    for x,y in disj:
        if (y,x) not in disj: return False, "disj_not_symmetric"
    for x,y in order:
        if (x,y) in disj or (y,x) in disj: return False, "comparable_disjoint"
    # downward closure
    le={(x,x) for x in objs} | set(order)
    for a,b in disj:
        for x,a2 in le:
            if a2 != a: continue
            for y,b2 in le:
                if b2 != b: continue
                if x != y and (x,y) not in disj:
                    return False, "not_downclosed"
    return True, "ok"

def dr_repair(objs, order, disj, typ, po_ok, dr_ok, protected_po=frozenset()):
    order=transitive_closure(order)
    disj=downclose(disj, order, objs)
    atom=derive_rcc(order, disj, objs)
    unsafe=[]
    for x,y in combinations(objs,2):
        if atom(x,y)=="PO" and not po_ok(typ[x], typ[y]):
            unsafe.append((x,y)); unsafe.append((y,x))
    repaired=downclose(set(disj)|set(unsafe), order, objs)
    # Conditions
    failures=[]
    for x in objs:
        if (x,x) in repaired:
            failures.append(("diagonal",x))
    for x,y in repaired:
        if (x,y) in order or (y,x) in order:
            failures.append(("comparable",x,y))
        if not dr_ok(typ[x], typ[y]):
            failures.append(("dr_incompatible",x,y,typ[x],typ[y]))
        if (x,y) in protected_po or (y,x) in protected_po:
            failures.append(("protected_po_destroyed",x,y))
    valid, why = is_valid_order_disj(order, repaired, objs)
    if not valid:
        failures.append(("invalid_order_disj", why))
    atom2=derive_rcc(order, repaired, objs)
    remaining=[]
    for x,y in combinations(objs,2):
        if atom2(x,y)=="PO" and not po_ok(typ[x],typ[y]):
            remaining.append((x,y,typ[x],typ[y]))
    return unsafe, repaired, failures, remaining

def demo_minimal_fork():
    # x<z, y#x, y-z residual PO. Types Y and Z are PO-incompatible but DR-compatible.
    objs=["y","x","z"]
    order=transitive_closure({("x","z")})
    disj=downclose({("y","x")}, order, objs)
    typ={"y":"Y","x":"X","z":"Z"}
    def po_ok(a,b):
        return set([a,b]) != set(["Y","Z"])
    def dr_ok(a,b):
        return True
    unsafe, repaired, failures, remaining = dr_repair(objs,order,disj,typ,po_ok,dr_ok)
    atom_before=derive_rcc(order,disj,objs)
    atom_after=derive_rcc(order,repaired,objs)
    print("minimal fork:")
    print("  before y-z =", atom_before("y","z"))
    print("  unsafe residual pairs =", unsafe)
    print("  repair failures =", failures)
    print("  remaining unsafe PO =", remaining)
    print("  after y-z =", atom_after("y","z"))


def random_template(seed, n=7, colors=("A","B","C")):
    random.seed(seed)
    objs=list(range(n))
    # random acyclic order by numeric direction
    order={(i,j) for i in objs for j in objs if i<j and random.random()<0.18}
    order=transitive_closure(order)
    # base disjoint only among incomparable pairs, sparse
    base=set()
    for i,j in combinations(objs,2):
        if (i,j) not in order and (j,i) not in order and random.random()<0.12:
            base.add((i,j))
    disj=downclose(base, order, objs)
    ok,_=is_valid_order_disj(order, disj, objs)
    if not ok:
        return None
    typ={i:random.choice(colors) for i in objs}
    # random compatibility matrices, symmetric for PO/DR here
    po_bad=set()
    dr_bad=set()
    for a,b in combinations(colors,2):
        if random.random()<0.35: po_bad.add(frozenset([a,b]))
        if random.random()<0.15: dr_bad.add(frozenset([a,b]))
    def po_ok(a,b): return frozenset([a,b]) not in po_bad
    def dr_ok(a,b): return a!=b and frozenset([a,b]) not in dr_bad
    return objs,order,disj,typ,po_ok,dr_ok,po_bad,dr_bad

def main():
    print("WP53: DR repair of residual PO-unsafe pairs")
    demo_minimal_fork()
    passed=failed=blocked=0
    examples=[]
    for seed in range(200):
        tpl=random_template(seed)
        if tpl is None: continue
        objs,order,disj,typ,po_ok,dr_ok,po_bad,dr_bad=tpl
        unsafe,repaired,failures,remaining=dr_repair(objs,order,disj,typ,po_ok,dr_ok)
        if not unsafe:
            continue
        if not failures and not remaining:
            passed += 1
            if len(examples)<2:
                examples.append(("repaired",seed,len(unsafe)//2,po_bad,dr_bad))
        else:
            failed += 1
            # distinguish failures caused by DR incompat/comparable closure: these require non-DR guards
            blocked += 1
            if len(examples)<4:
                examples.append(("blocked",seed,len(unsafe)//2,failures[:3],remaining[:3],po_bad,dr_bad))
    print(f"random templates with unsafe PO: repaired={passed} blocked={blocked}")
    for ex in examples:
        print("  example:", ex)
    print("Interpretation:")
    print("  The DR-repair operator is a decidable sufficient full-logic repair.")
    print("  When it is blocked, the obstruction is explicit: comparable/downward-closure conflict,")
    print("  DR-incompatible endpoint types, or destruction of protected PO witnesses.")

if __name__ == '__main__':
    main()
