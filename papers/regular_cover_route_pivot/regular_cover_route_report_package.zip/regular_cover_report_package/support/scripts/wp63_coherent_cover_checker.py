#!/usr/bin/env python3
"""
WP63: formula-visible coherent-cover finite-prefix checker.

This is not a decision procedure for ALCI_RCC5.  It is a small sanity
checker for the finite object that emerged in the regular-cover route:

  profiles + formula-visible pair colours + realized triple patterns
  + selected witness subrelations.

It demonstrates two points on finite prefixes:

  (1) A vertical PP-chain passes the realized-triple RCC5 check even though
      a palette-only all-combinations check would over-reject it.

  (2) A private-witness family passes the same coherent-cover checks when
      existential witnesses are represented as selected subrelations rather
      than as singleton whole-profile-pair relations.

The RCC5 table is derived from finite set semantics over a 3-element universe.
"""
from itertools import combinations, product
from collections import defaultdict

ATOMS = ["EQ", "PP", "PPI", "PO", "DR"]
PROPER = ["PP", "PPI", "PO", "DR"]


def rcc5_rel(a, b):
    a = set(a); b = set(b)
    if a == b:
        return "EQ"
    if a < b:
        return "PP"
    if a > b:
        return "PPI"
    if a.isdisjoint(b):
        return "DR"
    return "PO"


def derive_comp():
    universe = {0, 1, 2, 3}
    regs = []
    for mask in range(1, 1 << len(universe)):
        regs.append(frozenset(i for i in universe if mask & (1 << i)))
    comp = {(r, s): set() for r in ATOMS for s in ATOMS}
    for x, y, z in product(regs, repeat=3):
        r = rcc5_rel(x, y)
        s = rcc5_rel(y, z)
        t = rcc5_rel(x, z)
        comp[(r, s)].add(t)
    return comp

COMP = derive_comp()
CONV = {"EQ": "EQ", "PP": "PPI", "PPI": "PP", "PO": "PO", "DR": "DR"}


def check_closed(objs, rel):
    errs = []
    for x, y in product(objs, repeat=2):
        if x == y and rel[(x, y)] != "EQ":
            errs.append(("diag", x, rel[(x, y)]))
        if rel[(y, x)] != CONV[rel[(x, y)]]:
            errs.append(("conv", x, y, rel[(x, y)], rel[(y, x)]))
    for x, y, z in product(objs, repeat=3):
        r, s, t = rel[(x, y)], rel[(y, z)], rel[(x, z)]
        if t not in COMP[(r, s)]:
            errs.append(("comp", x, y, z, r, s, t, sorted(COMP[(r, s)])))
    return errs


def pair_colour(x, y, prof, rel, wit):
    labels = tuple(sorted(wit.get((x, y), set())))
    return (prof[x], prof[y], rel[(x, y)], labels)


def coherent_summary(objs, prof, rel, wit, required_total):
    pcols = {pair_colour(x, y, prof, rel, wit) for x, y in product(objs, repeat=2)}
    triples = {
        (pair_colour(x, y, prof, rel, wit),
         pair_colour(y, z, prof, rel, wit),
         pair_colour(x, z, prof, rel, wit))
        for x, y, z in product(objs, repeat=3)
    }
    realized_bad = []
    for cxy, cyz, cxz in triples:
        r, s, t = cxy[2], cyz[2], cxz[2]
        if t not in COMP[(r, s)]:
            realized_bad.append((cxy, cyz, cxz, sorted(COMP[(r, s)])))

    # Palette-only overstrong check: all pair-colour combinations with matching
    # middle profile are required to compose.  This is deliberately too strict.
    palette_bad = []
    for cxy, cyz, cxz in product(pcols, repeat=3):
        if cxy[1] != cyz[0]:
            continue
        if cxy[0] != cxz[0] or cyz[1] != cxz[1]:
            continue
        if cxz[2] not in COMP[(cxy[2], cyz[2])]:
            palette_bad.append((cxy, cyz, cxz, sorted(COMP[(cxy[2], cyz[2])])))

    total_bad = []
    # required_total entries are (label, source_profile, target_profile, atom)
    for label, sp, tp, atom in required_total:
        for x in objs:
            if prof[x] != sp:
                continue
            ok = False
            for y in objs:
                if prof[y] == tp and rel[(x, y)] == atom and label in wit.get((x, y), set()):
                    ok = True
                    break
            if not ok:
                total_bad.append((label, x, sp, tp, atom))
    return pcols, triples, realized_bad, palette_bad, total_bad


def vertical_chain(n):
    objs = [f"x{i}" for i in range(n)]
    prof = {x: "T" for x in objs}
    rel = {}
    for i, x in enumerate(objs):
        for j, y in enumerate(objs):
            if i == j:
                r = "EQ"
            elif i < j:
                r = "PP"
            else:
                r = "PPI"
            rel[(x, y)] = r
    wit = {}
    return objs, prof, rel, wit, []


def private_witness(n):
    # Set-model family from WP59.
    # A contains all "inside" atoms.  B_i,D_i are outside A and overlap each
    # other.  C_i,E_i are proper parts of A and overlap each other.  Nonmatching
    # T/N pairs are DR.
    regions = {}
    A = {"a_core"}
    for i in range(n):
        A.update([f"c{i}", f"t{i}", f"e{i}"])
    regions["A"] = frozenset(A)
    for i in range(n):
        regions[f"B{i}"] = frozenset([f"b{i}", f"s{i}"])
        regions[f"D{i}"] = frozenset([f"s{i}", f"d{i}"])
        regions[f"C{i}"] = frozenset([f"c{i}", f"t{i}"])
        regions[f"E{i}"] = frozenset([f"t{i}", f"e{i}"])
    objs = list(regions)
    prof = {"A": "A"}
    for i in range(n):
        prof[f"B{i}"] = "T"
        prof[f"C{i}"] = "T"
        prof[f"D{i}"] = "N"
        prof[f"E{i}"] = "N"
    rel = {(x, y): rcc5_rel(regions[x], regions[y]) for x, y in product(objs, repeat=2)}
    wit = defaultdict(set)
    for i in range(n):
        wit[(f"B{i}", f"D{i}")].add("e_T_PO_N")
        wit[(f"C{i}", f"E{i}")].add("e_T_PO_N")
    required = [("e_T_PO_N", "T", "N", "PO")]
    return objs, prof, rel, wit, required

def main():
    print("=== WP63 coherent regular-cover finite-prefix checks ===")
    print("RCC5 singleton cells:")
    for k in sorted(COMP):
        if len(COMP[k]) == 1:
            print(f"  {k[0]};{k[1]} -> {sorted(COMP[k])}")

    print("\nExample 1: vertical PP-chain")
    for n in [2, 3, 5, 8]:
        objs, prof, rel, wit, req = vertical_chain(n)
        cerr = check_closed(objs, rel)
        pcols, triples, rbad, pbad, tbad = coherent_summary(objs, prof, rel, wit, req)
        print(f"  n={n}: pair_colours={len(pcols)} realized_triples={len(triples)} "
              f"closed={not cerr} realized_bad={len(rbad)} palette_bad={len(pbad)}")
    print("  Note: palette_bad>0 for n>=3 is the known over-rejection; realized_bad=0 is correct.")

    print("\nExample 2: private witness subrelations")
    for n in [1, 2, 3, 5]:
        objs, prof, rel, wit, req = private_witness(n)
        cerr = check_closed(objs, rel)
        pcols, triples, rbad, pbad, tbad = coherent_summary(objs, prof, rel, wit, req)
        print(f"  n={n}: objects={len(objs)} pair_colours={len(pcols)} realized_triples={len(triples)} "
              f"closed={not cerr} realized_bad={len(rbad)} witness_total_bad={len(tbad)}")
    print("  Witness totality is checked separately from RCC5 triple coherence.")

    print("\nPASS: finite-prefix checks support the coherent-cover object:")
    print("  profiles + formula-visible pair colours + realized triples + total witness subrelations.")

if __name__ == "__main__":
    main()
