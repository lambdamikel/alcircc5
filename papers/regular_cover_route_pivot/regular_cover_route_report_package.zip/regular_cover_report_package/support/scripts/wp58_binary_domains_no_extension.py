#!/usr/bin/env python3
"""
WP58: binary profile-domain closure does not imply one-point extension.

A finite profile-domain abstraction can be path-consistent/nonempty, and an old
atomic RCC5 network can respect it, while a fresh profile demanded by the
abstraction has no atomic extension. This is a profile-level W2'-style obstruction:
two same-profile old nodes impose incompatible constraints on the new node through
different relations to a third old node.
"""
from itertools import product

ATOMS=['EQ','PP','PPI','PO','DR']
PROPER=['PP','PPI','PO','DR']
CONV={'EQ':'EQ','PP':'PPI','PPI':'PP','PO':'PO','DR':'DR'}

def rel(A,B):
    if A==B: return 'EQ'
    if A < B: return 'PP'
    if B < A: return 'PPI'
    if A.isdisjoint(B): return 'DR'
    return 'PO'

def comp_table():
    U=range(5)
    subs=[frozenset(i for i in U if mask>>i&1) for mask in range(1,1<<5)]
    comp={(a,b):set() for a in ATOMS for b in ATOMS}
    for A,B,C in product(subs, repeat=3):
        comp[(rel(A,B), rel(B,C))].add(rel(A,C))
    return comp
COMP=comp_table()

def compose(S,T):
    out=set()
    for a in S:
        for b in T:
            out |= COMP[(a,b)]
    return out & set(PROPER)

def close_domains(D, profiles):
    D={k:set(v) for k,v in D.items()}
    changed=True
    while changed:
        changed=False
        for i,j,k in product(profiles, repeat=3):
            new=D[(i,k)] & compose(D[(i,j)],D[(j,k)])
            if not new:
                return None
            if new != D[(i,k)]:
                D[(i,k)] = new
                D[(k,i)] = {CONV[x] for x in new}
                changed=True
    return D

def atom_closed(edges, nodes):
    for i,j,k in product(nodes, repeat=3):
        rij='EQ' if i==j else edges[(i,j)]
        rjk='EQ' if j==k else edges[(j,k)]
        rik='EQ' if i==k else edges[(i,k)]
        if rik not in COMP[(rij,rjk)]:
            return False, (i,j,k,rij,rjk,rik,COMP[(rij,rjk)])
    return True, None

def add_edge(edges,i,j,r):
    edges[(i,j)]=r; edges[(j,i)]=CONV[r]

profiles=['A','T','N']  # A = selector anchor type, T = old twin type, N = fresh type
# Proper-domain abstraction. D(X,Y) is the set of possible atoms between distinct
# occurrences of profiles X and Y. Same-profile T/T has DR available, so two T-old
# nodes can be horizontally separated.
D={}
for x in profiles:
    for y in profiles:
        D[(x,y)]=set(PROPER)
# Constraints of the witness
D[('A','T')]={'DR','PPI'}; D[('T','A')]={'DR','PP'}
D[('T','T')]={'DR'}
D[('T','N')]={'PO'}; D[('N','T')]={'PO'}
D[('A','N')]={'DR','PPI'}; D[('N','A')]={'DR','PP'}
# keep N/N and A/A unconstrained proper
closed=close_domains(D,profiles)
print('profile-domain closure nonempty:', closed is not None)
if closed:
    for x in profiles:
        print(x, {y: ''.join(sorted(closed[(x,y)])) for y in profiles})

# Old network: a:A, b:T, c:T.
# a DR b, a PPI c, b DR c. This is composition-closed.
type_of={'a':'A','b':'T','c':'T'}
edges={}
add_edge(edges,'a','b','DR')
add_edge(edges,'a','c','PPI')
add_edge(edges,'b','c','DR')
ok,why=atom_closed(edges,['a','b','c'])
print('old atomic network closed:', ok, why)
print('old network respects profile domains:', all(edges[(i,j)] in closed[(type_of[i],type_of[j])] for i,j in [('a','b'),('a','c'),('b','c')]))

# Try to add d:N. Domains force b PO d and c PO d. a-d may be DR or PPI.
for r_ad in sorted(closed[('A','N')]):
    e=dict(edges)
    add_edge(e,'b','d','PO')
    add_edge(e,'c','d','PO')
    add_edge(e,'a','d',r_ad)
    ok,why=atom_closed(e,['a','b','c','d'])
    print(f'try a-{r_ad}-d: closed={ok}', '' if ok else f'failure={why}')

# Derive the two forced singleton narrows explicitly.
left = COMP[('DR','PO')] & closed[('A','N')]
right = COMP[('PPI','PO')] & closed[('A','N')]
print('from a DR b, b PO d: a-d in', sorted(left))
print('from a PPI c, c PO d: a-d in', sorted(right))
print('intersection:', sorted(left & right))
if not (left & right):
    print('PASS: no one-point extension exists although the binary profile domains are closed/nonempty.')
