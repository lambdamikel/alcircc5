#!/usr/bin/env python3
"""
WP64: coherent regular cover for a protected-PO pocket with forced order guard.

This is a finite-prefix sanity check for the regular extension-basis picture.
Each block i contains X_i, Y_i, Z_i with
    X_i PO Y_i     (protected PO witness pocket)
    Y_i PP Z_i
    X_i PP Z_i     (forced if X/Z is PO-unsafe, since PO;PP={PO,PP})
Different blocks are made DR by putting their tops Z_i, Z_j disjoint and closing downward.
The resulting infinite family is regular over the block index i.
"""
from itertools import product

ATOMS = ["EQ","PP","PPI","PO","DR"]
PROPER = ["PP","PPI","PO","DR"]
CONV = {"EQ":"EQ","PP":"PPI","PPI":"PP","PO":"PO","DR":"DR"}

def rcc5(a,b):
    if a == b: return "EQ"
    if a < b: return "PP"
    if b < a: return "PPI"
    if a.isdisjoint(b): return "DR"
    return "PO"

def derive_comp():
    # finite universe sufficient for RCC5 set semantics samples
    U = list(range(4))
    regs = [frozenset(s) for mask in range(1,1<<len(U))
            for s in [[U[i] for i in range(len(U)) if mask & (1<<i)]]]
    comp = {(r,s): set() for r in ATOMS for s in ATOMS}
    for x,y,z in product(regs, repeat=3):
        comp[(rcc5(x,y), rcc5(y,z))].add(rcc5(x,z))
    return {k: frozenset(v) for k,v in comp.items()}
COMP = derive_comp()

def build_prefix(n):
    objs = []
    for i in range(n):
        objs += [("X",i),("Y",i),("Z",i)]
    # strict order: X_i < Z_i and Y_i < Z_i.
    less = set()
    for i in range(n):
        less.add((("X",i),("Z",i)))
        less.add((("Y",i),("Z",i)))
    # transitive closure (already closed here, but keep generic)
    changed = True
    while changed:
        changed = False
        for a,b in list(less):
            for c,d in list(less):
                if b == c and (a,d) not in less:
                    less.add((a,d)); changed = True
    # disjointness: different blocks are disjoint at top, then downward closure.
    disj = set()
    for i in range(n):
        for j in range(i+1,n):
            disj.add((("Z",i),("Z",j)))
            disj.add((("Z",j),("Z",i)))
    leq = set((o,o) for o in objs) | less
    changed = True
    while changed:
        changed = False
        for a,b in list(disj):
            for x,aa in list(leq):
                if aa != a: continue
                for y,bb in list(leq):
                    if bb == b and (x,y) not in disj and x != y:
                        disj.add((x,y)); disj.add((y,x)); changed = True
    def rel(a,b):
        if a == b: return "EQ"
        if (a,b) in less: return "PP"
        if (b,a) in less: return "PPI"
        if (a,b) in disj: return "DR"
        return "PO"
    return objs, rel

def check_closed(objs, rel):
    errors=[]
    for x,y,z in product(objs, repeat=3):
        r,s,t = rel(x,y), rel(y,z), rel(x,z)
        if t not in COMP[(r,s)]:
            errors.append((x,y,z,r,s,t,COMP[(r,s)]))
            if len(errors) > 10: break
    return errors

def formula_visible_colour(a,b,rel):
    # witness label only for protected X_i -> Y_i PO pocket, same block.
    labs = []
    if a[0] == "X" and b[0] == "Y" and a[1] == b[1] and rel(a,b) == "PO":
        labs.append("e_X_PO_Y")
    return (a[0], b[0], rel(a,b), tuple(labs))

def stats(n):
    objs, rel = build_prefix(n)
    errs = check_closed(objs, rel)
    colours = set()
    triples = set()
    for a,b in product(objs, repeat=2):
        colours.add(formula_visible_colour(a,b,rel))
    for a,b,c in product(objs, repeat=3):
        ca = formula_visible_colour(a,b,rel)
        cb = formula_visible_colour(b,c,rel)
        cc = formula_visible_colour(a,c,rel)
        triples.add((ca,cb,cc))
    # key counts
    pocket = sum(1 for i in range(n) if rel(("X",i),("Y",i)) == "PO")
    forced = sum(1 for i in range(n) if rel(("X",i),("Z",i)) == "PP")
    cross_dr = sum(1 for i in range(n) for j in range(n) if i != j and rel(("X",i),("Y",j)) == "DR")
    return len(objs), len(colours), len(triples), len(errs), pocket, forced, cross_dr

if __name__ == "__main__":
    print("WP64: protected-PO pocket coherent cover finite prefixes")
    for n in [1,2,3,5,8,12]:
        m,c,t,e,p,f,d = stats(n)
        print(f"n={n}: objects={m} pair_colours={c} triple_patterns={t} closure_errors={e} pockets={p} forced_XZ_PP={f} cross_XY_DR={d}")
    print("\nKey finite rule represented by the cover:")
    print("  X_i PO Y_i and Y_i PP Z_i, with X/Z PO-unsafe, is realized by X_i PP Z_i.")
    print("  Different blocks are DR via downward closure from Z_i # Z_j.")
