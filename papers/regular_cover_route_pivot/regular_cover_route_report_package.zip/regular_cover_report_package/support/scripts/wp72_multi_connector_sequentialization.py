#!/usr/bin/env python3
"""
WP72: multi-connector topology is sequential one-point trace selection.

This probe uses the RCC5 normal form (PP as strict order, DR as downward-closed
incompatibility) and the WP71 one-point extension criterion.  It checks that
adding finitely many connector points is exactly sequential one-point extension:
for small closed pockets, every sequentially admissible two-connector extension
is RCC5-closed, and every RCC5-closed two-connector extension is sequentially
admissible.
"""
from itertools import product, combinations

ATOMS = ["PP", "PPI", "PO", "DR"]
CONV = {"PP":"PPI", "PPI":"PP", "PO":"PO", "DR":"DR", "EQ":"EQ"}

# RCC5 relation from finite sets for composition table derivation.
def rel(a,b):
    if a == b: return "EQ"
    if a < b: return "PP"
    if b < a: return "PPI"
    if a.isdisjoint(b): return "DR"
    return "PO"

def derive_comp():
    # universe with enough small subsets
    U = range(4)
    regs = [frozenset(s) for mask in range(1,1<<4) for s in [[i for i in U if mask & (1<<i)]]]
    comp = {(r,s): set() for r in ["EQ"]+ATOMS for s in ["EQ"]+ATOMS}
    for a in regs:
        for b in regs:
            for c in regs:
                comp[(rel(a,b), rel(b,c))].add(rel(a,c))
    return comp

COMP = derive_comp()

def get(net,x,y):
    if x == y: return "EQ"
    return net[(x,y)]

def set_edge(net,x,y,r):
    if x == y:
        assert r == "EQ"
        return
    net[(x,y)] = r
    net[(y,x)] = CONV[r]

def is_closed(net, nodes):
    for x in nodes:
        for y in nodes:
            for z in nodes:
                r = get(net,x,y); s = get(net,y,z); t = get(net,x,z)
                if t not in COMP[(r,s)]:
                    return False, (x,y,z,r,s,t,sorted(COMP[(r,s)]))
    return True, None

def all_networks(nodes):
    pairs = [(nodes[i], nodes[j]) for i in range(len(nodes)) for j in range(i+1,len(nodes))]
    for choices in product(ATOMS, repeat=len(pairs)):
        net = {}
        for (x,y), r in zip(pairs, choices):
            set_edge(net,x,y,r)
        yield net

def closed_pockets(n):
    nodes = tuple(range(n))
    for net in all_networks(nodes):
        ok,_ = is_closed(net,nodes)
        if ok:
            yield net

def leq(net,x,y):
    return x == y or get(net,x,y) == "PP"

def lt(net,x,y):
    return get(net,x,y) == "PP"

def disj(net,x,y):
    return get(net,x,y) == "DR"

def one_point_criterion(base_net, base_nodes, e_rel):
    """e_rel[x] is relation e -> x for x in base_nodes."""
    U = {x for x,r in e_rel.items() if r == "PP"}   # e < x
    L = {x for x,r in e_rel.items() if r == "PPI"}  # x < e
    D = {x for x,r in e_rel.items() if r == "DR"}   # e # x
    # U upward and disjoint-neighbour closure
    for x in list(U):
        for y in base_nodes:
            if lt(base_net,x,y) and y not in U:
                return False, ("U_up", x, y)
            if disj(base_net,x,y) and y not in D:
                return False, ("U_disj_not_D", x, y)
    # L downward
    for x in list(L):
        for y in base_nodes:
            if lt(base_net,y,x) and y not in L:
                return False, ("L_down", x, y)
    # L below U must already be true in old pocket
    for l in L:
        for u in U:
            if not lt(base_net,l,u):
                return False, ("L_not_below_U", l, u)
    # D downward
    for x in list(D):
        for y in base_nodes:
            if leq(base_net,y,x) and y not in D:
                return False, ("D_down", x, y)
    # L disjoint D must already be true
    for l in L:
        for d in D:
            if not disj(base_net,l,d):
                return False, ("L_not_disj_D", l, d)
    return True, ("ok",)

def add_point(base_net, base_nodes, e, e_rel):
    net = dict(base_net)
    for x,r in e_rel.items():
        set_edge(net,e,x,r)
    return net, tuple(list(base_nodes)+[e])

def test_sequential(kmax_n=3):
    print("WP72 multi-connector sequentialization")
    print("Checking: sequential WP71 traces <=> closed two-connector extensions (small exhaustive).")
    for n in range(1,kmax_n+1):
        pockets = list(closed_pockets(n))
        seq_bad = 0
        closed_not_seq = 0
        total_seq = 0
        total_closed = 0
        for base in pockets:
            nodes = tuple(range(n))
            e0 = n; e1 = n+1
            for rel0_vals in product(ATOMS, repeat=n):
                rel0 = dict(zip(nodes, rel0_vals))
                c0,_ = one_point_criterion(base,nodes,rel0)
                net0,nodes0 = add_point(base,nodes,e0,rel0)
                ok0,_ = is_closed(net0,nodes0)
                if c0 != ok0:
                    print("criterion mismatch first point", n, rel0, c0, ok0)
                    return
                for rel1_vals in product(ATOMS, repeat=n+1):
                    rel1 = dict(zip(nodes0, rel1_vals))
                    c1,_ = one_point_criterion(net0,nodes0,rel1)
                    net1,nodes1 = add_point(net0,nodes0,e1,rel1)
                    ok1,_ = is_closed(net1,nodes1)
                    if c0 and c1:
                        total_seq += 1
                        if not ok1:
                            seq_bad += 1
                    if ok1:
                        total_closed += 1
                        if not (c0 and c1):
                            closed_not_seq += 1
        print(f"n={n}: closed_pockets={len(pockets)} seq_extensions={total_seq} closed_extensions={total_closed} seq_bad={seq_bad} closed_not_seq={closed_not_seq}")

def example_split_lower_connectors():
    print("\nExample: two DR-separated nodes cannot share a lower connector, but can use split lower connectors.")
    # Pocket B # D
    B,D = "B","D"
    pocket = {}
    set_edge(pocket,B,D,"DR")
    nodes = (B,D)
    ok,_ = is_closed(pocket,nodes)
    assert ok
    # Common lower L below both: invalid
    L = "L"
    relL = {B:"PP", D:"PP"}  # L PP B and L PP D
    c,why = one_point_criterion(pocket,nodes,relL)
    netL,nodesL = add_point(pocket,nodes,L,relL)
    okL,badL = is_closed(netL,nodesL)
    print("  common lower trace L->B=PP, L->D=PP:", "criterion", c, why, "closed", okL)
    # Split lower connector LB below B, disjoint D; then LD below D, disjoint B and LB.
    LB = "LB"
    relLB = {B:"PP", D:"DR"}
    c1,why1 = one_point_criterion(pocket,nodes,relLB)
    net1,nodes1 = add_point(pocket,nodes,LB,relLB)
    ok1,_ = is_closed(net1,nodes1)
    LD = "LD"
    relLD = {B:"DR", D:"PP", LB:"DR"}
    c2,why2 = one_point_criterion(net1,nodes1,relLD)
    net2,nodes2 = add_point(net1,nodes1,LD,relLD)
    ok2,bad2 = is_closed(net2,nodes2)
    print("  split LB below B/disjoint D:", "criterion", c1, why1, "closed", ok1)
    print("  split LD below D/disjoint B,LB:", "criterion", c2, why2, "closed", ok2)
    for x,y in [(LB,B),(LB,D),(LD,D),(LD,B),(LB,LD)]:
        print(f"    {x}->{y} = {get(net2,x,y)}")

if __name__ == "__main__":
    test_sequential(3)
    example_split_lower_connectors()
