#!/usr/bin/env python3
"""
WP73: bounded trace alphabet for finite extension-basis search.

This probe illustrates the next abstraction step after WP71/WP72.
For a fixed finite RCC5 pocket P and a fixed endpoint-compatibility mask
for a new connector e, the possible connector behaviours are a finite
trace alphabet.  The trace is (U,L,D), where
  U = {x in P : e PP x}
  L = {x in P : e PPI x}
  D = {x in P : e DR x}
and all other pocket nodes are e PO x.

The WP71 criterion characterizes RCC5-consistent traces.  Here we add
endpoint masks: for each x, only some atoms from {PP,PPI,DR,PO} are type-
compatible for e -> x.  The valid trace alphabet is the finite set of
WP71-consistent traces respecting the masks.

The script enumerates all closed pockets up to size 4 and summarizes the
maximum number of valid traces under unconstrained masks, then samples
random masks to show that type compatibility just prunes this finite
alphabet.  This supports the bounded-basis-search theorem: for a fixed
pocket size and connector budget, extension-basis existence is a finite
search problem.  It does not prove the global bounded-budget lemma.
"""
from itertools import product, combinations
from random import Random

ATOMS = ("PP", "PPI", "DR", "PO")
CONV = {"PP":"PPI", "PPI":"PP", "DR":"DR", "PO":"PO", "EQ":"EQ"}

# RCC5 composition table for proper atoms plus EQ, derived from small-set semantics.
def rcc5_rel(a,b):
    if a == b:
        return "EQ"
    if a < b:
        return "PP"
    if b < a:
        return "PPI"
    if a.isdisjoint(b):
        return "DR"
    return "PO"

def derive_comp():
    universe = list(range(5))
    subs = []
    for mask in range(1, 1 << len(universe)):
        subs.append(frozenset(i for i in universe if mask & (1 << i)))
    comp = {(r,s): set() for r in ("EQ",)+ATOMS for s in ("EQ",)+ATOMS}
    for x in subs:
        for y in subs:
            r = rcc5_rel(x,y)
            for z in subs:
                s = rcc5_rel(y,z)
                t = rcc5_rel(x,z)
                comp[(r,s)].add(t)
    return comp
COMP = derive_comp()

def rel_from_matrix(mat, i, j):
    if i == j:
        return "EQ"
    return mat[(i,j)]

def closed_network(n, mat):
    for i in range(n):
        for j in range(n):
            for k in range(n):
                r = rel_from_matrix(mat,i,j)
                s = rel_from_matrix(mat,j,k)
                t = rel_from_matrix(mat,i,k)
                if t not in COMP[(r,s)]:
                    return False
    return True

def all_networks(n):
    pairs = [(i,j) for i in range(n) for j in range(i+1,n)]
    for labels in product(ATOMS, repeat=len(pairs)):
        mat = {}
        for (i,j), r in zip(pairs, labels):
            mat[(i,j)] = r
            mat[(j,i)] = CONV[r]
        yield mat

def poset_disj(n, mat):
    # Return order < and disjointness # from an RCC5 matrix.
    less = set()
    disj = set()
    for i in range(n):
        for j in range(n):
            if i == j: continue
            r = mat[(i,j)]
            if r == "PP": less.add((i,j))
            if r == "DR": disj.add((i,j))
    return less, disj

def leq(less, x, y):
    return x == y or (x,y) in less

def wp71_trace_ok(n, mat, trace):
    """trace is tuple of atoms e->x for x=0..n-1."""
    less, disj = poset_disj(n, mat)
    U = {i for i,r in enumerate(trace) if r == "PP"}
    L = {i for i,r in enumerate(trace) if r == "PPI"}
    D = {i for i,r in enumerate(trace) if r == "DR"}
    # U upward closed
    for x in U:
        for y in range(n):
            if (x,y) in less and y not in U:
                return False
    # U disjoint closure into D
    for x in U:
        for y in range(n):
            if (x,y) in disj and y not in D:
                return False
    # L downward closed
    for x in L:
        for y in range(n):
            if (y,x) in less and y not in L:
                return False
    # L below U already
    for ell in L:
        for u in U:
            if (ell,u) not in less:
                return False
    # D downward closed
    for x in D:
        for y in range(n):
            if leq(less,y,x) and y not in D:
                return False
    # L disjoint from D already
    for ell in L:
        for d in D:
            if (ell,d) not in disj:
                return False
    return True

def valid_traces(n, mat, masks=None):
    if masks is None:
        masks = [set(ATOMS) for _ in range(n)]
    out = []
    for tr in product(ATOMS, repeat=n):
        if all(tr[i] in masks[i] for i in range(n)) and wp71_trace_ok(n, mat, tr):
            out.append(tr)
    return out

def summarize_closed_pockets(maxn=4):
    print("WP73 bounded trace alphabet")
    print("For each closed pocket, count WP71-valid one-connector traces under unconstrained masks.")
    for n in range(1, maxn+1):
        closed = 0
        max_traces = 0
        min_traces = 10**9
        total_traces = 0
        example_max = None
        for mat in all_networks(n):
            if not closed_network(n, mat):
                continue
            closed += 1
            k = len(valid_traces(n, mat))
            total_traces += k
            if k > max_traces:
                max_traces = k; example_max = mat
            if k < min_traces:
                min_traces = k
        avg = total_traces / closed if closed else 0
        print(f"n={n}: closed_pockets={closed} min={min_traces} max={max_traces} avg={avg:.2f} raw_bound={4**n}")
    print()

def sample_masks(n=4, samples=200, seed=73):
    rng = Random(seed)
    mats = [mat for mat in all_networks(n) if closed_network(n, mat)]
    mat = rng.choice(mats)
    base = len(valid_traces(n, mat))
    print(f"Random mask pruning on one closed pocket of size {n}: base_valid_traces={base}")
    counts = []
    nonempty = 0
    for _ in range(samples):
        masks = []
        for _i in range(n):
            # random nonempty subset of ATOMS
            s = {a for a in ATOMS if rng.random() < 0.55}
            if not s:
                s.add(rng.choice(ATOMS))
            masks.append(s)
        c = len(valid_traces(n, mat, masks))
        counts.append(c)
        if c: nonempty += 1
    print(f"  samples={samples} nonempty={nonempty} min={min(counts)} max={max(counts)} avg={sum(counts)/samples:.2f}")
    print("  Interpretation: endpoint type compatibility only prunes a finite trace alphabet.")
    print()

def transition_graph_toy():
    """A tiny toy boundary automaton: profiles A,B with a pocket A PO B.
    Boundary connector e may be PP to both (interval) or DR to both (envelope),
    depending on masks.  We show the finite transition graph of trace signatures.
    """
    n=2
    mat = {(0,1):"PO", (1,0):"PO"}
    assert closed_network(n, mat)
    traces = valid_traces(n, mat)
    # signature by relation to A,B
    print("Toy pocket A PO B: finite trace alphabet")
    for tr in traces:
        print(" ", tr)
    print(f"  count={len(traces)} raw_bound={4**n}")
    print("  A recursive basis can use these traces as finite boundary states.")
    print()

if __name__ == "__main__":
    summarize_closed_pockets(4)
    sample_masks(4, 200)
    transition_graph_toy()
