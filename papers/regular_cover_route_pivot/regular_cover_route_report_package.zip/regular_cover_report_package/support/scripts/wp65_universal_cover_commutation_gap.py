#!/usr/bin/env python3
"""
WP64: Universal-cover / commutation-gap probe.

This is not an RCC5 table probe. It is a finite-model-theoretic sanity check
for the regular-cover direction.

The point illustrated here is the standard 'grid coincidence' gap:
local unary/binary witness requirements plus 3-variable edge-colour coherence
can force E/N successor and predecessor structure, and even functionality, but
cannot force the 4-variable commuting-square equality

    E(N(x)) = N(E(x)).

A regular universal cover of the finite two-loop graph -- the Cayley tree of the
free group on E,N -- satisfies the local successor/predecessor/functionality
constraints but has EN(x) != NE(x).

This mirrors the RCC5 situation: coherent regular covers can unravel attempted
coordinate systems into regular noncommuting covers unless the logic has a way
to force the coincidence square.
"""
from collections import defaultdict

GENS = ['E','N','e','n']  # e=E^-1, n=N^-1
INV = {'E':'e','e':'E','N':'n','n':'N'}


def reduce_word(w):
    st=[]
    for g in w:
        if st and INV[g] == st[-1]:
            st.pop()
        else:
            st.append(g)
    return tuple(st)


def mul(w,g):
    return reduce_word(tuple(w)+(g,))


def ball(depth):
    seen={()}
    frontier=[()]
    for _ in range(depth):
        nxt=[]
        for w in frontier:
            for g in GENS:
                v=mul(w,g)
                if v not in seen:
                    seen.add(v); nxt.append(v)
        frontier=nxt
    return seen


def interior(nodes, margin=1):
    # nodes whose all generator neighbours are present
    return {w for w in nodes if all(mul(w,g) in nodes for g in GENS)}


def check_local(nodes):
    """Check local two-way/functionality constraints on the interior."""
    ints=interior(nodes)
    errors=[]
    for x in ints:
        # total successors and predecessors for E,N on interior
        for g in ['E','N','e','n']:
            y=mul(x,g)
            if y not in nodes:
                errors.append((x,'missing',g,y))
        # functionality is automatic for functions, but check unique images in finite relation graph
        for g in ['E','N']:
            imgs=[y for y in nodes if y==mul(x,g)]
            if len(imgs)!=1:
                errors.append((x,'nonfunctional',g,imgs))
        # inverse consistency
        if mul(mul(x,'E'),'e') != x: errors.append((x,'bad inverse E'))
        if mul(mul(x,'N'),'n') != x: errors.append((x,'bad inverse N'))
    return errors


def diamond_failures(nodes):
    ints={w for w in nodes if all(mul(mul(w,a),b) in nodes for a,b in [('E','N'),('N','E')] )}
    fails=[]
    for x in ints:
        en=mul(mul(x,'E'),'N')
        ne=mul(mul(x,'N'),'E')
        if en != ne:
            fails.append((x,en,ne))
    return fails


def wordstr(w):
    return ''.join(w) if w else '1'


def main():
    for d in [2,3,4,5,6]:
        nodes=ball(d)
        ints=interior(nodes)
        errs=check_local(nodes)
        fails=diamond_failures(nodes)
        print(f"depth={d}: nodes={len(nodes)} interior={len(ints)} local_errors={len(errs)} diamond_failures={len(fails)}")
        if d==4:
            print("  sample diamond failures EN(x) != NE(x):")
            for x,en,ne in fails[:5]:
                print(f"    x={wordstr(x):>4s}: EN={wordstr(en):>6s}  NE={wordstr(ne):>6s}")
    print("\nConclusion:")
    print("  The finite local successor/predecessor/functionality checks pass on interiors,")
    print("  but the commuting-square equation EN(x)=NE(x) systematically fails.")
    print("  The missing equation is a 4-variable coincidence condition, not a 3-variable")
    print("  pair-colour composition condition.")

if __name__ == '__main__':
    main()
