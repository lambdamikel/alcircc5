#!/usr/bin/env python3
"""
WP69: Envelope guard for arbitrary finite RCC5 pockets.

Given any finite strong-EQ RCC5 pocket/network P, add two fresh connector
points L,U with:
  L PP U,
  x PP U for every pocket node x,
  L DR x for every pocket node x.
Internal pocket relations are preserved.
The resulting network should remain RCC5 composition-closed.

Intuition in (<,#) normal form:
  PP is strict order <, DR is disjointness # downward-closed.
  Adding a common upper U above all pocket nodes is harmless.
  Adding L disjoint from every pocket node and L<U is harmless.
  This is a universal envelope/isolation guard for a finite pocket.

The script exhaustively checks all closed atomic RCC5 pockets up to n=4,
and random pockets up to n=8. It also shows why the naive interval guard
(common lower below all pocket nodes) fails when the pocket has internal DR.
"""
from itertools import combinations, product
import random

ATOMS = ["DR", "PO", "PP", "PPI"]
ALL = ["EQ"] + ATOMS
CONV = {"EQ":"EQ", "DR":"DR", "PO":"PO", "PP":"PPI", "PPI":"PP"}

def rel_sets(a,b):
    # derive RCC5 atom between nonempty finite sets a,b
    if a == b:
        return "EQ"
    if a.isdisjoint(b):
        return "DR"
    if a < b:
        return "PP"
    if a > b:
        return "PPI"
    return "PO"

def derive_comp():
    # finite universe of 3 atoms suffices for RCC5 base table
    universe = set(range(4))
    subs = [frozenset(s) for r in range(1,4) for s in combinations(universe,r)]
    comp = {(r,s): set() for r in ALL for s in ALL}
    for X in subs:
        for Y in subs:
            r = rel_sets(X,Y)
            for Z in subs:
                s = rel_sets(Y,Z)
                t = rel_sets(X,Z)
                comp[(r,s)].add(t)
    return comp
COMP = derive_comp()

def atom(net, i, j):
    if i == j:
        return "EQ"
    return net.get((i,j))

def set_atom(net, i, j, r):
    if i == j:
        assert r == "EQ"
    else:
        net[(i,j)] = r
        net[(j,i)] = CONV[r]

def closed_errors(nodes, net, max_errors=10):
    errs=[]
    for x in nodes:
        for y in nodes:
            for z in nodes:
                r=atom(net,x,y); s=atom(net,y,z); t=atom(net,x,z)
                if t not in COMP[(r,s)]:
                    errs.append((x,y,z,r,s,t,sorted(COMP[(r,s)])))
                    if len(errs)>=max_errors:
                        return errs
    return errs

def complete_network_from_upper(n, labels):
    # labels over unordered pairs i<j; label is relation i->j
    nodes=list(range(n))
    net={}
    for (i,j),r in zip(combinations(nodes,2), labels):
        set_atom(net,i,j,r)
    return nodes, net

def add_envelope(nodes, net):
    # make fresh L,U; internal pocket preserved; L PP U, x PP U, L DR x.
    out=dict(net)
    L="L"; U="U"
    new_nodes=[L] + list(nodes) + [U]
    set_atom(out, L, U, "PP")
    for x in nodes:
        set_atom(out, x, U, "PP")
        set_atom(out, L, x, "DR")
    return new_nodes, out

def add_bad_common_lower(nodes, net):
    # naive interval guard: L below all pocket nodes, all below U.
    out=dict(net)
    L="L"; U="U"
    new_nodes=[L] + list(nodes) + [U]
    set_atom(out, L, U, "PP")
    for x in nodes:
        set_atom(out, L, x, "PP")
        set_atom(out, x, U, "PP")
    return new_nodes, out

def exhaustive(n):
    pairs=list(combinations(range(n),2))
    total=0; closed=0; env_fail=0; bad_lower_fail_on_dr=0; bad_lower_total_dr=0
    for labels in product(ATOMS, repeat=len(pairs)):
        total += 1
        nodes,net=complete_network_from_upper(n, labels)
        if closed_errors(nodes,net,1):
            continue
        closed += 1
        enodes,enet=add_envelope(nodes,net)
        if closed_errors(enodes,enet,1):
            env_fail += 1
            break
        has_dr=any(atom(net,i,j)=="DR" for i,j in combinations(nodes,2))
        if has_dr:
            bad_lower_total_dr += 1
            bnodes,bnet=add_bad_common_lower(nodes,net)
            if closed_errors(bnodes,bnet,1):
                bad_lower_fail_on_dr += 1
    return total, closed, env_fail, bad_lower_fail_on_dr, bad_lower_total_dr

def random_poset(n, p=0.25):
    # create acyclic order by natural index orientation, then transitive closure.
    less=set()
    for i in range(n):
        for j in range(i+1,n):
            if random.random()<p:
                less.add((i,j))
    changed=True
    while changed:
        changed=False
        for i,j in list(less):
            for k,l in list(less):
                if j==k and (i,l) not in less:
                    less.add((i,l)); changed=True
    return less

def random_ordered_disjoint(n):
    nodes=list(range(n))
    less=random_poset(n, random.uniform(0.1,0.35))
    # choose random DR seeds among incomparable pairs, downward close.
    disj=set()
    incomps=[(i,j) for i,j in combinations(nodes,2) if (i,j) not in less and (j,i) not in less]
    for i,j in incomps:
        if random.random()<0.18:
            disj.add(tuple(sorted((i,j))))
    # downward closure; if conflict arises, drop conflicting seed by retry recursively.
    changed=True
    while changed:
        changed=False
        for a,b in list(disj):
            lows_a=[x for x in nodes if x==a or (x,a) in less]
            lows_b=[y for y in nodes if y==b or (y,b) in less]
            for x in lows_a:
                for y in lows_b:
                    if x==y or (x,y) in less or (y,x) in less:
                        return random_ordered_disjoint(n)
                    key=tuple(sorted((x,y)))
                    if key not in disj:
                        disj.add(key); changed=True
    net={}
    for i,j in combinations(nodes,2):
        if (i,j) in less:
            r="PP"
        elif (j,i) in less:
            r="PPI"
        elif tuple(sorted((i,j))) in disj:
            r="DR"
        else:
            r="PO"
        set_atom(net,i,j,r)
    assert not closed_errors(nodes,net,1)
    return nodes,net

def random_test(ns=(5,6,7,8), trials=200):
    rows=[]
    for n in ns:
        fail=0
        for _ in range(trials):
            nodes,net=random_ordered_disjoint(n)
            enodes,enet=add_envelope(nodes,net)
            if closed_errors(enodes,enet,1):
                fail += 1
                break
        rows.append((n,trials,fail))
    return rows

def demo_internal_dr_failure():
    nodes=["a","b"]
    net={}
    set_atom(net,"a","b","DR")
    bnodes,bnet=add_bad_common_lower(nodes,net)
    errs=closed_errors(bnodes,bnet,5)
    enodes,enet=add_envelope(nodes,net)
    eerrs=closed_errors(enodes,enet,5)
    return errs,eerrs

if __name__ == "__main__":
    print("WP69: envelope guard for arbitrary finite RCC5 pockets")
    print("Composition singleton cells of interest:")
    for k in [("PP","PP"),("PP","DR"),("DR","PPI"),("PPI","PPI")]:
        print(f"  {k[0]};{k[1]} -> {sorted(COMP[k])}")
    print("\nExhaustive pockets n<=4:")
    for n in range(1,5):
        total,closed,env_fail,bad_fail,bad_dr=exhaustive(n)
        print(f"  n={n}: total={total} closed={closed} envelope_failures={env_fail} naive_lower_failures_on_DR={bad_fail}/{bad_dr}")
    print("\nRandom ordered-disjoint pockets:")
    for n,trials,fail in random_test():
        print(f"  n={n}: trials={trials} envelope_failures={fail}")
    errs,eerrs=demo_internal_dr_failure()
    print("\nMinimal internal-DR demo:")
    print(f"  naive common lower errors={len(errs)} sample={errs[:1]}")
    print(f"  envelope guard errors={len(eerrs)}")
    print("\nConclusion:")
    print("  Any finite closed RCC5 pocket can be isolated from a lower connector by making the connector DR from every pocket node and placing the whole pocket below a fresh upper connector.")
    print("  A common lower part below all pocket nodes is not safe when the pocket contains internal DR.")
