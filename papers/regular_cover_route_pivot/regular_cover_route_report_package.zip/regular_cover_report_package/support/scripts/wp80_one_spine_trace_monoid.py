#!/usr/bin/env python3
"""
WP80: one-spine trace-transfer monoids for finite RCC5 extension blocks.

For a fixed finite block with one inherited boundary port L and one outgoing
continuation port C, enumerate all possible relations from an old outside point X
to the fresh block, conditional on the relation X->L.  Project this to X->C.
The resulting finite relation on the four proper RCC5 atoms is the one-spine
trace transfer.  Iterating a fixed block therefore has finite-state behaviour.
"""
from itertools import product, combinations

ATOMS = ["PP", "PPI", "PO", "DR"]
ALL = ["EQ"] + ATOMS
INV = {"EQ":"EQ", "PP":"PPI", "PPI":"PP", "PO":"PO", "DR":"DR"}


def rcc5(a,b):
    if a == b:
        return "EQ"
    if a < b:
        return "PP"
    if a > b:
        return "PPI"
    if a.isdisjoint(b):
        return "DR"
    return "PO"


def derive_comp(n=5):
    U = set(range(n))
    regs = [frozenset(s) for k in range(1,n+1) for s in combinations(U,k)]
    comp = {r:{s:set() for s in ALL} for r in ALL}
    for a in regs:
        for b in regs:
            r = rcc5(a,b)
            for c in regs:
                s = rcc5(b,c)
                t = rcc5(a,c)
                comp[r][s].add(t)
    return comp

COMP = derive_comp()


def rel_table_from_sets(sets):
    names = list(sets)
    rel = {}
    for x in names:
        for y in names:
            rel[(x,y)] = rcc5(sets[x], sets[y])
    return names, rel


def check_closed(names, rel):
    errs=[]
    for x in names:
        for y in names:
            for z in names:
                a,b,c = rel[(x,y)], rel[(y,z)], rel[(x,z)]
                if c not in COMP[a][b]:
                    errs.append((x,y,z,a,b,c,sorted(COMP[a][b])))
    return errs


def enumerate_transfer(block_name, sets, boundary, outgoing):
    names, base = rel_table_from_sets(sets)
    errs = check_closed(names, base)
    print(f"=== {block_name} ===")
    print(f"block nodes={names} boundary={boundary} outgoing={outgoing} closed_errors={len(errs)}")
    if errs:
        print("sample block error", errs[0])
        print()
        return

    fresh = [n for n in names if n != boundary]
    # Fresh includes outgoing and local ports; L is inherited.
    transfer = {r:set() for r in ATOMS}
    full_counts = {r:0 for r in ATOMS}
    sample = {r:[] for r in ATOMS}

    for r_to_L in ATOMS:
        for vals in product(ATOMS, repeat=len(fresh)):
            rel = dict(base)
            allnames = names + ["X"]
            # X to boundary
            rel[("X", boundary)] = r_to_L
            rel[(boundary, "X")] = INV[r_to_L]
            # X to fresh ports
            for f, rf in zip(fresh, vals):
                rel[("X", f)] = rf
                rel[(f, "X")] = INV[rf]
            rel[("X","X")] = "EQ"
            ok = not check_closed(allnames, rel)
            if ok:
                out = rel[("X", outgoing)]
                transfer[r_to_L].add(out)
                full_counts[r_to_L] += 1
                if len(sample[r_to_L]) < 3:
                    sample[r_to_L].append({f: rel[("X",f)] for f in fresh})
    print("one-spine transfer relation X->boundary  ==> possible X->outgoing")
    for r in ATOMS:
        print(f"  {r:3s} -> {sorted(transfer[r])}   full fresh traces={full_counts[r]}")
        for s in sample[r][:2]:
            print(f"       sample {s}")

    # Compute reachable sets under iteration from each atom.
    print("iteration closure on boundary trace states")
    for start in ATOMS:
        seen = {start}
        frontier = {start}
        steps = 0
        while frontier:
            nxt=set()
            for r in frontier:
                nxt |= transfer[r]
            nxt -= seen
            if nxt:
                seen |= nxt
                frontier = nxt
                steps += 1
            else:
                break
        print(f"  start {start:3s}: reachable={sorted(seen)} stabilized_after<={steps} expansions")
    print()


def main():
    # Interval pocket: L < A,B < C and A PO B.
    interval_sets = {
        "L": frozenset({0}),
        "A": frozenset({0,1}),
        "B": frozenset({0,2}),
        "C": frozenset({0,1,2,3}),
    }
    enumerate_transfer("interval PO-pocket block", interval_sets, "L", "C")

    # Separated star: L<A<C, B<C, D<C, L DR B,D, A PO B,D, B DR D.
    sep_sets = {
        "L": frozenset({0}),
        "A": frozenset({0,1,3,5}),
        "B": frozenset({1,2}),
        "D": frozenset({3,4}),
        "C": frozenset({0,1,2,3,4,5,6}),
    }
    enumerate_transfer("separated-star multi-witness block", sep_sets, "L", "C")

    # Envelope: L DR pocket, all pocket nodes and L below U.
    env_sets = {
        "L": frozenset({0}),
        "A": frozenset({1,3,5}),
        "B": frozenset({1,2}),
        "D": frozenset({3,4}),
        "U": frozenset({0,1,2,3,4,5,6}),
    }
    enumerate_transfer("envelope-isolated multi-witness block", env_sets, "L", "U")

    print("Conclusion: for every fixed one-boundary/one-continuation block tested, old-to-boundary traces evolve by a finite relation on the four RCC5 atoms.  More generally, with k boundary ports the state space is at most 4^k, so one-spine recursion through a fixed finite block is finite-state.")

if __name__ == "__main__":
    main()
