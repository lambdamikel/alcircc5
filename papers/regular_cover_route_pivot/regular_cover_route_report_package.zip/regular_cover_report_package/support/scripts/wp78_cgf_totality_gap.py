#!/usr/bin/env python3
"""WP78: why standard guarded/clique-guarded unravelling does not by itself
solve RCC5 complete-edge models.

A guarded tree cover may preserve local bags while leaving non-bag pairs
uncoloured. RCC5 semantics requires every pair to be coloured, and composition
constraints can force the colour of a pair that is not in any local bag.
"""
from itertools import combinations

REL = ["EQ", "PP", "PPI", "PO", "DR"]
PROPER = ["PP", "PPI", "PO", "DR"]
CONV = {"EQ":"EQ", "PP":"PPI", "PPI":"PP", "PO":"PO", "DR":"DR"}

def rcc5(a,b):
    a=set(a); b=set(b)
    if a==b: return "EQ"
    if a < b: return "PP"
    if b < a: return "PPI"
    if a.isdisjoint(b): return "DR"
    return "PO"

def derive_comp(n=4):
    atoms=list(range(n))
    regs=[]
    for mask in range(1,1<<n):
        regs.append(frozenset(i for i in atoms if mask>>i & 1))
    comp={(r,s):set() for r in REL for s in REL}
    for x in regs:
        for y in regs:
            r=rcc5(x,y)
            for z in regs:
                s=rcc5(y,z)
                t=rcc5(x,z)
                comp[(r,s)].add(t)
    return comp

COMP=derive_comp()

def allowed(r,s):
    return sorted(COMP[(r,s)], key=REL.index)

examples=[
    ("two PP bags", "PP", "PP"),
    ("PP followed by DR", "PP", "DR"),
    ("PO followed by PP", "PO", "PP"),
    ("PO followed by DR", "PO", "DR"),
]

print("WP78 guarded-cover/total-edge gap")
print("A partial guarded cover may contain only bags {a,b} and {b,c}.")
print("The non-bag pair {a,c} still must receive an RCC5 atom in a total model.\n")

for name,r,s in examples:
    al=allowed(r,s)
    print(f"Example: {name}")
    print(f"  local bag 1: a {r} b")
    print(f"  local bag 2: b {s} c")
    print(f"  locally, the two bags are consistent without any a-c edge.")
    print(f"  but total RCC5 completion requires a-c in comp({r},{s}) = {al}")
    if len(al)==1:
        print(f"  singleton forcing: a-c must be {al[0]}")
    print()

# Minimal failure of arbitrary completion for PP;PP
r,s="PP","PP"
print("Arbitrary completion failure for PP;PP:")
for t in PROPER:
    ok=t in COMP[(r,s)]
    print(f"  choosing a {t} c: {'OK' if ok else 'BAD'}")
print()
print("Conclusion:")
print("  Guarded/local bag consistency does not determine a complete RCC5 model.")
print("  Completing non-bag pairs is a global triangle-coherent edge-colouring problem.")
print("  This is exactly what the coherent regular-cover certificate must include via")
print("  pair colours and realized triple patterns.")
