#!/usr/bin/env python3
"""
WP46 -- no global RCC5 path-composition atom selector.

This checks a tempting regular-cover proof shortcut.  Let S,T be non-empty
sets of RCC5 atoms and let S*T be their complex composition.  A canonical
path selector would choose an atom sigma(S) in S, fixed on singletons and
respecting converse, such that

    sigma(S*T) in comp(sigma(S), sigma(T))

for all non-empty S,T.  Such a selector would let one label arbitrary
unfolded path-composition domains by a single atom in a uniformly
composition-safe way.  The exhaustive finite search below shows that no such
selector exists for RCC5.  Therefore the regular-cover route needs richer
address-sensitive automata; it cannot be closed by a one-state canonical
selector on composition domains.
"""
from itertools import combinations

BASE = ("EQ", "PP", "PPI", "PO", "DR")
CONV = {"EQ":"EQ", "PP":"PPI", "PPI":"PP", "PO":"PO", "DR":"DR"}

def rel(A, B):
    if A == B: return "EQ"
    if A.isdisjoint(B): return "DR"
    if A < B: return "PP"
    if B < A: return "PPI"
    return "PO"

def derive_comp(n=5):
    U = range(n)
    subs = [frozenset(c) for k in range(1, n+1) for c in combinations(U, k)]
    tab = {(r,s): set() for r in BASE for s in BASE}
    for A in subs:
        for B in subs:
            for C in subs:
                tab[(rel(A,B), rel(B,C))].add(rel(A,C))
    return {k: frozenset(v) for k,v in tab.items()}

COMP = derive_comp()
ALLSETS = []
for k in range(1, len(BASE)+1):
    for c in combinations(BASE, k):
        ALLSETS.append(frozenset(c))

def conv_set(S):
    return frozenset(CONV[a] for a in S)

def cmul(S, T):
    out = set()
    for a in S:
        for b in T:
            out |= set(COMP[(a,b)])
    return frozenset(out)

# Assign singletons as required.
assign = {frozenset([a]): a for a in BASE}
VARS = [S for S in ALLSETS if len(S) > 1]
VARS.sort(key=lambda S: (len(S), tuple(sorted(S))))

def local_ok(S, a):
    if a not in S:
        return False
    CS = conv_set(S)
    if CS in assign and assign[CS] != CONV[a]:
        return False
    # Check all currently determined multiplicative constraints involving S.
    for T, t in list(assign.items()):
        P = cmul(S, T)
        if P in assign and assign[P] not in COMP[(a, t)]:
            return False
        P = cmul(T, S)
        if P in assign and assign[P] not in COMP[(t, a)]:
            return False
    P = cmul(S, S)
    if P in assign and assign[P] not in COMP[(a, a)]:
        return False
    return True

def full_ok():
    for S, s in assign.items():
        if s not in S:
            return False
        if assign.get(conv_set(S)) != CONV[s]:
            return False
    for S, s in assign.items():
        for T, t in assign.items():
            P = cmul(S, T)
            if P in assign and assign[P] not in COMP[(s, t)]:
                return False
    return True

nodes = 0

def choose_var():
    best = None
    best_dom = None
    for S in VARS:
        if S not in assign:
            dom = [a for a in sorted(S) if local_ok(S, a)]
            if best is None or len(dom) < len(best_dom):
                best, best_dom = S, dom
                if not dom:
                    break
    return best, best_dom

def search():
    global nodes
    nodes += 1
    if len(assign) == len(ALLSETS):
        return full_ok()
    S, dom = choose_var()
    if not dom:
        return False
    for a in dom:
        saved = dict(assign)
        assign[S] = a
        CS = conv_set(S)
        if CS not in assign:
            ca = CONV[a]
            if ca in CS and local_ok(CS, ca):
                assign[CS] = ca
            else:
                assign.clear(); assign.update(saved); continue
        if full_ok() and search():
            return True
        assign.clear(); assign.update(saved)
    return False

if __name__ == "__main__":
    sat = search()
    print("global_selector_exists =", sat)
    print("search_nodes =", nodes)
    assert not sat
    print("PASS: no singleton-fixed, converse-respecting, multiplicatively coherent atom selector exists for RCC5 complex domains.")
