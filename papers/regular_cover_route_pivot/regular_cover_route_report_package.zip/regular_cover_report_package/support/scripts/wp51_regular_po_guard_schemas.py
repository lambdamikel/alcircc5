#!/usr/bin/env python3
"""
WP51: Regular PO-guard schemas for the regular-cover route.

This probe illustrates a full-logic phenomenon that static type-level
PO guards miss but regular covers handle: an unsafe pair of types P,Q
may need both P< Q and Q< P occurrences, so neither static guard
'P below Q' nor 'Q below P' is adequate. A periodic vertical chain
... P < Q < P < Q ... guards every P/Q pair by comparability while
still providing both PP and PPI witnesses of type Q for type P and vice versa
away from finite endpoints.

The script checks finite windows of the periodic chain using the
ordered-disjoint RCC5 normal form (< plus downward-closed #). Here # is empty,
so every distinct pair in the chain is comparable and hence never PO.
"""
from itertools import combinations, product

ATOMS = ["EQ","PP","PPI","PO","DR"]

def atom(i,j):
    if i == j: return "EQ"
    if i < j: return "PP"
    if j < i: return "PPI"
    raise AssertionError

# RCC5 composition table from finite set semantics over universe of size 4.
def rel(a,b):
    if a == b: return "EQ"
    if a < b: return "PP"
    if b < a: return "PPI"
    if a.isdisjoint(b): return "DR"
    return "PO"

def derive_comp():
    U = range(4)
    regs = [frozenset(s) for m in range(1,1<<4) for s in [[i for i in U if (m>>i)&1]]]
    comp = {(r,s):set() for r in ATOMS for s in ATOMS}
    for x in regs:
        for y in regs:
            r = rel(x,y)
            for z in regs:
                s = rel(y,z)
                comp[(r,s)].add(rel(x,z))
    return comp

COMP = derive_comp()

def check_rcc5_closure(n):
    # finite chain positions 0..n-1 with empty #
    errors = []
    for i,j,k in product(range(n), repeat=3):
        r = atom(i,j)
        s = atom(j,k)
        t = atom(i,k)
        if t not in COMP[(r,s)]:
            errors.append((i,j,k,r,s,t,COMP[(r,s)]))
            break
    return errors

def typ(i):
    return "P" if i % 2 == 0 else "Q"

def witness_summary(n):
    """For interior positions, record whether each type has PP/PPI witness of other type."""
    out = {"P":{"PP_Q":False,"PPI_Q":False}, "Q":{"PP_P":False,"PPI_P":False}}
    for i in range(n):
        t = typ(i)
        for j in range(n):
            if i == j: continue
            if t == "P" and typ(j) == "Q":
                if i < j: out["P"]["PP_Q"] = True
                if j < i: out["P"]["PPI_Q"] = True
            if t == "Q" and typ(j) == "P":
                if i < j: out["Q"]["PP_P"] = True
                if j < i: out["Q"]["PPI_P"] = True
    return out

def count_po_between_PQ(n):
    c = 0
    for i,j in product(range(n), repeat=2):
        if typ(i) != typ(j) and atom(i,j) == "PO":
            c += 1
    return c

def static_guard_obstruction():
    # A static type-level guard P<Q provides P PP Q but never P PPI Q;
    # Q<P provides the converse. If both existential directions are required,
    # neither static orientation suffices. Static DR also gives no PP/PPI witnesses.
    return {
        "static_P_below_Q_satisfies": ["P has PP Q", "Q has PPI P"],
        "static_P_below_Q_misses": ["P has PPI Q", "Q has PP P"],
        "static_Q_below_P_satisfies": ["P has PPI Q", "Q has PP P"],
        "static_Q_below_P_misses": ["P has PP Q", "Q has PPI P"],
        "static_DR_misses": ["all vertical PP/PPI witnesses"]
    }

if __name__ == "__main__":
    print("WP51: regular vertical guard schema for bidirectional PO-unsafe type pairs")
    print("RCC5 singleton checks relevant to vertical chains:")
    print("  PP;PP =", sorted(COMP[("PP","PP")]))
    print("  PPI;PPI =", sorted(COMP[("PPI","PPI")]))
    print()
    for n in [3,4,5,8,12]:
        errs = check_rcc5_closure(n)
        summ = witness_summary(n)
        po_pq = count_po_between_PQ(n)
        print(f"prefix n={n}: closure_errors={len(errs)} PO_between_PQ={po_pq} witnesses={summ}")
    print()
    print("Static guard obstruction for requirements:")
    print("  P requires exists PP.Q and exists PPI.Q")
    print("  Q requires exists PP.P and exists PPI.P")
    obs = static_guard_obstruction()
    for k,v in obs.items():
        print(f"  {k}: {', '.join(v)}")
    print()
    print("Conclusion: a finite regular cover with periodic vertical order P<Q<P<Q<... guards all P/Q pairs without PO and supplies both directions; a static type-level guard cannot.")
