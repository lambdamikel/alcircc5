#!/usr/bin/env python3
"""
WP55: SCC vertical lift for cyclic order guards.

A finite order-guard graph may be cyclic at the type/component level.  Such a
cycle is not a cycle in the unfolded PP order if it is realized as a periodic
vertical component.  The sufficient condition is simple: inside every SCC, all
ordered type pairs that will appear in the periodic total order must be PP-
compatible.  Between SCCs, the quotient order must be PP-compatible from lower
to upper.

This is a finite check for a useful class of regular PO guards.
"""

def sccs(n, edges):
    g=[[] for _ in range(n)]
    rg=[[] for _ in range(n)]
    for i,j in edges:
        g[i].append(j); rg[j].append(i)
    seen=[False]*n; order=[]
    def dfs(v):
        seen[v]=True
        for w in g[v]:
            if not seen[w]: dfs(w)
        order.append(v)
    for i in range(n):
        if not seen[i]: dfs(i)
    comp=[-1]*n; comps=[]
    def rdfs(v,c):
        comp[v]=c; comps[c].append(v)
        for w in rg[v]:
            if comp[w] < 0: rdfs(w,c)
    for v in reversed(order):
        if comp[v] < 0:
            comps.append([]); rdfs(v,len(comps)-1)
    return comp, comps


def transitive_closure_dag(k, edges):
    rel=[[False]*k for _ in range(k)]
    for i,j in edges:
        if i!=j: rel[i][j]=True
    changed=True
    while changed:
        changed=False
        for i in range(k):
            for j in range(k):
                if rel[i][j]:
                    for l in range(k):
                        if rel[j][l] and not rel[i][l]:
                            rel[i][l]=True; changed=True
    return rel


def check_scc_vertical_lift(names, ok_pp, directed_edges):
    n=len(names)
    comp, comps=sccs(n, directed_edges)
    q_edges=set()
    for i,j in directed_edges:
        ci,cj=comp[i],comp[j]
        if ci!=cj: q_edges.add((ci,cj))
    qrel=transitive_closure_dag(len(comps), q_edges)
    # quotient must be acyclic
    for c in range(len(comps)):
        if qrel[c][c]:
            return False, f"SCC quotient has cycle at component {c}", comp, comps, qrel
    # Inside each SCC, periodic total order creates p<q for all pairs of states,
    # including p=q across distinct copies.
    for c, members in enumerate(comps):
        if len(members)>1 or any(i==j for i,j in directed_edges if comp[i]==c):
            for p in members:
                for q in members:
                    if not ok_pp[p][q]:
                        return False, f"inside SCC {c}, PP-incompatible {names[p]} < {names[q]}", comp, comps, qrel
    # Between SCCs, lower<upper for every type pair.
    for c in range(len(comps)):
        for d in range(len(comps)):
            if qrel[c][d]:
                for p in comps[c]:
                    for q in comps[d]:
                        if not ok_pp[p][q]:
                            return False, f"between SCCs {c}<{d}, PP-incompatible {names[p]} < {names[q]}", comp, comps, qrel
    return True, "ok", comp, comps, qrel


def mat(n, default=True): return [[default]*n for _ in range(n)]


def show_result(names, ok_pp, edges):
    ok, reason, comp, comps, qrel = check_scc_vertical_lift(names, ok_pp, edges)
    print(f"names={names}")
    print(f"edges={[ (names[i],names[j]) for i,j in edges ]}")
    print(f"ok={ok} reason={reason}")
    if ok:
        print("SCCs:", [[names[i] for i in c] for c in comps])
        print("quotient order:")
        for i,row in enumerate(qrel):
            outs=[j for j,v in enumerate(row) if v]
            print(f"  C{i} -> {outs}")
    print()


def main():
    print("WP55 SCC vertical lift")
    # Bidirectional P/Q vertical witnesses: static orientation fails, periodic SCC succeeds.
    names=["P","Q"]
    ok_pp=mat(2, True)
    edges={(0,1),(1,0)}
    print("Example 1: bidirectional P/Q, all PP-compatible: periodic lift succeeds")
    show_result(names, ok_pp, edges)

    # The WP54 cyclic orientation example with missing transitive compat fails.
    names=["A","B","C"]
    ok_pp=mat(3, False)
    for i in range(3): ok_pp[i][i]=False
    ok_pp[0][1]=True; ok_pp[1][2]=True; ok_pp[2][0]=True
    edges={(0,1),(1,2),(2,0)}
    print("Example 2: 3-cycle but missing all-pairs PP compatibility: lift fails")
    show_result(names, ok_pp, edges)

    # Same 3-cycle, saturated all-pairs compatibility: periodic SCC succeeds.
    names=["A","B","C"]
    ok_pp=mat(3, True)
    print("Example 3: 3-cycle with all-pairs PP compatibility: periodic lift succeeds")
    show_result(names, ok_pp, edges)
    print("PASS: cyclic type-order guards are finite-checkable via SCC periodic vertical components.")

if __name__ == "__main__":
    main()
