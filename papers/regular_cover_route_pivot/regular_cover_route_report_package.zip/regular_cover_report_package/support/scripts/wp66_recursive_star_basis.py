#!/usr/bin/env python3
"""
WP66: recursive star-basis / universal-cover prefix sanity check.

This probe builds finite prefixes of a regular extension basis with a protected
PO pocket repeated along a vertical PP chain.

At each level i there are nodes A_i, B_i, C_i with:
  A_i PO B_i     (selected witness for A's exists-PO B demand)
  B_i PP C_i
  A_i PP C_i     (forced pocket guard: PO;PP={PO,PP}, PO forbidden to C)
  C_i PP A_{i+1} (recursive vertical continuation, for i+1 < n)

No DR seeds are used.  The order is the transitive closure of these PP edges;
PO is residual.  This is a universal-cover style unfolding of one finite star
basis; paths are split rather than quotiented.

The script checks finite prefixes for RCC5 composition closure, witness totality
for A_i -> B_i via PO, and stabilization of formula-visible pair/triple colours.
"""
from itertools import product

ATOMS = ["EQ", "PP", "PPI", "PO", "DR"]
PROPER = ["PP", "PPI", "PO", "DR"]

def rel_of_sets(a,b):
    A=set(a); B=set(b)
    if A==B: return "EQ"
    if A < B: return "PP"
    if A > B: return "PPI"
    if A.isdisjoint(B): return "DR"
    return "PO"

# derive RCC5 composition table from a small universe
U = range(4)
subs = [frozenset(s for i,s in enumerate(U) if mask & (1<<i)) for mask in range(1,1<<4)]
COMP = {(r,s): set() for r in ATOMS for s in ATOMS}
for X,Y,Z in product(subs, repeat=3):
    COMP[(rel_of_sets(X,Y), rel_of_sets(Y,Z))].add(rel_of_sets(X,Z))

CONV = {"EQ":"EQ", "PP":"PPI", "PPI":"PP", "PO":"PO", "DR":"DR"}

def build_prefix(n):
    # nodes are tuples (kind,i), kind in A,B,C
    nodes=[]
    for i in range(n):
        nodes += [("A",i),("B",i),("C",i)]
    # base less-than edges x<y means x PP y
    base=[]
    for i in range(n):
        base.append((("B",i),("C",i)))
        base.append((("A",i),("C",i)))
        if i+1<n:
            base.append((("C",i),("A",i+1)))
    # transitive closure
    less=set(base)
    changed=True
    while changed:
        changed=False
        for x,y in list(less):
            for u,v in list(less):
                if y==u and (x,v) not in less:
                    less.add((x,v)); changed=True
    return nodes, less

def atom(x,y,less):
    if x==y: return "EQ"
    if (x,y) in less: return "PP"
    if (y,x) in less: return "PPI"
    return "PO"  # no DR seeds in this example

def check_closed(nodes, less):
    errs=[]
    for x,y,z in product(nodes, repeat=3):
        r=atom(x,y,less); s=atom(y,z,less); t=atom(x,z,less)
        if t not in COMP[(r,s)]:
            errs.append((x,y,z,r,s,t,COMP[(r,s)]))
            if len(errs)>10: break
    return errs

def pair_colour(x,y,less):
    # formula-visible: source kind, target kind, atom, witness labels
    r=atom(x,y,less)
    w=[]
    # selected witness label: A_i --PO--> B_i
    if x[0]=="A" and y[0]=="B" and x[1]==y[1] and r=="PO":
        w.append("e_A_PO_B")
    # recursive PP witness: C_i --PP--> A_{i+1}
    if x[0]=="C" and y[0]=="A" and y[1]==x[1]+1 and r=="PP":
        w.append("e_C_PP_A")
    return (x[0], y[0], r, tuple(w))

def witness_errors(nodes, less):
    errs=[]
    for x in nodes:
        if x[0]=="A":
            y=("B",x[1])
            if y not in nodes or atom(x,y,less)!="PO":
                errs.append((x,"missing A PO B witness"))
        if x[0]=="C" and x[1]+1 < max(i for _,i in nodes)+1:
            y=("A",x[1]+1)
            if y not in nodes or atom(x,y,less)!="PP":
                errs.append((x,"missing C PP A witness"))
    return errs

def summarize(n):
    nodes, less = build_prefix(n)
    cerrs=check_closed(nodes, less)
    werrs=witness_errors(nodes, less)
    pcs={pair_colour(x,y,less) for x,y in product(nodes, repeat=2)}
    triples={(pair_colour(x,y,less), pair_colour(y,z,less), pair_colour(x,z,less)) for x,y,z in product(nodes, repeat=3)}
    # count protected pocket forced edges A_i PP C_i
    pocket_ok=all(atom(("A",i),("C",i),less)=="PP" for i in range(n))
    return len(nodes), len(pcs), len(triples), len(cerrs), len(werrs), pocket_ok

if __name__ == "__main__":
    print("WP66 recursive star-basis universal-cover prefix check")
    for n in [1,2,3,4,6,9,12]:
        objs, pc, tc, ce, we, pok = summarize(n)
        print(f"n={n}: objects={objs} pair_colours={pc} triple_patterns={tc} closure_errors={ce} witness_errors={we} pocket_forced_PP={pok}")
    print("\nSample relations for n=4:")
    nodes, less = build_prefix(4)
    for pair in [(("A",0),("B",0)), (("B",0),("C",0)), (("A",0),("C",0)), (("C",0),("A",1)), (("B",0),("A",1)), (("A",0),("B",1)), (("A",2),("B",2))]:
        print(f"  {pair[0]} -> {pair[1]} = {atom(pair[0],pair[1],less)}, colour={pair_colour(pair[0],pair[1],less)}")
