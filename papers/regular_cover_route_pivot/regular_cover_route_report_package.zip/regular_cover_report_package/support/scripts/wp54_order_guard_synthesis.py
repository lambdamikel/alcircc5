#!/usr/bin/env python3
"""
WP54: finite order/DR guard synthesis for residual PO-unsafe pairs.

This is a finite-component abstraction of the full regular-cover PO-repair
problem.  It does not prove completeness for ALCI_RCC5; it demonstrates that,
for a fixed finite guard template, deciding whether residual PO-unsafe pairs can
be repaired by adding DR guards and/or acyclic order guards is a finite CSP.

States/components are abstract.  Compatibility OK_R(i,j) says that putting i R j
would respect endpoint universal requirements already saturated into types.
"""
from itertools import product

NAMES = []
IDX = {}

def add_names(names):
    global NAMES, IDX
    NAMES = list(names)
    IDX = {n:i for i,n in enumerate(NAMES)}


def transitive_closure(less):
    n = len(less)
    less = [row[:] for row in less]
    changed = True
    while changed:
        changed = False
        for i in range(n):
            for j in range(n):
                if less[i][j]:
                    rowj = less[j]
                    for k in range(n):
                        if rowj[k] and not less[i][k]:
                            less[i][k] = True
                            changed = True
    return less


def downward_closure(disj, less):
    n = len(disj)
    leq = [[i == j or less[i][j] for j in range(n)] for i in range(n)]
    out = [row[:] for row in disj]
    changed = True
    while changed:
        changed = False
        for a in range(n):
            for b in range(n):
                if out[a][b]:
                    for x in range(n):
                        if leq[x][a]:
                            for y in range(n):
                                if leq[y][b] and not out[x][y]:
                                    out[x][y] = out[y][x] = True
                                    changed = True
    return out


def check_template(ok_pp, ok_dr, ok_po, base_less, base_disj, protected_po=None):
    """Return (valid, reason, less_closure, disj_closure)."""
    n = len(base_less)
    protected_po = protected_po or set()
    less = transitive_closure(base_less)
    for i in range(n):
        if less[i][i]:
            return False, f"order cycle at {NAMES[i]}", less, base_disj
    disj = downward_closure(base_disj, less)
    for i in range(n):
        if disj[i][i]:
            return False, f"DR hits diagonal at {NAMES[i]}", less, disj
    for i in range(n):
        for j in range(n):
            if less[i][j] and disj[i][j]:
                return False, f"comparable and DR: {NAMES[i]} < {NAMES[j]}", less, disj
            if less[i][j] and not ok_pp[i][j]:
                return False, f"PP-incompatible generated: {NAMES[i]} < {NAMES[j]}", less, disj
            if disj[i][j] and not ok_dr[i][j]:
                return False, f"DR-incompatible generated: {NAMES[i]} # {NAMES[j]}", less, disj
    for i,j in protected_po:
        if i == j or less[i][j] or less[j][i] or disj[i][j]:
            return False, f"protected PO destroyed: {NAMES[i]}--{NAMES[j]}", less, disj
    for i in range(n):
        for j in range(n):
            if i == j: continue
            if not less[i][j] and not less[j][i] and not disj[i][j]:
                if not ok_po[i][j]:
                    return False, f"unsafe residual PO: {NAMES[i]}--{NAMES[j]}", less, disj
    return True, "ok", less, disj


def synthesize(ok_pp, ok_dr, ok_po, initial_less=None, initial_disj=None, protected_po=None, max_solutions=5):
    n = len(ok_pp)
    initial_less = initial_less or [[False]*n for _ in range(n)]
    initial_disj = initial_disj or [[False]*n for _ in range(n)]
    protected_po = protected_po or set()

    # Compute initial closure; identify residual unsafe unordered pairs.
    valid0, reason0, less0, disj0 = check_template(ok_pp, ok_dr, ok_po, initial_less, initial_disj, protected_po)
    if valid0:
        return [(less0, disj0, [])]

    pairs = []
    for i in range(n):
        for j in range(i+1, n):
            if (i,j) in protected_po or (j,i) in protected_po:
                continue
            # If not already guarded under initial closure and PO is unsafe either direction, choose a guard.
            if not less0[i][j] and not less0[j][i] and not disj0[i][j] and (not ok_po[i][j] or not ok_po[j][i]):
                opts = []
                if ok_dr[i][j] and ok_dr[j][i]:
                    opts.append(('DR', i, j))
                if ok_pp[i][j]:
                    opts.append(('LT', i, j))
                if ok_pp[j][i]:
                    opts.append(('LT', j, i))
                if not opts:
                    return []
                pairs.append(((i,j), opts))

    sols = []
    for choices in product(*[opts for _,opts in pairs]):
        less = [row[:] for row in initial_less]
        disj = [row[:] for row in initial_disj]
        trace = []
        for kind,i,j in choices:
            trace.append((kind, NAMES[i], NAMES[j]))
            if kind == 'DR':
                disj[i][j] = disj[j][i] = True
            elif kind == 'LT':
                less[i][j] = True
        valid, reason, lc, dc = check_template(ok_pp, ok_dr, ok_po, less, disj, protected_po)
        if valid:
            sols.append((lc, dc, trace))
            if len(sols) >= max_solutions:
                break
    return sols


def mat(n, default=True):
    return [[default for _ in range(n)] for __ in range(n)]


def print_rel(title, rel):
    print(title)
    for i,row in enumerate(rel):
        vals = [NAMES[j] for j,v in enumerate(row) if v]
        print(f"  {NAMES[i]} -> {vals}")


def run_example_order_succeeds():
    print("\nExample 1: DR forbidden, acyclic order guard succeeds")
    add_names(["A","B"])
    n=2
    ok_pp = mat(n, True)
    ok_dr = mat(n, True)
    ok_po = mat(n, True)
    # A/B cannot be PO and cannot be DR; only A<B is compatible.
    ok_po[0][1] = ok_po[1][0] = False
    ok_dr[0][1] = ok_dr[1][0] = False
    ok_pp[1][0] = False
    sols = synthesize(ok_pp, ok_dr, ok_po)
    print(f"solutions={len(sols)}")
    if sols:
        less, disj, trace = sols[0]
        print("chosen", trace)
        print_rel("less", less)
        print_rel("disj", disj)


def run_example_cycle_fails_static():
    print("\nExample 2: orientation cycle has no finite static guard solution")
    add_names(["A","B","C"])
    n=3
    ok_pp = mat(n, False)
    ok_dr = mat(n, False)
    ok_po = mat(n, True)
    # Unsafe pairs must be oriented A<B, B<C, C<A.  DR forbidden.
    for i in range(n):
        ok_pp[i][i] = False
        ok_dr[i][i] = False
    required = [(0,1),(1,2),(2,0)]
    for i,j in required:
        ok_po[i][j] = ok_po[j][i] = False
        ok_pp[i][j] = True
    sols = synthesize(ok_pp, ok_dr, ok_po)
    print(f"solutions={len(sols)}")
    print("expected: 0, because the only guards form A<B<C<A")


def run_example_dr_repair_then_order():
    print("\nExample 3: mixed DR/order repair succeeds after closure")
    add_names(["A","B","C"])
    n=3
    ok_pp = mat(n, True)
    ok_dr = mat(n, True)
    ok_po = mat(n, True)
    # A/B unsafe; DR ok, so solver may use DR.
    ok_po[0][1] = ok_po[1][0] = False
    # B/C unsafe; DR forbidden, only B<C works.
    ok_po[1][2] = ok_po[2][1] = False
    ok_dr[1][2] = ok_dr[2][1] = False
    ok_pp[2][1] = False
    sols = synthesize(ok_pp, ok_dr, ok_po)
    print(f"solutions={len(sols)}")
    if sols:
        less, disj, trace = sols[0]
        print("chosen", trace)
        print_rel("less", less)
        print_rel("disj", disj)


def main():
    print("WP54 finite PO-guard synthesis over components")
    run_example_order_succeeds()
    run_example_cycle_fails_static()
    run_example_dr_repair_then_order()
    print("\nPASS: finite static guard synthesis is a decidable CSP for a fixed component template.")

if __name__ == "__main__":
    main()
