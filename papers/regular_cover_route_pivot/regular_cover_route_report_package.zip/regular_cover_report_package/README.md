# Regular-cover route report package

This package contains the formal report and all supporting Python probes and captured outputs from the regular-cover phase of the ALCI_RCC5 exploration, beginning with the cyclic PP/PPI generator / regular-cover reframing.

## Contents

- `report/regular_cover_route_report.pdf` - compiled formal report.
- `report/regular_cover_route_report.tex` - LaTeX source.
- `support/scripts/` - Python probes WP45-WP80 found in the workspace.
- `support/outputs/` - captured outputs for each probe.
- `MANIFEST.txt` - relative-path manifest.

## Reproducing probe outputs

From the package root, run for example:

```bash
python3 support/scripts/wp80_principal_lower_connector_basis.py
```

The corresponding saved output is in:

```bash
support/outputs/wp80_principal_lower_connector_basis.out
```

The report is conservative: it does not claim full decidability.  It records the regular-cover theorem stack, the unconditional forall-PO-free decidability result, and the remaining bounded coherent regular-cover / extension-basis lemma.
