# F6 candidate investigations report package

This archive contains the formal report and supporting scripts for the three post-BCD investigations:

1. WP41: shell-staircase forcing candidate.
2. WP42: finite Lean-style row-catalogue collapse of the shell staircase.
3. WP43: pumped W2'-style non-uniformity attempt and one-slot finite-memory collapse.

## Contents

- `report/f6_candidates_last3_report.pdf` - compiled report.
- `report/f6_candidates_last3_report.tex` - LaTeX source.
- `support/scripts/wp41_shell_staircase_f6_candidate.py` - shell finite-prefix checker.
- `support/scripts/wp42_shell_catalogue_collapse.py` - row-catalogue/SCat-style checker.
- `support/scripts/wp43_pumped_w2_attempt.py` - pumped W2' finite-prefix checker.
- `support/outputs/*.txt` - captured outputs from the scripts.
- `support/lean_relevant_excerpt.txt` - small extracted excerpt of the attached Lean file showing the steering shape and SCat fields used for comparison.

## Reproduce

From the package root:

```bash
python3 support/scripts/wp41_shell_staircase_f6_candidate.py
python3 support/scripts/wp42_shell_catalogue_collapse.py
python3 support/scripts/wp43_pumped_w2_attempt.py
```

The scripts are dependency-free Python 3 programs.
