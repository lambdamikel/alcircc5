Support files for the W2' impact report.

Files:
- wp39_w2prime_small_witness.py
  Self-contained Python script deriving the RCC5 composition table from finite set semantics and verifying the small jointly-realizable but non-coarse-uniform glue step.

- wp39_w2prime_small_witness_output.txt
  Output of running the witness script in this environment.

- lean_formalization_anchors.txt
  Grep extract of relevant theorem/definition/comment anchors from formal/Round19Transport.lean in the uploaded repository. This is not a Lean kernel check; Lean/lake were not installed in this environment.

Run:
  python3 support/wp39_w2prime_small_witness.py
