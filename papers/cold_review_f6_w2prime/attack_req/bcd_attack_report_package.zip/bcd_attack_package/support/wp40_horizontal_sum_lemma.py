#!/usr/bin/env python3
"""
WP40: finite RCC5 checks supporting the Target-B/D note.

The script verifies the two table facts used in the horizontal-sum lemma:

  (A) horizontal absorption: for H in {DR,PO} and every RCC5 relation R,
      H is in comp(R,H) and in comp(H,R).

  (B) horizontal triangle freedom: for H1,H2,H3 in {DR,PO},
      H3 is in comp(H1,H2).

Together these imply: if RCC5 networks are put in disjoint components and
all cross-pairs between component i and component j are assigned one fixed
horizontal label H_ij in {DR,PO}, then the disjoint union is still
composition-closed, provided the component-level labels form any symmetric
{DR,PO}-network.
"""

REL = ["EQ", "DR", "PO", "PP", "PPI"]
HREL = ["DR", "PO"]

COMP = {
    ("EQ", "EQ"): {"EQ"},
    ("EQ", "DR"): {"DR"},
    ("EQ", "PO"): {"PO"},
    ("EQ", "PP"): {"PP"},
    ("EQ", "PPI"): {"PPI"},

    ("DR", "EQ"): {"DR"},
    ("DR", "DR"): {"EQ", "DR", "PO", "PP", "PPI"},
    ("DR", "PO"): {"DR", "PO", "PP"},
    ("DR", "PP"): {"DR", "PO", "PP"},
    ("DR", "PPI"): {"DR"},

    ("PO", "EQ"): {"PO"},
    ("PO", "DR"): {"DR", "PO", "PPI"},
    ("PO", "PO"): {"EQ", "DR", "PO", "PP", "PPI"},
    ("PO", "PP"): {"PO", "PP"},
    ("PO", "PPI"): {"DR", "PO", "PPI"},

    ("PP", "EQ"): {"PP"},
    ("PP", "DR"): {"DR"},
    ("PP", "PO"): {"DR", "PO", "PP"},
    ("PP", "PP"): {"PP"},
    ("PP", "PPI"): {"EQ", "DR", "PO", "PP", "PPI"},

    ("PPI", "EQ"): {"PPI"},
    ("PPI", "DR"): {"DR", "PO", "PPI"},
    ("PPI", "PO"): {"PO", "PPI"},
    ("PPI", "PP"): {"EQ", "PO", "PP", "PPI"},
    ("PPI", "PPI"): {"PPI"},
}

def check_absorption():
    failures = []
    for h in HREL:
        for r in REL:
            if h not in COMP[(r, h)]:
                failures.append(("right", r, h, COMP[(r, h)]))
            if h not in COMP[(h, r)]:
                failures.append(("left", h, r, COMP[(h, r)]))
    return failures

def check_triangle_freedom():
    failures = []
    for h1 in HREL:
        for h2 in HREL:
            for h3 in HREL:
                if h3 not in COMP[(h1, h2)]:
                    failures.append((h1, h2, h3, COMP[(h1, h2)]))
    return failures

def main():
    print("WP40 horizontal-sum checks")
    print("relations:", REL)
    print("horizontal relations:", HREL)
    print()

    absorption_failures = check_absorption()
    triangle_failures = check_triangle_freedom()

    print("(A) horizontal absorption failures:", len(absorption_failures))
    for item in absorption_failures:
        print("  ", item)
    print("(B) horizontal triangle-freedom failures:", len(triangle_failures))
    for item in triangle_failures:
        print("  ", item)
    print()

    assert not absorption_failures
    assert not triangle_failures

    print("PASS")
    print("Consequent lemma: arbitrary RCC5 components may be horizontally summed")
    print("by assigning each cross-component pair one fixed DR/PO label.")

if __name__ == "__main__":
    main()
