# B/C/D attack package

Contents:

- `report/bcd_attack_report.tex` - TeX source.
- `report/bcd_attack_report.pdf` - compiled PDF report.
- `support/wp40_po_gap_live_width.py` - self-contained RCC5 composition-table check for the PO-gap construction and its bounded live window.

Run the support script with:

```bash
python3 support/wp40_po_gap_live_width.py
```
