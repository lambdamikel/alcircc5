F6 separator-cover investigation package

Contents:
- report/f6_separator_cover_report.pdf: formal technical report.
- report/f6_separator_cover_report.tex: LaTeX source.
- support/scripts/: scripts used in the last F6 candidate and separator-cover investigations.
- support/outputs/: captured outputs from those scripts.

Main new result:
- wp44_unbounded_separator_cover_glue.py constructs arbitrary finite RCC5 glue steps with separator-cover number n, showing that support-tree compression alone cannot prove F6. The construction is not claimed to be ALCI-forced.

Bottom line:
- Shell and pumped-W2 candidates are not F6 threats: both are finite-catalogue quotientable.
- Full F6 remains open.
- The sharpened target is unbounded forced M_n identity-selector minors.
